import { AccountMeta, PublicKey } from "@solana/web3.js";
import IDL from "./idl_v2.js";
import type { DuskDefinedInput } from "./instruction-args.js";

/** Shared on-chain default; regenerated from the program instead of duplicated here. */
export const DEFAULT_PROTOCOL_REVENUE_SHARE_BPS = Number(
  IDL.constants.find(({ name }) => name === "DEFAULT_PROTOCOL_REVENUE_SHARE_BPS")!.value
);

const DEFAULT_PROGRAM_ID = "DuskWhswJYrzABDn8GqQD191X9RobRi5jhgGntXEdnKj";
const MPL_TOKEN_METADATA_PROGRAM_ID = "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s";

function getProgramIdFromEnv(fallback: string): string {
  if (typeof process === "undefined" || !process.env) return fallback;
  return process.env.DUSK_PROGRAM_ID ?? fallback;
}

/**
 * Omnipair Dusk program ID.
 * Reads from env DUSK_PROGRAM_ID.
 */
export const DUSK_PROGRAM_ID = new PublicKey(getProgramIdFromEnv(DEFAULT_PROGRAM_ID));

export const PROGRAM_ID = DUSK_PROGRAM_ID;
/** Fewest decimals a market counts token amounts in (curve depth, hLP NAV and
 * debt/collateral values). Prices, rates and ratios stay at nine decimals. */
export const MIN_AMOUNT_DECIMALS = Number(
  IDL.constants.find(({ name }) => name === "MIN_AMOUNT_DECIMALS")!.value
);
/** The one Market account layout the program reads. Accounts at any other
 * layout are rejected rather than read at this layout's amount scale. */
export const MARKET_LAYOUT_VERSION = Number(
  IDL.constants.find(({ name }) => name === "MARKET_LAYOUT_VERSION")!.value
);
export const TOKEN_METADATA_PROGRAM_ID = new PublicKey(MPL_TOKEN_METADATA_PROGRAM_ID);

/** Immutable Dusk operator and metadata limits. */
export const PARAMETER_EXECUTION_MAX_UTILIZATION_BPS = 8_000;
export const PROPOSAL_METADATA_VERSION = 1;
export const MAX_PROPOSAL_TITLE_BYTES = 96;
export const MAX_PROPOSAL_DESCRIPTION_URI_BYTES = 200;
export const MAX_PROPOSAL_DESCRIPTION_BYTES = 32_768;
// Nominal 1-7 day ramp at Solana's current 200 ms scheduled slot cadence.
// Update with the on-chain timing constant if the network cadence changes.
export const DEFAULT_CONCENTRATION_RAMP_DURATION_SLOTS = 432_000;
export const MIN_CONCENTRATION_RAMP_DURATION_SLOTS = 432_000;

/**
 * PDA seeds used by the program
 */
export const SEEDS = {
  MARKET_V2: Buffer.from("market_v2"),
  MARKET_RESERVE_VAULT: Buffer.from("market_reserve"),
  MARKET_COLLATERAL_VAULT: Buffer.from("market_collateral"),
  MARKET_INTEREST_VAULT: Buffer.from("market_interest"),
  BORROW_POSITION: Buffer.from("borrow_position_v2"),
  LEVERAGE_POSITION: Buffer.from("leverage_position_v2"),
  LEVERAGE_COLLATERAL_VAULT: Buffer.from("leverage_collateral"),
  LEVERAGE_DELEGATION: Buffer.from("leverage_delegation_v2"),
  YIELD_ACCOUNT: Buffer.from("yield"),
  // Stable PDA namespace, shared with the program.
  HLP_SRLP_VAULT: Buffer.from("hlp_ylp_vault"),
  HLP_COHORT: Buffer.from("hlp_cohort"),
  EVENT_AUTHORITY: Buffer.from("__event_authority"),
  FUTARCHY_AUTHORITY: Buffer.from("futarchy_authority"),
  REFERRAL_PARTNER: Buffer.from("referral_partner"),
  REFERRAL_ACCRUAL: Buffer.from("referral_accrual"),
  METADATA: Buffer.from("metadata"),
} as const;

/** Derive the canonical Anchor event-CPI authority for a Dusk program. */
export function deriveEventAuthorityAddress(
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([SEEDS.EVENT_AUTHORITY], programId);
}

function normalizeParamsHash(paramsHash: Uint8Array | Buffer | number[]): Buffer {
  const hash = Buffer.from(paramsHash);
  if (hash.length !== 32) {
    throw new Error(`paramsHash must be 32 bytes, got ${hash.length}`);
  }
  return hash;
}

/**
 * Derive Futarchy Authority PDA address
 */
export function deriveFutarchyAuthorityAddress(programId: PublicKey = DUSK_PROGRAM_ID): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([SEEDS.FUTARCHY_AUTHORITY], programId);
}

/** Derive the protocol-wide referral partner for a referrer authority. */
export function deriveReferralPartnerAddress(
  authority: PublicKey,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [SEEDS.REFERRAL_PARTNER, authority.toBuffer()],
    programId
  );
}

/** Derive claimable referral interest for one partner, market, and debt mint. */
export function deriveReferralAccrualAddress(
  referralPartner: PublicKey,
  market: PublicKey,
  assetMint: PublicKey,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [
      SEEDS.REFERRAL_ACCRUAL,
      referralPartner.toBuffer(),
      market.toBuffer(),
      assetMint.toBuffer(),
    ],
    programId
  );
}

export type U64SeedLike = bigint | number | string | { toString(): string };

function u64Seed(value: U64SeedLike, label: string): Buffer {
  if (typeof value === "number" && !Number.isSafeInteger(value)) {
    throw new Error(`${label} must be a safe integer when supplied as a number`);
  }
  let normalized: bigint;
  try {
    normalized = BigInt(value.toString());
  } catch {
    throw new Error(`${label} must be an unsigned 64-bit integer`);
  }
  if (normalized < 0n || normalized > 0xffff_ffff_ffff_ffffn) {
    throw new Error(`${label} must be an unsigned 64-bit integer`);
  }
  const encoded = Buffer.alloc(8);
  encoded.writeBigUInt64LE(normalized);
  return encoded;
}

/** Derive one immutable typed parameter proposal. The nonce is Borsh u64 LE. */


/** Derive one support position. Locked srLP cannot be shared across proposals. */


/**
 * Derive Dusk market PDA address
 */
export function deriveMarketAddress(
  baseMint: PublicKey,
  quoteMint: PublicKey,
  paramsHash: Uint8Array | Buffer | number[],
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [
      SEEDS.MARKET_V2,
      baseMint.toBuffer(),
      quoteMint.toBuffer(),
      normalizeParamsHash(paramsHash),
    ],
    programId
  );
}

/**
 * Derive a Metaplex Token Metadata PDA for a mint.
 */
export function deriveTokenMetadataAddress(mint: PublicKey): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [SEEDS.METADATA, TOKEN_METADATA_PROGRAM_ID.toBuffer(), mint.toBuffer()],
    TOKEN_METADATA_PROGRAM_ID
  );
}

/**
 * Derive market reserve vault PDA address
 */
export function deriveMarketReserveVaultAddress(
  market: PublicKey,
  reserveMint: PublicKey,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [SEEDS.MARKET_RESERVE_VAULT, market.toBuffer(), reserveMint.toBuffer()],
    programId
  );
}

/**
 * Derive market collateral vault PDA address
 */
/** Per-market collateral custody for leverage positions. */
export function deriveLeverageCollateralVaultAddress(
  market: PublicKey,
  collateralMint: PublicKey,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [SEEDS.LEVERAGE_COLLATERAL_VAULT, market.toBuffer(), collateralMint.toBuffer()],
    programId
  );
}

export function deriveMarketCollateralVaultAddress(
  market: PublicKey,
  collateralMint: PublicKey,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [SEEDS.MARKET_COLLATERAL_VAULT, market.toBuffer(), collateralMint.toBuffer()],
    programId
  );
}

/**
 * Derive market interest vault PDA address
 */
export function deriveMarketInterestVaultAddress(
  market: PublicKey,
  interestMint: PublicKey,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [SEEDS.MARKET_INTEREST_VAULT, market.toBuffer(), interestMint.toBuffer()],
    programId
  );
}

/**
 * Derive borrow position PDA address
 */
export function deriveBorrowPositionAddress(
  market: PublicKey,
  owner: PublicKey,
  positionId: PublicKey,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [SEEDS.BORROW_POSITION, market.toBuffer(), owner.toBuffer(), positionId.toBuffer()],
    programId
  );
}

/**
 * Derive leverage position PDA address
 */
/** Delegation is keyed by the position it delegates, not by the owner. */
export function deriveLeverageDelegationAddress(
  leveragePosition: PublicKey,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [SEEDS.LEVERAGE_DELEGATION, leveragePosition.toBuffer()],
    programId
  );
}

/** `namespaceAuthority` defaults to the position owner; pass it explicitly
 * (or `undefined`) before `programId` for another deployment. */
export function deriveLeveragePositionAddress(
  market: PublicKey,
  positionOwner: PublicKey,
  positionId: PublicKey,
  namespaceAuthority: PublicKey = positionOwner,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [
      SEEDS.LEVERAGE_POSITION,
      market.toBuffer(),
      positionOwner.toBuffer(),
      namespaceAuthority.toBuffer(),
      positionId.toBuffer(),
    ],
    programId
  );
}

export type YieldTokenKind = "srlp" | "hlp" | "junior" | 0 | 1 | 2;

function yieldTokenKindCode(tokenKind: YieldTokenKind): number {
  if (tokenKind === "srlp" || tokenKind === 0) return 0;
  if (tokenKind === "hlp" || tokenKind === 1) return 1;
  if (tokenKind === "junior" || tokenKind === 2) return 2;
  throw new Error(`Unsupported yield token kind: ${tokenKind}`);
}

/** The `YieldTokenKind` enum value an instruction argument takes, such as `{ hlp: {} }`. */
export function yieldTokenKindArg(tokenKind: YieldTokenKind): DuskDefinedInput<"yieldTokenKind"> {
  switch (yieldTokenKindCode(tokenKind)) {
    case 0:
      return { srlp: {} };
    case 2:
      return { junior: {} };
    default:
      return { hlp: {} };
  }
}

/**
 * Derive yield-account PDA address for srLP/hLP revenue checkpoints.
 */
export function deriveYieldAccountAddress(
  market: PublicKey,
  owner: PublicKey,
  lpMint: PublicKey,
  assetMint: PublicKey,
  tokenKind: YieldTokenKind,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [
      SEEDS.YIELD_ACCOUNT,
      market.toBuffer(),
      owner.toBuffer(),
      lpMint.toBuffer(),
      assetMint.toBuffer(),
      Buffer.from([yieldTokenKindCode(tokenKind)]),
    ],
    programId
  );
}

export interface YieldTransferHookAccountsArgs {
  lpMint: PublicKey;
  market: PublicKey;
  sourceOwner: PublicKey;
  destinationOwner: PublicKey;
  baseMint: PublicKey;
  quoteMint: PublicKey;
  tokenKind: YieldTokenKind;
  programId?: PublicKey;
}

export const TRANSFER_HOOK_EXECUTE_DISCRIMINATOR = Buffer.from([
  105, 37, 101, 197, 75, 251, 102, 26,
]);

const TRANSFER_HOOK_EXTRA_ACCOUNT_META_SIZE = 35;
const TRANSFER_HOOK_TOKEN_ACCOUNT_OWNER_OFFSET = 32;
const TRANSFER_HOOK_SOURCE_ACCOUNT_INDEX = 0;
const TRANSFER_HOOK_DESTINATION_ACCOUNT_INDEX = 2;
const TRANSFER_HOOK_MARKET_ACCOUNT_INDEX = 5;
const TRANSFER_HOOK_ASSET_MINT_ACCOUNT_INDEX = 6;
const TRANSFER_HOOK_QUOTE_ASSET_MINT_ACCOUNT_INDEX = 7;

type TransferHookSeed =
  | { kind: "literal"; bytes: Uint8Array | Buffer | number[] }
  | { kind: "instructionData"; index: number; length: number }
  | { kind: "accountKey"; index: number }
  | { kind: "accountData"; accountIndex: number; dataIndex: number; length: number };

interface TransferHookValidationMeta {
  discriminator: number;
  addressConfig: Buffer;
  isSigner: boolean;
  isWritable: boolean;
}

export interface LpTransferHookValidationArgs {
  market: PublicKey;
  baseMint: PublicKey;
  quoteMint: PublicKey;
  tokenKind: YieldTokenKind;
  programId?: PublicKey;
}

/**
 * Derive the standard Token-2022 transfer-hook validation PDA for a Dusk LP mint.
 */
export function deriveYieldTransferHookValidationAddress(
  lpMint: PublicKey,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [Buffer.from("extra-account-metas"), lpMint.toBuffer()],
    programId
  );
}

/** Mint-specific hLP cohort; retired mints retain their frozen yield state. */
export function deriveHlpCohortAddress(
  market: PublicKey,
  hlpMint: PublicKey,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [SEEDS.HLP_COHORT, market.toBuffer(), hlpMint.toBuffer()],
    programId
  );
}

function assertU8(value: number, label: string): void {
  if (!Number.isInteger(value) || value < 0 || value > 255) {
    throw new Error(`${label} must fit in a u8, got ${value}`);
  }
}

function packTransferHookSeedConfig(seeds: TransferHookSeed[]): Buffer {
  const config = Buffer.alloc(32);
  let offset = 0;
  const writeByte = (value: number, label: string) => {
    assertU8(value, label);
    if (offset >= config.length) {
      throw new Error("transfer-hook seed config exceeds 32 bytes");
    }
    config[offset] = value;
    offset += 1;
  };

  for (const seed of seeds) {
    switch (seed.kind) {
      case "literal": {
        const bytes = Buffer.from(seed.bytes);
        assertU8(bytes.length, "literal seed length");
        writeByte(1, "literal seed discriminator");
        writeByte(bytes.length, "literal seed length");
        if (offset + bytes.length > config.length) {
          throw new Error("transfer-hook seed config exceeds 32 bytes");
        }
        bytes.copy(config, offset);
        offset += bytes.length;
        break;
      }
      case "instructionData":
        writeByte(2, "instruction-data seed discriminator");
        writeByte(seed.index, "instruction-data seed index");
        writeByte(seed.length, "instruction-data seed length");
        break;
      case "accountKey":
        writeByte(3, "account-key seed discriminator");
        writeByte(seed.index, "account-key seed index");
        break;
      case "accountData":
        writeByte(4, "account-data seed discriminator");
        writeByte(seed.accountIndex, "account-data seed account index");
        writeByte(seed.dataIndex, "account-data seed data index");
        writeByte(seed.length, "account-data seed length");
        break;
    }
  }

  return config;
}

function staticTransferHookMeta(meta: AccountMeta): TransferHookValidationMeta {
  return {
    discriminator: 0,
    addressConfig: meta.pubkey.toBuffer(),
    isSigner: meta.isSigner,
    isWritable: meta.isWritable,
  };
}

function pdaTransferHookMeta(
  seeds: TransferHookSeed[],
  isWritable: boolean
): TransferHookValidationMeta {
  return {
    discriminator: 1,
    addressConfig: packTransferHookSeedConfig(seeds),
    isSigner: false,
    isWritable,
  };
}

function yieldAccountTransferHookSeeds(
  ownerTokenAccountIndex: number,
  tokenKind: YieldTokenKind,
  assetMintAccountIndex = TRANSFER_HOOK_ASSET_MINT_ACCOUNT_INDEX
): TransferHookSeed[] {
  return [
    { kind: "literal", bytes: SEEDS.YIELD_ACCOUNT },
    { kind: "accountKey", index: TRANSFER_HOOK_MARKET_ACCOUNT_INDEX },
    {
      kind: "accountData",
      accountIndex: ownerTokenAccountIndex,
      dataIndex: TRANSFER_HOOK_TOKEN_ACCOUNT_OWNER_OFFSET,
      length: 32,
    },
    { kind: "accountKey", index: 1 },
    { kind: "accountKey", index: assetMintAccountIndex },
    { kind: "literal", bytes: [yieldTokenKindCode(tokenKind)] },
  ];
}

function encodeTransferHookValidationAccountData(extraMetas: TransferHookValidationMeta[]): Buffer {
  const podSliceLength = 4 + extraMetas.length * TRANSFER_HOOK_EXTRA_ACCOUNT_META_SIZE;
  const data = Buffer.alloc(8 + 4 + podSliceLength);
  TRANSFER_HOOK_EXECUTE_DISCRIMINATOR.copy(data, 0);
  data.writeUInt32LE(podSliceLength, 8);
  data.writeUInt32LE(extraMetas.length, 12);

  let offset = 16;
  for (const meta of extraMetas) {
    data[offset] = meta.discriminator;
    offset += 1;
    meta.addressConfig.copy(data, offset);
    offset += 32;
    data[offset] = meta.isSigner ? 1 : 0;
    offset += 1;
    data[offset] = meta.isWritable ? 1 : 0;
    offset += 1;
  }
  return data;
}

/**
 * Encode a static Token-2022 transfer-hook validation account for Execute.
 *
 * The returned bytes use the SPL TLV shape expected by Token-2022:
 * execute discriminator, pod-slice length, count, then static account metas.
 */
export function buildYieldTransferHookValidationAccountData(extraMetas: AccountMeta[]): Buffer {
  return encodeTransferHookValidationAccountData(extraMetas.map(staticTransferHookMeta));
}

/**
 * Encode the production Token-2022 transfer-hook validation account for Dusk
 * srLP/hLP mints.
 *
 * The validation state resolves static market/asset-mint accounts and derives
 * source/destination YieldAccount PDAs from the source and destination token
 * account owners observed by Token-2022 during Execute.
 */
export function buildLpTransferHookValidationAccountData({
  market,
  baseMint,
  quoteMint,
  tokenKind,
  programId = DUSK_PROGRAM_ID,
}: LpTransferHookValidationArgs): Buffer {
  const eventMetas = [
        staticTransferHookMeta({
          pubkey: deriveEventAuthorityAddress(programId)[0],
          isSigner: false,
          isWritable: false,
        }),
        staticTransferHookMeta({ pubkey: programId, isSigner: false, isWritable: false }),
        staticTransferHookMeta({ pubkey: deriveFutarchyAuthorityAddress(programId)[0], isSigner: false, isWritable: false }),
      ];
  return encodeTransferHookValidationAccountData([
    staticTransferHookMeta({ pubkey: market, isSigner: false, isWritable: true }),
    staticTransferHookMeta({ pubkey: baseMint, isSigner: false, isWritable: false }),
    staticTransferHookMeta({ pubkey: quoteMint, isSigner: false, isWritable: false }),
    pdaTransferHookMeta(
      yieldAccountTransferHookSeeds(TRANSFER_HOOK_SOURCE_ACCOUNT_INDEX, tokenKind),
      true
    ),
    pdaTransferHookMeta(
      yieldAccountTransferHookSeeds(TRANSFER_HOOK_DESTINATION_ACCOUNT_INDEX, tokenKind),
      true
    ),
    pdaTransferHookMeta(
      yieldAccountTransferHookSeeds(
        TRANSFER_HOOK_SOURCE_ACCOUNT_INDEX,
        tokenKind,
        TRANSFER_HOOK_QUOTE_ASSET_MINT_ACCOUNT_INDEX
      ),
      true
    ),
    pdaTransferHookMeta(
      yieldAccountTransferHookSeeds(
        TRANSFER_HOOK_DESTINATION_ACCOUNT_INDEX,
        tokenKind,
        TRANSFER_HOOK_QUOTE_ASSET_MINT_ACCOUNT_INDEX
      ),
      true
    ),
    ...eventMetas,
    ...(yieldTokenKindCode(tokenKind) !== 0
      ? [
          pdaTransferHookMeta(
            [
              { kind: "literal", bytes: yieldTokenKindCode(tokenKind) === 2 ? Buffer.from("junior_cohort") : SEEDS.HLP_COHORT },
              { kind: "accountKey", index: TRANSFER_HOOK_MARKET_ACCOUNT_INDEX },
              { kind: "accountKey", index: 1 },
            ],
            false
          ),
        ]
      : []),
  ]);
}

/**
 * Build Dusk srLP/hLP transfer-hook extra account metas.
 *
 * Token-2022 passes the source token account, LP mint, destination token
 * account, and transfer authority as the base hook accounts. Omnipair Dusk needs
 * the market, underlying asset mint, canonical source/destination yield
 * accounts, hook program, and standard validation PDA as extra metas so the
 * hook can checkpoint revenue before the balance move is finalized. The event
 * authority and Dusk program let the hook publish `LpTransferred`, and the
 * futarchy authority and any hLP or junior cohort follow. The hook requires
 * this complete list; every LP mint's validation account declares it.
 */
export function buildLpTransferHookAccountMetas({
  lpMint,
  market,
  sourceOwner,
  destinationOwner,
  baseMint,
  quoteMint,
  tokenKind,
  programId = DUSK_PROGRAM_ID,
}: YieldTransferHookAccountsArgs): AccountMeta[] {
  const sourceBaseYieldAccount = deriveYieldAccountAddress(
    market,
    sourceOwner,
    lpMint,
    baseMint,
    tokenKind,
    programId
  )[0];
  const destinationBaseYieldAccount = deriveYieldAccountAddress(
    market,
    destinationOwner,
    lpMint,
    baseMint,
    tokenKind,
    programId
  )[0];
  const sourceQuoteYieldAccount = deriveYieldAccountAddress(
    market,
    sourceOwner,
    lpMint,
    quoteMint,
    tokenKind,
    programId
  )[0];
  const destinationQuoteYieldAccount = deriveYieldAccountAddress(
    market,
    destinationOwner,
    lpMint,
    quoteMint,
    tokenKind,
    programId
  )[0];
  const validationAccount = deriveYieldTransferHookValidationAddress(lpMint, programId)[0];

  return [
    { pubkey: market, isSigner: false, isWritable: true },
    { pubkey: baseMint, isSigner: false, isWritable: false },
    { pubkey: quoteMint, isSigner: false, isWritable: false },
    { pubkey: sourceBaseYieldAccount, isSigner: false, isWritable: true },
    { pubkey: destinationBaseYieldAccount, isSigner: false, isWritable: true },
    { pubkey: sourceQuoteYieldAccount, isSigner: false, isWritable: true },
    { pubkey: destinationQuoteYieldAccount, isSigner: false, isWritable: true },
    { pubkey: deriveEventAuthorityAddress(programId)[0], isSigner: false, isWritable: false },
    { pubkey: programId, isSigner: false, isWritable: false },
    { pubkey: deriveFutarchyAuthorityAddress(programId)[0], isSigner: false, isWritable: false },
    ...(yieldTokenKindCode(tokenKind) === 1
      ? [{ pubkey: deriveHlpCohortAddress(market, lpMint, programId)[0], isSigner: false, isWritable: false }]
      : yieldTokenKindCode(tokenKind) === 2
        ? [{ pubkey: deriveJuniorCohortAddress(market, lpMint, programId)[0], isSigner: false, isWritable: false }]
        : []),
    { pubkey: validationAccount, isSigner: false, isWritable: false },
  ];
}

/**
 * Derive canonical aggregate hLP vault srLP token-account PDA.
 */
export function deriveHlpSrlpVaultAddress(
  market: PublicKey,
  targetHlpMint: PublicKey,
  srlpMint: PublicKey,
  programId: PublicKey = DUSK_PROGRAM_ID
): [PublicKey, number] {
  return PublicKey.findProgramAddressSync(
    [
      SEEDS.HLP_SRLP_VAULT,
      market.toBuffer(),
      targetHlpMint.toBuffer(),
      srlpMint.toBuffer(),
    ],
    programId
  );
}






export function deriveJuniorMintAddress(market: PublicKey, generation: U64SeedLike, programId: PublicKey = DUSK_PROGRAM_ID): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([Buffer.from("junior_mint"), market.toBuffer(), u64Seed(generation, "generation")], programId);
}
export function deriveJuniorCohortAddress(market: PublicKey, mint: PublicKey, programId: PublicKey = DUSK_PROGRAM_ID): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([Buffer.from("junior_cohort"), market.toBuffer(), mint.toBuffer()], programId);
}
export function deriveJuniorExitAddress(market: PublicKey, owner: PublicKey, mint: PublicKey, programId: PublicKey = DUSK_PROGRAM_ID): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([Buffer.from("junior_exit"), market.toBuffer(), owner.toBuffer(), mint.toBuffer()], programId);
}

export function deriveIncomeEpochAddress(market: PublicKey, bookIndex: number, epoch: U64SeedLike, programId: PublicKey = DUSK_PROGRAM_ID): [PublicKey, number] {
  if (!Number.isInteger(bookIndex) || bookIndex < 0 || bookIndex > 3) throw new Error("bookIndex must be 0–3");
  return PublicKey.findProgramAddressSync([Buffer.from("income_epoch"), market.toBuffer(), Buffer.from([bookIndex]), u64Seed(epoch, "epoch")], programId);
}






export const OPERATOR_POLICY_VERSION = 2;
export const OPERATOR_PENDING_LIMIT = 1;
export const JUNIOR_MAX_NOTICE_SLOTS = 4_320_000;
export const OPERATOR_NOTICE_SLOTS = 4_752_000;
export const OPERATOR_EXECUTION_WINDOW_SLOTS = 3_024_000;
export const MAX_OPERATOR_INTEREST_SHARE_BPS = 10_000;
export function deriveOperatorProposalAddress(market: PublicKey, nonce: U64SeedLike, programId: PublicKey = DUSK_PROGRAM_ID): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([Buffer.from("operator_change"), market.toBuffer(), u64Seed(nonce, "nonce")], programId);
}

export function deriveOperatorRevenueAddress(market: PublicKey,revenueEpoch:U64SeedLike,programId:PublicKey=DUSK_PROGRAM_ID):[PublicKey,number] {
  return PublicKey.findProgramAddressSync([Buffer.from("operator_revenue"),market.toBuffer(),u64Seed(revenueEpoch,"revenueEpoch")],programId);
}
