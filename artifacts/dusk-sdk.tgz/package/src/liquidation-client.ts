import { fetchTransferFeeNotices, type MintTransferFeeNotice } from "./transfer-fees.js";
import type { Program } from "@coral-xyz/anchor";
import { createAssociatedTokenAccountIdempotentInstruction, getAssociatedTokenAddressSync, TOKEN_2022_PROGRAM_ID, TOKEN_PROGRAM_ID } from "@solana/spl-token";
import { ComputeBudgetProgram, PublicKey, SystemProgram, SYSVAR_INSTRUCTIONS_PUBKEY, type AccountMeta, type TransactionInstruction } from "@solana/web3.js";
import type { Dusk as DuskIdl } from "./types_v2.js";
import type { EmergencyLiquidationQuote, FlashAmmLiquidationQuote, FlashLiquidationQuote, LiquidationHealth } from "./type-aliases.js";
import { address, type AddressLike } from "./address.js";
import { DuskWrite } from "./write.js";
import { DuskGet } from "./get.js";
import { previewReturnDataBytes } from "./preview.js";
import { integerBN, type IntegerLike } from "./parameters.js";
import { tokenProgramForMint } from "./referral.js";
import { deriveFutarchyAuthorityAddress, deriveLeverageCollateralVaultAddress, deriveReferralAccrualAddress } from "./constants.js";
import { deriveLiquidationPaymentAddress, deriveLiquidationSessionAddress, grossLiquidationPayment } from "./liquidation.js";

export type { FlashLiquidationQuote, FlashAmmLiquidationQuote, EmergencyLiquidationQuote };

export interface LiquidationPositionParams {
  market: AddressLike;
  position: AddressLike;
  kind: "borrow" | "leverage";
  debtAsset: "base" | "quote";
}

export interface FlashLiquidationParams extends LiquidationPositionParams {
  buyer: AddressLike;
  maxRepayment: IntegerLike;
  full?: boolean;
  /** Net escrow balance increase, including all outgoing transfer gross-ups. */
  maxPayment?: IntegerLike;
  /** Actual buyer receipt after collateral transfer fees. */
  minCollateralCredit?: IntegerLike;
  /** Final debt-token receipt when `settlement` is `duskAmm`. */
  minBuyerCredit?: IntegerLike;
  prefixInstructions?: readonly TransactionInstruction[];
  /** Dusk execution sells the received collateral in the paired settle and
   * nets debt principal internally. External settlement requires route payment. */
  settlement?: "external" | "duskAmm";
  /** Defaults to the canonical hLP prefix for either venue, empty while no
   * hLP is active. Override when the route changes which hLP accounts
   * settlement requires; supply the complete ordered list for the final state. */
  settleRemainingAccounts?: readonly AccountMeta[];
  /** Builds the collateral sale, inventory payment, or mixed route. The
   * resulting instructions run after begin and before the exact paired settle.
   */
  route?: (context: FlashLiquidationRouteContext) => Promise<readonly TransactionInstruction[]> | readonly TransactionInstruction[];
}

export interface FlashLiquidationRouteContext {
  session: PublicKey;
  repaymentVault: PublicKey;
  buyerCollateralAccount: PublicKey;
  buyerDebtAccount: PublicKey;
  collateralMint: PublicKey;
  debtMint: PublicKey;
  debtTokenProgram: PublicKey;
  collateralTokenProgram: PublicKey;
  /** Route must deliver at least this net spendable amount into repaymentVault.
   * Settlement measures the vault's balance increase, so a fee-bearing debt
   * mint's inbound transfer fee comes out of whatever the route sends. */
  requiredPaymentCredit: bigint;
  /** The transfer into repaymentVault that credits `requiredPaymentCredit`
   * under the debt mint's transfer fee at `paymentTransferFee.epoch`. Equal to
   * `requiredPaymentCredit` for a mint without a fee and for `duskAmm`
   * settlement. It does not cover a fee that activates later: rebuild the plan
   * if the epoch changes before execution. */
  requiredPaymentGross: bigint;
  /** The debt mint's fee schedule `requiredPaymentGross` was computed from;
   * null for a legacy SPL mint and for `duskAmm` settlement. */
  paymentTransferFee: MintTransferFeeNotice | null;
  quote: FlashLiquidationQuote;
}

export interface EmergencyLiquidationParams extends LiquidationPositionParams {
  caller: AddressLike;
  collateralDebit: IntegerLike;
  full?: boolean;
  minRewardCredit?: IntegerLike;
  minSwapOutput?: IntegerLike;
  prefixInstructions?: readonly TransactionInstruction[];
}

function liquidationPrefix(instructions: readonly TransactionInstruction[] = []): TransactionInstruction[] {
  const prefix = [...instructions];
  if (!prefix.some(ix => ix.programId.equals(ComputeBudgetProgram.programId) && ix.data[0] === 1)) {
    prefix.unshift(ComputeBudgetProgram.requestHeapFrame({ bytes: 256 * 1024 }));
  }
  if (!prefix.some(ix => ix.programId.equals(ComputeBudgetProgram.programId) && ix.data[0] === 2)) {
    prefix.unshift(ComputeBudgetProgram.setComputeUnitLimit({ units: 1_400_000 }));
  }
  return prefix;
}

/** Fixed-payment liquidation helpers. No method signs or sends a transaction,
 * debits the owner's wallet, or chooses an external routing program.
 */
export class DuskLiquidations {
  readonly write: DuskWrite;
  readonly get: DuskGet;

  constructor(readonly program: Program<DuskIdl>, feePayer?: AddressLike) {
    this.write = new DuskWrite(program);
    this.get = new DuskGet(program, feePayer);
  }

  private async resolve(params: LiquidationPositionParams) {
    if (params.kind !== "borrow" && params.kind !== "leverage") throw new Error("Invalid position kind");
    if (params.debtAsset !== "base" && params.debtAsset !== "quote") throw new Error("Invalid debt asset");
    const market = address(params.market);
    const position = address(params.position);
    const [state, positionState] = await Promise.all([
      this.get.market(market),
      params.kind === "borrow" ? this.get.borrowPosition(position) : this.get.leveragePosition(position),
    ]);
    if (!positionState.market.equals(market)) throw new Error("Position belongs to another market");
    const debtAsset = params.debtAsset === "base" ? 0 : 1;
    if ("debtAsset" in positionState && positionState.debtAsset !== debtAsset) throw new Error("Wrong leverage debt side");
    const debtSide = debtAsset === 0 ? state.baseSide : state.quoteSide;
    const collateralSide = debtAsset === 0 ? state.quoteSide : state.baseSide;
    const readAccounts = { market, borrowPosition: params.kind === "borrow" ? position : null, leveragePosition: params.kind === "leverage" ? position : null, debtMint: debtSide.assetMint, collateralMint: collateralSide.assetMint };
    return { market, position, state, positionState, debtSide, collateralSide, debtAsset, readAccounts };
  }

  /** Monitor both sides: collateral fees affect health, debt fees affect payment.
   * Re-preview when refreshKey changes, including epoch changes without mint writes.
   * This read does not prove eligibility or reserve a price for a later transaction.
   */
  async transferFeeNotices(params: LiquidationPositionParams, minContextSlot?: number) {
    const r = await this.resolve(params);
    const snapshot = await fetchTransferFeeNotices(this.program.provider.connection,
      [r.debtSide.assetMint, r.collateralSide.assetMint], { minContextSlot });
    return { slot: snapshot.slot, epoch: snapshot.epoch, debt: snapshot.mints[0], collateral: snapshot.mints[1] };
  }

  /** Simulate current health without committing any observation or timer. */
  async previewHealth(params: LiquidationPositionParams): Promise<LiquidationHealth> {
    const resolved = await this.resolve(params);
    const instruction = await this.write.instruction("previewLiquidationHealth", [resolved.debtAsset], { accounts: resolved.readAccounts });
    const returned = await this.get.simulateReturnData(instruction);
    return this.program.coder.types.decode("liquidationHealth", previewReturnDataBytes(returned)) as LiquidationHealth;
  }

  /** Returns the executable discount after partial-health affordability checks.
   * The health-based ceiling alone must not be used to construct a payment or route.
   */
  async preview(params: LiquidationPositionParams & { maxRepayment: IntegerLike; full?: boolean }): Promise<FlashLiquidationQuote> {
    const resolved = await this.resolve(params);
    const instruction = await this.write.instruction("previewFlashLiquidation", {
      debtAsset: resolved.debtAsset, maxRepayment: integerBN(params.maxRepayment, "maxRepayment"), full: params.full ?? false,
    }, { accounts: resolved.readAccounts });
    const returned = await this.get.simulateReturnData(instruction);
    return this.program.coder.types.decode("flashLiquidationQuote", previewReturnDataBytes(returned)) as FlashLiquidationQuote;
  }

  /** Preview the paired Dusk-AMM route through the buyer's final debt-token
   * receipt. This includes both collateral transfers, AMM fees, liquidation
   * distributions, and the final debt-token transfer fee.
   */
  async previewAmm(params: LiquidationPositionParams & { maxRepayment: IntegerLike; full?: boolean }): Promise<FlashAmmLiquidationQuote> {
    const r = await this.resolve(params);
    const instruction = await this.write.instruction("previewFlashAmmLiquidation", {
      debtAsset: r.debtAsset, maxRepayment: integerBN(params.maxRepayment, "maxRepayment"), full: params.full ?? false,
    }, { accounts: { preview: r.readAccounts, futarchyAuthority: deriveFutarchyAuthorityAddress(this.program.programId)[0] } });
    const returned = await this.get.simulateReturnData(instruction);
    return this.program.coder.types.decode("flashAmmLiquidationQuote", previewReturnDataBytes(returned)) as FlashAmmLiquidationQuote;
  }

  /** Emergency inventory settlement uses the symmetric price EMA and smoothed
   * curve depth, including the configured concentration and full fee schedule.
   * referencePriceNad is debt per collateral (1e9); referenceDepthNad is curve depth,
   * not token atoms or TVL. swapOutput is credited settlement value, not a
   * live-spot trade quote. Eligibility remains linear symmetric-EMA health.
   * Full settlement requires either EMA insolvency or proof that no smaller
   * reference-priced settlement can restore MM + 2 points.
   * A useful below-target partial or external flash quote does not block it.
   * Proof failure remains a rejection; a failed requested slice is not evidence.
   */
  async previewEmergency(params: LiquidationPositionParams & { collateralDebit: IntegerLike; full?: boolean }): Promise<EmergencyLiquidationQuote> {
    const r = await this.resolve(params);
    const instruction = await this.write.instruction("previewEmergencyLiquidation", {
      debtAsset: r.debtAsset, collateralDebit: integerBN(params.collateralDebit, "collateralDebit"), full: params.full ?? false,
    }, { accounts: { preview: r.readAccounts, futarchyAuthority: deriveFutarchyAuthorityAddress(this.program.programId)[0] } });
    const returned = await this.get.simulateReturnData(instruction);
    return this.program.coder.types.decode("emergencyLiquidationQuote", previewReturnDataBytes(returned)) as EmergencyLiquidationQuote;
  }

  /** EMA inventory liquidation with partial recovery or the approved full fallback.
   * Uses the on-chain preview for sizing, full fees and loss allocation.
   * The program nets principal, pays only funded cash amounts, reconciles real
   * hLP balances and verifies the gates again during execution. The reference
   * returned here identifies the preview's inputs; it is not locked on-chain.
   * Explicit minimums protect the caller if the EMA/fee state changes.
   */
  async buildEmergency(params: EmergencyLiquidationParams) {
    const r = await this.resolve(params);
    const buyer = address(params.caller);
    const [debtTokenProgram, collateralTokenProgram, quote, remainingAccounts] = await Promise.all([
      tokenProgramForMint(this.program.provider.connection, r.debtSide.assetMint),
      tokenProgramForMint(this.program.provider.connection, r.collateralSide.assetMint),
      this.previewEmergency(params), this.write.hlpRemainingAccounts(r.market, r.state),
    ]);
    const buyerCollateralAccount = getAssociatedTokenAddressSync(r.collateralSide.assetMint, buyer, true, collateralTokenProgram);
    const buyerRefundAccount = getAssociatedTokenAddressSync(r.debtSide.assetMint, buyer, true, debtTokenProgram);
    const ownerDebtAccount = getAssociatedTokenAddressSync(r.debtSide.assetMint, r.positionState.owner, true, debtTokenProgram);
    const prefix = liquidationPrefix(params.prefixInstructions);
    const seen = new Set<string>();
    for (const [account, mint, owner, token] of [
      [buyerCollateralAccount, r.collateralSide.assetMint, buyer, collateralTokenProgram],
      [buyerRefundAccount, r.debtSide.assetMint, buyer, debtTokenProgram],
      [ownerDebtAccount, r.debtSide.assetMint, r.positionState.owner, debtTokenProgram],
    ]) {
      if (!seen.has(account.toBase58())) prefix.push(createAssociatedTokenAccountIdempotentInstruction(buyer, account, owner, mint, token));
      seen.add(account.toBase58());
    }
    const p = r.positionState;
    const partner = "referralPartner" in p ? p.referralPartner : r.debtAsset === 0 ? p.baseReferralPartner : p.quoteReferralPartner;
    const referralPartner = partner.equals(PublicKey.default) ? null : partner;
    const accounts = { ...r.readAccounts, buyer, buyerCollateralAccount, buyerRefundAccount, ownerDebtAccount,
      collateralVault: params.kind === "borrow" ? r.collateralSide.collateralVault : deriveLeverageCollateralVaultAddress(r.market, r.collateralSide.assetMint, this.program.programId)[0],
      reserveVault: r.debtSide.reserveVault,
      futarchyAuthority: deriveFutarchyAuthorityAddress(this.program.programId)[0], referralPartner,
      referralAccrual: referralPartner ? deriveReferralAccrualAddress(referralPartner, r.market, r.debtSide.assetMint, this.program.programId)[0] : null,
      tokenProgram: TOKEN_PROGRAM_ID, token2022Program: TOKEN_2022_PROGRAM_ID, debtTokenProgram };
    const instruction = await this.write.instruction("emergencyLiquidation", {
      debtAsset: r.debtAsset, collateralDebit: integerBN(params.collateralDebit, "collateralDebit"), full: params.full ?? false,
      minRewardCredit: integerBN(params.minRewardCredit ?? BigInt(quote.rewardCredit.toString()), "minRewardCredit"),
      minSwapOutput: integerBN(params.minSwapOutput ?? BigInt(quote.swapOutput.toString()), "minSwapOutput"),
    }, { accounts: { accounts, collateralReserveVault: r.collateralSide.reserveVault, instructions: SYSVAR_INSTRUCTIONS_PUBKEY }, remainingAccounts });
    return {
      quote, instruction, instructions: [...prefix, instruction],
      reference: {
        priceNad: BigInt(quote.referencePriceNad.toString()),
        depthNad: BigInt(quote.referenceDepthNad.toString()),
      },
      callerDebtAccount: buyerRefundAccount, ownerDebtAccount,
    };
  }

  /** Prefix + begin + caller's route + settle, with indices computed last.
   * Do not subsequently prepend/insert instructions; build another plan.
   * The persistent payment account retains withheld Token-2022 fees, avoiding
   * an invalid close-account CPI when the mint charges transfer fees.
   */
  async buildFlash(params: FlashLiquidationParams) {
    const internal = params.settlement === "duskAmm";
    if (params.settlement !== undefined && params.settlement !== "external" && !internal) throw new Error("Invalid flash settlement venue");
    if (!internal && !params.route) throw new Error("External settlement requires an explicit payment route");
    const r = await this.resolve(params);
    const buyer = address(params.buyer);
    const [debtTokenProgram, collateralTokenProgram, preview] = await Promise.all([
      tokenProgramForMint(this.program.provider.connection, r.debtSide.assetMint),
      tokenProgramForMint(this.program.provider.connection, r.collateralSide.assetMint),
      internal ? this.previewAmm(params) : this.preview(params),
    ]);
    const ammQuote = internal ? preview as FlashAmmLiquidationQuote : null;
    const quote = ammQuote ? ammQuote.liquidation : preview as FlashLiquidationQuote;
    const [session] = deriveLiquidationSessionAddress(r.position, this.program.programId);
    const [repaymentVault] = deriveLiquidationPaymentAddress(r.position, r.debtSide.assetMint, this.program.programId);
    const buyerCollateralAccount = getAssociatedTokenAddressSync(r.collateralSide.assetMint, buyer, true, collateralTokenProgram);
    const buyerDebtAccount = getAssociatedTokenAddressSync(r.debtSide.assetMint, buyer, true, debtTokenProgram);
    const ownerDebtAccount = getAssociatedTokenAddressSync(r.debtSide.assetMint, r.positionState.owner, true, debtTokenProgram);
    const prefix = liquidationPrefix(params.prefixInstructions);
    const seen = new Set<string>();
    for (const [account, mint, owner, token] of [
      [buyerCollateralAccount, r.collateralSide.assetMint, buyer, collateralTokenProgram],
      [buyerDebtAccount, r.debtSide.assetMint, buyer, debtTokenProgram],
      [ownerDebtAccount, r.debtSide.assetMint, r.positionState.owner, debtTokenProgram],
    ]) {
      if (!seen.has(account.toBase58())) prefix.push(createAssociatedTokenAccountIdempotentInstruction(buyer, account, owner, mint, token));
      seen.add(account.toBase58());
    }
    const requiredPaymentCredit = internal ? 0n : BigInt(quote.payment.toString());
    // Only a Token-2022 debt mint can charge the route's inbound transfer.
    const paymentTransferFee = internal || debtTokenProgram.equals(TOKEN_PROGRAM_ID) ? null
      : (await fetchTransferFeeNotices(this.program.provider.connection, [r.debtSide.assetMint])).mints[0];
    const fee = paymentTransferFee?.effective;
    const context: FlashLiquidationRouteContext = {
      session, repaymentVault, buyerCollateralAccount, buyerDebtAccount, debtTokenProgram, collateralTokenProgram,
      collateralMint: r.collateralSide.assetMint, debtMint: r.debtSide.assetMint,
      requiredPaymentCredit,
      requiredPaymentGross: fee
        ? grossLiquidationPayment(requiredPaymentCredit, { basisPoints: fee.transferFeeBasisPoints, maximumFee: fee.maximumFee })
        : requiredPaymentCredit,
      paymentTransferFee, quote,
    };
    const route = params.route ? [...await params.route(context)] : [];
    const beginIndex = prefix.length;
    const settleIndex = beginIndex + 1 + route.length;
    if (settleIndex > 65_535) throw new RangeError("Too many instructions for the bound settle index");
    const p = r.positionState;
    const partner = "referralPartner" in p ? p.referralPartner : r.debtAsset === 0 ? p.baseReferralPartner : p.quoteReferralPartner;
    const referralPartner = partner.equals(PublicKey.default) ? null : partner;
    const accounts = {
      ...r.readAccounts, buyer, buyerCollateralAccount, buyerRefundAccount: buyerDebtAccount, ownerDebtAccount,
      collateralVault: params.kind === "borrow" ? r.collateralSide.collateralVault : deriveLeverageCollateralVaultAddress(r.market, r.collateralSide.assetMint, this.program.programId)[0],
      reserveVault: r.debtSide.reserveVault,
      futarchyAuthority: deriveFutarchyAuthorityAddress(this.program.programId)[0], referralPartner,
      referralAccrual: referralPartner ? deriveReferralAccrualAddress(referralPartner, r.market, r.debtSide.assetMint, this.program.programId)[0] : null,
      tokenProgram: TOKEN_PROGRAM_ID, token2022Program: TOKEN_2022_PROGRAM_ID, debtTokenProgram,
    };
    const common = { accounts, session, repaymentVault, instructions: SYSVAR_INSTRUCTIONS_PUBKEY };
    const begin = await this.write.instruction("beginFlashLiquidation", {
      position: r.position, debtAsset: r.debtAsset, maxRepayment: integerBN(params.maxRepayment, "maxRepayment"),
      maxPayment: integerBN(params.maxPayment ?? BigInt(quote.payment.toString()), "maxPayment"),
      minCollateralCredit: integerBN(params.minCollateralCredit ?? BigInt(quote.collateralCredit.toString()), "minCollateralCredit"),
      minBuyerCredit: integerBN(internal ? params.minBuyerCredit ?? BigInt(ammQuote!.buyerCredit.toString()) : 0n, "minBuyerCredit"),
      full: params.full ?? false, settleIndex,
    }, { accounts: { ...common, systemProgram: SystemProgram.programId } });
    // Both venues can settle fresh public interest into an active hLP, which
    // reads the canonical prefix. It is empty while no hLP is active.
    const settle = await this.write.instruction("settleFlashLiquidation", [], {
      accounts: { ...common, collateralReserveVault: internal ? r.collateralSide.reserveVault : null },
      remainingAccounts: params.settleRemainingAccounts ? [...params.settleRemainingAccounts]
        : await this.write.hlpRemainingAccounts(r.market, r.state),
    });
    return { ...context, ammQuote, beginIndex, settleIndex, instructions: [...prefix, begin, ...route, settle], beginInstruction: begin, settleInstruction: settle };
  }
}
