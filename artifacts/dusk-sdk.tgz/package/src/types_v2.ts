/**
 * Program IDL in camelCase format in order to be used in JS/TS.
 *
 * Note that this is only a type helper and is not the actual IDL. The original
 * IDL can be found at `target/idl/dusk.json`.
 */
export type Dusk = {
  "address": "DuskWhswJYrzABDn8GqQD191X9RobRi5jhgGntXEdnKj",
  "metadata": {
    "name": "dusk",
    "version": "2.0.0",
    "spec": "0.1.0",
    "description": "Dusk market architecture program for Omnipair V2"
  },
  "instructions": [
    {
      "name": "addLeverageMargin",
      "discriminator": [
        56,
        245,
        65,
        29,
        221,
        125,
        238,
        241
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "positionOwner"
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "owner",
          "docs": [
            "Token payer; need not own the leverage position."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "addLeverageMarginArgs"
            }
          }
        }
      ]
    },
    {
      "name": "addLiquidity",
      "discriminator": [
        181,
        157,
        89,
        67,
        143,
        182,
        52,
        72
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "srlpMint",
          "writable": true
        },
        {
          "name": "baseReserveVault",
          "writable": true
        },
        {
          "name": "quoteReserveVault",
          "writable": true
        },
        {
          "name": "ownerBaseAccount",
          "writable": true
        },
        {
          "name": "ownerQuoteAccount",
          "writable": true
        },
        {
          "name": "ownerSrlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "docs": [
            "any liquidity mutation."
          ],
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "docs": [
            "any liquidity mutation."
          ],
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "addLiquidityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "announceOperatorChange",
      "docs": [
        "Announce one atomic change. An optional manager may propose parameters only; LP balances grant no authority."
      ],
      "discriminator": [
        119,
        10,
        131,
        39,
        87,
        242,
        115,
        110
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "operator",
          "signer": true
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "proposal",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  111,
                  112,
                  101,
                  114,
                  97,
                  116,
                  111,
                  114,
                  95,
                  99,
                  104,
                  97,
                  110,
                  103,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "arg",
                "path": "args.nonce"
              }
            ]
          }
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "announceOperatorChangeArgs"
            }
          }
        }
      ]
    },
    {
      "name": "beginFlashLiquidation",
      "discriminator": [
        18,
        242,
        47,
        42,
        203,
        45,
        98,
        252
      ],
      "accounts": [
        {
          "name": "accounts",
          "accounts": [
            {
              "name": "market",
              "writable": true,
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      109,
                      97,
                      114,
                      107,
                      101,
                      116,
                      95,
                      118,
                      50
                    ]
                  },
                  {
                    "kind": "account",
                    "path": "market.base_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.quote_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.params_hash",
                    "account": "market"
                  }
                ]
              }
            },
            {
              "name": "borrowPosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "leveragePosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "buyer",
              "writable": true,
              "signer": true
            },
            {
              "name": "collateralMint"
            },
            {
              "name": "debtMint"
            },
            {
              "name": "collateralVault",
              "writable": true
            },
            {
              "name": "reserveVault",
              "writable": true
            },
            {
              "name": "buyerCollateralAccount",
              "writable": true
            },
            {
              "name": "buyerRefundAccount",
              "writable": true
            },
            {
              "name": "ownerDebtAccount",
              "writable": true
            },
            {
              "name": "futarchyAuthority",
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      102,
                      117,
                      116,
                      97,
                      114,
                      99,
                      104,
                      121,
                      95,
                      97,
                      117,
                      116,
                      104,
                      111,
                      114,
                      105,
                      116,
                      121
                    ]
                  }
                ]
              }
            },
            {
              "name": "referralPartner",
              "optional": true
            },
            {
              "name": "referralAccrual",
              "writable": true,
              "optional": true
            },
            {
              "name": "tokenProgram",
              "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            },
            {
              "name": "token2022Program",
              "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
            },
            {
              "name": "debtTokenProgram"
            }
          ]
        },
        {
          "name": "session",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  105,
                  113,
                  117,
                  105,
                  100,
                  97,
                  116,
                  105,
                  111,
                  110,
                  45,
                  115,
                  101,
                  115,
                  115,
                  105,
                  111,
                  110
                ]
              },
              {
                "kind": "arg",
                "path": "args.position"
              }
            ]
          }
        },
        {
          "name": "repaymentVault",
          "docs": [
            "session authority and token-program owner with the extension-aware helper."
          ],
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  105,
                  113,
                  117,
                  105,
                  100,
                  97,
                  116,
                  105,
                  111,
                  110,
                  45,
                  112,
                  97,
                  121,
                  109,
                  101,
                  110,
                  116
                ]
              },
              {
                "kind": "arg",
                "path": "args.position"
              },
              {
                "kind": "account",
                "path": "accounts.debt_mint",
                "account": "flashLiquidationAccounts"
              }
            ]
          }
        },
        {
          "name": "instructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "beginFlashLiquidationArgs"
            }
          }
        }
      ]
    },
    {
      "name": "beginHlpFlash",
      "docs": [
        "Release hLP target collateral, bound to an exact top-level settlement",
        "later in this same transaction. No routing program is privileged."
      ],
      "discriminator": [
        41,
        207,
        247,
        103,
        180,
        58,
        131,
        13
      ],
      "accounts": [
        {
          "name": "accounts",
          "accounts": [
            {
              "name": "market",
              "writable": true
            },
            {
              "name": "futarchyAuthority"
            },
            {
              "name": "buyer",
              "writable": true,
              "signer": true
            },
            {
              "name": "targetMint"
            },
            {
              "name": "borrowedMint"
            },
            {
              "name": "targetReserve",
              "writable": true
            },
            {
              "name": "borrowedReserve",
              "writable": true
            },
            {
              "name": "buyerCollateralAccount",
              "writable": true
            },
            {
              "name": "buyerRefundAccount",
              "writable": true
            },
            {
              "name": "tokenProgram",
              "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            },
            {
              "name": "token2022Program",
              "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
            },
            {
              "name": "borrowedTokenProgram"
            }
          ]
        },
        {
          "name": "session",
          "writable": true
        },
        {
          "name": "repaymentVault",
          "docs": [
            "session authority and token-program owner with the extension-aware helper."
          ],
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  45,
                  102,
                  108,
                  97,
                  115,
                  104,
                  45,
                  112,
                  97,
                  121,
                  109,
                  101,
                  110,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "session"
              }
            ]
          }
        },
        {
          "name": "instructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "beginHlpFlashArgs"
            }
          }
        }
      ]
    },
    {
      "name": "borrow",
      "discriminator": [
        228,
        253,
        131,
        202,
        207,
        116,
        89,
        18
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "debtAssetMint"
        },
        {
          "name": "collateralAssetMint"
        },
        {
          "name": "reserveVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "optional": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "borrowArgs"
            }
          }
        }
      ]
    },
    {
      "name": "burnRetiredHlpReceipt",
      "discriminator": [
        186,
        145,
        76,
        141,
        32,
        30,
        63,
        95
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "retiredMint",
          "writable": true
        },
        {
          "name": "cohort",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  95,
                  99,
                  111,
                  104,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "retiredMint"
              }
            ]
          }
        },
        {
          "name": "ownerHlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "burnRetiredHlpReceiptArgs"
            }
          }
        }
      ]
    },
    {
      "name": "burnRetiredJunior",
      "discriminator": [
        180,
        25,
        139,
        146,
        47,
        20,
        168,
        135
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "signer": true
        },
        {
          "name": "retiredMint",
          "writable": true
        },
        {
          "name": "cohort",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  106,
                  117,
                  110,
                  105,
                  111,
                  114,
                  95,
                  99,
                  111,
                  104,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "retiredMint"
              }
            ]
          }
        },
        {
          "name": "ownerJunior",
          "writable": true
        },
        {
          "name": "baseYield",
          "writable": true
        },
        {
          "name": "quoteYield",
          "writable": true
        },
        {
          "name": "exit",
          "writable": true,
          "optional": true
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "burnRetiredJuniorArgs"
            }
          }
        }
      ]
    },
    {
      "name": "claimOperatorRevenue",
      "docs": [
        "Permissionlessly pay earned interest fees to the immutable recipient ATA."
      ],
      "discriminator": [
        189,
        47,
        169,
        137,
        23,
        73,
        221,
        37
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "revenue",
          "writable": true,
          "optional": true
        },
        {
          "name": "recipient"
        },
        {
          "name": "assetMint"
        },
        {
          "name": "reserveVault",
          "writable": true
        },
        {
          "name": "recipientAssetAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "claimOperatorRevenueArgs"
            }
          }
        }
      ]
    },
    {
      "name": "claimReferralInterest",
      "discriminator": [
        16,
        89,
        1,
        198,
        140,
        72,
        89,
        13
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "authority",
          "writable": true,
          "signer": true
        },
        {
          "name": "referralPartner",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  112,
                  97,
                  114,
                  116,
                  110,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "authority"
              }
            ]
          }
        },
        {
          "name": "assetMint"
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  97,
                  99,
                  99,
                  114,
                  117,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "referralPartner"
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "assetMint"
              }
            ]
          }
        },
        {
          "name": "reserveVault",
          "writable": true
        },
        {
          "name": "recipientTokenAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "closeInsolventHlp",
      "docs": [
        "Permissionlessly closes an hLP whose current-slot symmetric-EMA backing",
        "cannot cover funding debt. Native recovery uses EMA price, smoothed depth,",
        "concentration and configured fees. Recovery protects principal first;",
        "junior absorbs principal loss before senior; unpaid interest is canceled.",
        "Interest the vault held while frozen counts as recovery. The bounded",
        "caller reward and the protocol share of the funding paid take only what",
        "borrowed-asset cash allows. Existing funded holder claims remain",
        "claimable after cleanup."
      ],
      "discriminator": [
        158,
        172,
        48,
        134,
        121,
        161,
        194,
        168
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "caller",
          "writable": true,
          "signer": true
        },
        {
          "name": "borrowedMint"
        },
        {
          "name": "borrowedReserveVault",
          "writable": true
        },
        {
          "name": "callerBountyAccount",
          "writable": true
        },
        {
          "name": "srlpMint",
          "writable": true
        },
        {
          "name": "targetHlpSrlpVault",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "closeInsolventHlpArgs"
            }
          }
        }
      ]
    },
    {
      "name": "closeLeverage",
      "discriminator": [
        45,
        157,
        207,
        176,
        194,
        6,
        218,
        253
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "positionOwner",
          "writable": true
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "leverageCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "collateralMint"
              }
            ]
          }
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "delegateFeeRecipient",
          "docs": [
            "Protocol treasury token account for delegated close order fees."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "delegateExecutorAccount",
          "docs": [
            "Executor-owned token account for delegated close incentives."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "leverageDelegation",
          "optional": true
        },
        {
          "name": "delegatedProgram",
          "optional": true
        },
        {
          "name": "authority",
          "writable": true,
          "signer": true
        },
        {
          "name": "instructionsSysvar",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "closeLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "closeLeverageDelegation",
      "discriminator": [
        252,
        151,
        253,
        52,
        242,
        118,
        104,
        109
      ],
      "accounts": [
        {
          "name": "leverageDelegation",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  100,
                  101,
                  108,
                  101,
                  103,
                  97,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "arg",
                "path": "args.position"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "closeLeverageDelegationArgs"
            }
          }
        }
      ]
    },
    {
      "name": "compoundJuniorSeed",
      "discriminator": [
        145,
        120,
        244,
        44,
        0,
        37,
        243,
        36
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "juniorMint"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "configureProtocolAuction",
      "discriminator": [
        169,
        178,
        239,
        169,
        228,
        103,
        127,
        127
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "configureProtocolAuctionArgs"
            }
          }
        }
      ]
    },
    {
      "name": "configureReferralPartner",
      "discriminator": [
        36,
        179,
        42,
        204,
        66,
        161,
        198,
        254
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "referralPartner",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  112,
                  97,
                  114,
                  116,
                  110,
                  101,
                  114
                ]
              },
              {
                "kind": "arg",
                "path": "args.referrer"
              }
            ]
          }
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "configureReferralPartnerArgs"
            }
          }
        }
      ]
    },
    {
      "name": "convertTranche",
      "discriminator": [
        192,
        218,
        132,
        202,
        247,
        23,
        75,
        230
      ],
      "accounts": [
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "seniorMint",
          "writable": true
        },
        {
          "name": "juniorMint",
          "writable": true
        },
        {
          "name": "ownerSenior",
          "writable": true
        },
        {
          "name": "ownerJunior",
          "writable": true
        },
        {
          "name": "exit",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  106,
                  117,
                  110,
                  105,
                  111,
                  114,
                  95,
                  101,
                  120,
                  105,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "owner"
              },
              {
                "kind": "account",
                "path": "juniorMint"
              }
            ]
          }
        },
        {
          "name": "seniorBaseYield",
          "writable": true
        },
        {
          "name": "seniorQuoteYield",
          "writable": true
        },
        {
          "name": "juniorBaseYield",
          "writable": true
        },
        {
          "name": "juniorQuoteYield",
          "writable": true
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "action",
          "type": {
            "defined": {
              "name": "trancheAction"
            }
          }
        }
      ]
    },
    {
      "name": "createLeverageDelegation",
      "discriminator": [
        189,
        154,
        156,
        116,
        213,
        249,
        107,
        163
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "leveragePosition",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "leverageDelegation",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  100,
                  101,
                  108,
                  101,
                  103,
                  97,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "createLeverageDelegationArgs"
            }
          }
        }
      ]
    },
    {
      "name": "decreaseLeverage",
      "discriminator": [
        177,
        163,
        187,
        72,
        82,
        174,
        68,
        229
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "positionOwner"
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "leverageCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "collateralMint"
              }
            ]
          }
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "instructionsSysvar",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "decreaseLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "delegatedCloseLeverage",
      "discriminator": [
        14,
        218,
        98,
        153,
        164,
        19,
        48,
        139
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "positionOwner",
          "writable": true
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "leverageCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "collateralMint"
              }
            ]
          }
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "delegateFeeRecipient",
          "docs": [
            "Protocol treasury token account for delegated close order fees."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "delegateExecutorAccount",
          "docs": [
            "Executor-owned token account for delegated close incentives."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "leverageDelegation",
          "optional": true
        },
        {
          "name": "delegatedProgram",
          "optional": true
        },
        {
          "name": "authority",
          "writable": true,
          "signer": true
        },
        {
          "name": "instructionsSysvar",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "delegatedCloseLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "depositCollateral",
      "discriminator": [
        156,
        131,
        142,
        116,
        146,
        247,
        162,
        120
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "collateralVault",
          "writable": true
        },
        {
          "name": "ownerAssetAccount",
          "writable": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "owner"
              },
              {
                "kind": "arg",
                "path": "args.position_id"
              }
            ]
          }
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "depositCollateralArgs"
            }
          }
        }
      ]
    },
    {
      "name": "depositSingleSided",
      "discriminator": [
        5,
        14,
        149,
        170,
        183,
        103,
        225,
        105
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "srlpMint",
          "writable": true
        },
        {
          "name": "targetHlpMint",
          "writable": true
        },
        {
          "name": "baseReserveVault",
          "writable": true
        },
        {
          "name": "quoteReserveVault",
          "writable": true
        },
        {
          "name": "ownerTargetAccount",
          "writable": true
        },
        {
          "name": "ownerHlpAccount",
          "writable": true
        },
        {
          "name": "hlpSrlpAccount",
          "docs": [
            "authority are all validated before any market mutation. A System-owned",
            "empty PDA is initialized inline by the deposit handler."
          ],
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "depositSingleSidedArgs"
            }
          }
        }
      ]
    },
    {
      "name": "donateCollateral",
      "docs": [
        "Adds the signer's tokens to an existing borrow position without granting",
        "the donor ownership or withdrawal rights. The recorded owner is unchanged."
      ],
      "discriminator": [
        237,
        234,
        205,
        84,
        177,
        106,
        198,
        38
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "collateralVault",
          "writable": true
        },
        {
          "name": "ownerAssetAccount",
          "writable": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "donateCollateralArgs"
            }
          }
        }
      ]
    },
    {
      "name": "emergencyLiquidation",
      "discriminator": [
        24,
        95,
        118,
        136,
        77,
        194,
        44,
        247
      ],
      "accounts": [
        {
          "name": "accounts",
          "accounts": [
            {
              "name": "market",
              "writable": true,
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      109,
                      97,
                      114,
                      107,
                      101,
                      116,
                      95,
                      118,
                      50
                    ]
                  },
                  {
                    "kind": "account",
                    "path": "market.base_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.quote_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.params_hash",
                    "account": "market"
                  }
                ]
              }
            },
            {
              "name": "borrowPosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "leveragePosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "buyer",
              "writable": true,
              "signer": true
            },
            {
              "name": "collateralMint"
            },
            {
              "name": "debtMint"
            },
            {
              "name": "collateralVault",
              "writable": true
            },
            {
              "name": "reserveVault",
              "writable": true
            },
            {
              "name": "buyerCollateralAccount",
              "writable": true
            },
            {
              "name": "buyerRefundAccount",
              "writable": true
            },
            {
              "name": "ownerDebtAccount",
              "writable": true
            },
            {
              "name": "futarchyAuthority",
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      102,
                      117,
                      116,
                      97,
                      114,
                      99,
                      104,
                      121,
                      95,
                      97,
                      117,
                      116,
                      104,
                      111,
                      114,
                      105,
                      116,
                      121
                    ]
                  }
                ]
              }
            },
            {
              "name": "referralPartner",
              "optional": true
            },
            {
              "name": "referralAccrual",
              "writable": true,
              "optional": true
            },
            {
              "name": "tokenProgram",
              "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            },
            {
              "name": "token2022Program",
              "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
            },
            {
              "name": "debtTokenProgram"
            }
          ]
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "instructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "emergencyLiquidationArgs"
            }
          }
        }
      ]
    },
    {
      "name": "executeOperatorChange",
      "docs": [
        "Permissionless execution after the full exit notice. A new authority accepts a handoff by signing."
      ],
      "discriminator": [
        114,
        146,
        27,
        116,
        61,
        134,
        151,
        35
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          },
          "relations": [
            "proposal"
          ]
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "proposal",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  111,
                  112,
                  101,
                  114,
                  97,
                  116,
                  111,
                  114,
                  95,
                  99,
                  104,
                  97,
                  110,
                  103,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "proposal.nonce",
                "account": "operatorProposal"
              }
            ]
          }
        },
        {
          "name": "acceptingOperator",
          "signer": true,
          "optional": true
        },
        {
          "name": "previousRevenue",
          "writable": true,
          "optional": true
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "fundJuniorSeed",
      "discriminator": [
        245,
        198,
        220,
        232,
        96,
        64,
        51,
        71
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "assetMint"
        },
        {
          "name": "reserveVault"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "harvest",
      "discriminator": [
        228,
        241,
        31,
        182,
        53,
        169,
        59,
        199
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "docs": [
            "LP holder identity. Its signature is not required when the designated",
            "recipient or harvest authority signs instead."
          ]
        },
        {
          "name": "caller",
          "docs": [
            "The LP holder, designated recipient, or harvest authority. Checked in validation."
          ],
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "lpMint"
        },
        {
          "name": "ownerLpAccount",
          "writable": true
        },
        {
          "name": "reserveVault",
          "writable": true
        },
        {
          "name": "recipientAssetAccount",
          "writable": true
        },
        {
          "name": "yieldAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "harvestArgs"
            }
          }
        }
      ]
    },
    {
      "name": "increaseLeverage",
      "discriminator": [
        61,
        30,
        86,
        173,
        5,
        127,
        12,
        160
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "positionOwner"
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "leverageCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "collateralMint"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "ownerDebtAccount",
          "docs": [
            "Required only when margin_amount is positive; always owned by the position owner."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "instructionsSysvar",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "increaseLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "initFutarchyAuthority",
      "discriminator": [
        133,
        110,
        154,
        29,
        240,
        206,
        71,
        100
      ],
      "accounts": [
        {
          "name": "deployer",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "programData",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  191,
                  215,
                  212,
                  33,
                  74,
                  68,
                  126,
                  168,
                  251,
                  64,
                  60,
                  251,
                  142,
                  177,
                  167,
                  146,
                  144,
                  83,
                  163,
                  155,
                  161,
                  57,
                  93,
                  175,
                  240,
                  188,
                  80,
                  198,
                  110,
                  6,
                  64,
                  2
                ]
              }
            ],
            "program": {
              "kind": "const",
              "value": [
                2,
                168,
                246,
                145,
                78,
                136,
                161,
                176,
                226,
                16,
                21,
                62,
                247,
                99,
                174,
                43,
                0,
                194,
                185,
                61,
                22,
                193,
                36,
                210,
                192,
                83,
                122,
                16,
                4,
                128,
                0,
                0
              ]
            }
          }
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "initFutarchyAuthorityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "initializeJunior",
      "discriminator": [
        179,
        239,
        121,
        100,
        88,
        74,
        12,
        66
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "juniorMint",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  106,
                  117,
                  110,
                  105,
                  111,
                  114,
                  95,
                  109,
                  105,
                  110,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "arg",
                "path": "args.generation"
              }
            ]
          }
        },
        {
          "name": "cohort",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  106,
                  117,
                  110,
                  105,
                  111,
                  114,
                  95,
                  99,
                  111,
                  104,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "juniorMint"
              }
            ]
          }
        },
        {
          "name": "previousCohort",
          "writable": true,
          "optional": true
        },
        {
          "name": "tokenMetadata",
          "writable": true
        },
        {
          "name": "sysvarInstructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenMetadataProgram",
          "address": "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "initializeJuniorArgs"
            }
          }
        }
      ]
    },
    {
      "name": "initializeLpTransferHook",
      "discriminator": [
        207,
        57,
        218,
        104,
        179,
        156,
        22,
        196
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "market"
        },
        {
          "name": "lpMint"
        },
        {
          "name": "validationAccount",
          "docs": [
            "against `lp_mint` and owned by Dusk after initialization."
          ],
          "writable": true
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        }
      ],
      "args": []
    },
    {
      "name": "initializeMarket",
      "discriminator": [
        35,
        35,
        189,
        193,
        155,
        48,
        170,
        203
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "srlpMint",
          "writable": true
        },
        {
          "name": "baseHlpMint",
          "writable": true
        },
        {
          "name": "quoteHlpMint",
          "writable": true
        },
        {
          "name": "srlpTokenMetadata",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  101,
                  116,
                  97,
                  100,
                  97,
                  116,
                  97
                ]
              },
              {
                "kind": "const",
                "value": [
                  11,
                  112,
                  101,
                  177,
                  227,
                  209,
                  124,
                  69,
                  56,
                  157,
                  82,
                  127,
                  107,
                  4,
                  195,
                  205,
                  88,
                  184,
                  108,
                  115,
                  26,
                  160,
                  253,
                  181,
                  73,
                  182,
                  209,
                  188,
                  3,
                  248,
                  41,
                  70
                ]
              },
              {
                "kind": "account",
                "path": "srlpMint"
              }
            ],
            "program": {
              "kind": "const",
              "value": [
                11,
                112,
                101,
                177,
                227,
                209,
                124,
                69,
                56,
                157,
                82,
                127,
                107,
                4,
                195,
                205,
                88,
                184,
                108,
                115,
                26,
                160,
                253,
                181,
                73,
                182,
                209,
                188,
                3,
                248,
                41,
                70
              ]
            }
          }
        },
        {
          "name": "baseHlpTokenMetadata",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  101,
                  116,
                  97,
                  100,
                  97,
                  116,
                  97
                ]
              },
              {
                "kind": "const",
                "value": [
                  11,
                  112,
                  101,
                  177,
                  227,
                  209,
                  124,
                  69,
                  56,
                  157,
                  82,
                  127,
                  107,
                  4,
                  195,
                  205,
                  88,
                  184,
                  108,
                  115,
                  26,
                  160,
                  253,
                  181,
                  73,
                  182,
                  209,
                  188,
                  3,
                  248,
                  41,
                  70
                ]
              },
              {
                "kind": "account",
                "path": "baseHlpMint"
              }
            ],
            "program": {
              "kind": "const",
              "value": [
                11,
                112,
                101,
                177,
                227,
                209,
                124,
                69,
                56,
                157,
                82,
                127,
                107,
                4,
                195,
                205,
                88,
                184,
                108,
                115,
                26,
                160,
                253,
                181,
                73,
                182,
                209,
                188,
                3,
                248,
                41,
                70
              ]
            }
          }
        },
        {
          "name": "quoteHlpTokenMetadata",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  101,
                  116,
                  97,
                  100,
                  97,
                  116,
                  97
                ]
              },
              {
                "kind": "const",
                "value": [
                  11,
                  112,
                  101,
                  177,
                  227,
                  209,
                  124,
                  69,
                  56,
                  157,
                  82,
                  127,
                  107,
                  4,
                  195,
                  205,
                  88,
                  184,
                  108,
                  115,
                  26,
                  160,
                  253,
                  181,
                  73,
                  182,
                  209,
                  188,
                  3,
                  248,
                  41,
                  70
                ]
              },
              {
                "kind": "account",
                "path": "quoteHlpMint"
              }
            ],
            "program": {
              "kind": "const",
              "value": [
                11,
                112,
                101,
                177,
                227,
                209,
                124,
                69,
                56,
                157,
                82,
                127,
                107,
                4,
                195,
                205,
                88,
                184,
                108,
                115,
                26,
                160,
                253,
                181,
                73,
                182,
                209,
                188,
                3,
                248,
                41,
                70
              ]
            }
          }
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "baseMint"
              },
              {
                "kind": "account",
                "path": "quoteMint"
              },
              {
                "kind": "arg",
                "path": "args.params_hash"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "baseReserveVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  114,
                  101,
                  115,
                  101,
                  114,
                  118,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "baseMint"
              }
            ]
          }
        },
        {
          "name": "quoteReserveVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  114,
                  101,
                  115,
                  101,
                  114,
                  118,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "quoteMint"
              }
            ]
          }
        },
        {
          "name": "baseCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "baseMint"
              }
            ]
          }
        },
        {
          "name": "quoteCollateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "quoteMint"
              }
            ]
          }
        },
        {
          "name": "teamTreasury"
        },
        {
          "name": "teamTreasuryWsolAccount",
          "writable": true
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "sysvarInstructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenMetadataProgram",
          "address": "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "initializeMarketArgs"
            }
          }
        }
      ]
    },
    {
      "name": "initializeOperatorRevenue",
      "docs": [
        "Prepare a recipient archive with a separate funded payer."
      ],
      "discriminator": [
        112,
        210,
        185,
        8,
        90,
        215,
        15,
        41
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "revenue",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  111,
                  112,
                  101,
                  114,
                  97,
                  116,
                  111,
                  114,
                  95,
                  114,
                  101,
                  118,
                  101,
                  110,
                  117,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "market.operator.revenue_epoch",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        }
      ],
      "args": []
    },
    {
      "name": "initializeReferralAccrual",
      "discriminator": [
        176,
        126,
        1,
        176,
        59,
        177,
        15,
        82
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "referralPartner",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  112,
                  97,
                  114,
                  116,
                  110,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "referral_partner.authority",
                "account": "referralPartner"
              }
            ]
          }
        },
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "assetMint"
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  97,
                  99,
                  99,
                  114,
                  117,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "referralPartner"
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "assetMint"
              }
            ]
          }
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        }
      ],
      "args": []
    },
    {
      "name": "initializeYieldAccounts",
      "discriminator": [
        236,
        172,
        68,
        27,
        9,
        165,
        181,
        4
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "lpMint"
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "initializeYieldAccountsArgs"
            }
          }
        }
      ]
    },
    {
      "name": "openLeverage",
      "discriminator": [
        182,
        198,
        96,
        61,
        133,
        28,
        41,
        16
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "payer",
          "docs": [
            "Pays account rent. Ordinary opens pass `owner` again; delegated opens",
            "use the keeper without transferring position ownership to it."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "leveragePosition",
          "docs": [
            "validated before any economic mutation."
          ],
          "writable": true
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "writable": true
        },
        {
          "name": "leverageCollateralVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "optional": true
        },
        {
          "name": "instructionsSysvar",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "openLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "openLiquidityGates",
      "docs": [
        "Permissionless launch adapters use the same fully-backed seeding path",
        "as ordinary srLP deposits. The initializer is the one-shot authority;",
        "after this succeeds, subsequent liquidity is permissionless."
      ],
      "discriminator": [
        84,
        83,
        110,
        45,
        185,
        4,
        186,
        222
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "srlpMint",
          "writable": true
        },
        {
          "name": "baseReserveVault",
          "writable": true
        },
        {
          "name": "quoteReserveVault",
          "writable": true
        },
        {
          "name": "ownerBaseAccount",
          "writable": true
        },
        {
          "name": "ownerQuoteAccount",
          "writable": true
        },
        {
          "name": "ownerSrlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "docs": [
            "any liquidity mutation."
          ],
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "docs": [
            "any liquidity mutation."
          ],
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "addLiquidityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "previewAddLiquidity",
      "discriminator": [
        109,
        110,
        51,
        225,
        17,
        58,
        243,
        255
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewAddLiquidityArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "addLiquidityPreview"
        }
      }
    },
    {
      "name": "previewBorrowCapacity",
      "discriminator": [
        203,
        170,
        28,
        79,
        32,
        180,
        177,
        70
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "collateralAssetMint"
        },
        {
          "name": "debtAssetMint"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewBorrowCapacityArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "borrowCapacityPreview"
        }
      }
    },
    {
      "name": "previewBorrowPosition",
      "discriminator": [
        240,
        236,
        45,
        30,
        172,
        146,
        45,
        163
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "borrowPosition",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "baseMint",
          "docs": [
            "Liquidation values each side's collateral after its mint's current",
            "transfer fee, so the preview reads both mints."
          ]
        },
        {
          "name": "quoteMint"
        }
      ],
      "args": [],
      "returns": {
        "defined": {
          "name": "borrowPositionPreview"
        }
      }
    },
    {
      "name": "previewBorrowPositionCapacity",
      "discriminator": [
        117,
        63,
        148,
        138,
        201,
        37,
        189,
        1
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "borrowPosition",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "collateralAssetMint"
        },
        {
          "name": "debtAssetMint"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewBorrowPositionCapacityArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "borrowPositionCapacityPreview"
        }
      }
    },
    {
      "name": "previewEmergencyLiquidation",
      "discriminator": [
        75,
        200,
        66,
        0,
        112,
        230,
        24,
        56
      ],
      "accounts": [
        {
          "name": "preview",
          "accounts": [
            {
              "name": "market",
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      109,
                      97,
                      114,
                      107,
                      101,
                      116,
                      95,
                      118,
                      50
                    ]
                  },
                  {
                    "kind": "account",
                    "path": "market.base_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.quote_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.params_hash",
                    "account": "market"
                  }
                ]
              }
            },
            {
              "name": "borrowPosition",
              "optional": true
            },
            {
              "name": "leveragePosition",
              "optional": true
            },
            {
              "name": "collateralMint"
            },
            {
              "name": "debtMint"
            }
          ]
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewEmergencyLiquidationArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "emergencyLiquidationQuote"
        }
      }
    },
    {
      "name": "previewFlashAmmLiquidation",
      "docs": [
        "Preview the final debt-token payout when the paired Dusk AMM funds an",
        "atomic flash liquidation settlement."
      ],
      "discriminator": [
        219,
        117,
        70,
        133,
        93,
        227,
        129,
        173
      ],
      "accounts": [
        {
          "name": "preview",
          "accounts": [
            {
              "name": "market",
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      109,
                      97,
                      114,
                      107,
                      101,
                      116,
                      95,
                      118,
                      50
                    ]
                  },
                  {
                    "kind": "account",
                    "path": "market.base_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.quote_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.params_hash",
                    "account": "market"
                  }
                ]
              }
            },
            {
              "name": "borrowPosition",
              "optional": true
            },
            {
              "name": "leveragePosition",
              "optional": true
            },
            {
              "name": "collateralMint"
            },
            {
              "name": "debtMint"
            }
          ]
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewFlashAmmLiquidationArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "flashAmmLiquidationQuote"
        }
      }
    },
    {
      "name": "previewFlashLiquidation",
      "discriminator": [
        238,
        94,
        122,
        243,
        214,
        175,
        246,
        3
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "borrowPosition",
          "optional": true
        },
        {
          "name": "leveragePosition",
          "optional": true
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtMint"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewFlashLiquidationArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "flashLiquidationQuote"
        }
      }
    },
    {
      "name": "previewHlpDepositCapacity",
      "discriminator": [
        183,
        4,
        20,
        188,
        148,
        193,
        129,
        195
      ],
      "accounts": [
        {
          "name": "market"
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "targetHlpMint"
        }
      ],
      "args": [],
      "returns": {
        "defined": {
          "name": "hlpDepositCapacityPreview"
        }
      }
    },
    {
      "name": "previewHlpFlash",
      "docs": [
        "Quote the fixed net payment for vault-wide atomic external hLP recovery."
      ],
      "discriminator": [
        26,
        164,
        118,
        84,
        231,
        86,
        157,
        176
      ],
      "accounts": [
        {
          "name": "market"
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "targetMint"
        },
        {
          "name": "borrowedMint"
        }
      ],
      "args": [
        {
          "name": "targetAsset",
          "type": "u8"
        }
      ],
      "returns": {
        "defined": {
          "name": "hlpFlashQuote"
        }
      }
    },
    {
      "name": "previewHlpOrderTrigger",
      "discriminator": [
        98,
        114,
        204,
        124,
        206,
        245,
        4,
        57
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewHlpOrderTriggerArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "hlpOrderTriggerPreview"
        }
      }
    },
    {
      "name": "previewLiquidationHealth",
      "docs": [
        "Read current liquidation health without starting an episode or mutating accounts."
      ],
      "discriminator": [
        123,
        158,
        120,
        122,
        95,
        28,
        6,
        172
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "borrowPosition",
          "optional": true
        },
        {
          "name": "leveragePosition",
          "optional": true
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtMint"
        }
      ],
      "args": [
        {
          "name": "debtAsset",
          "type": "u8"
        }
      ],
      "returns": {
        "defined": {
          "name": "liquidationHealth"
        }
      }
    },
    {
      "name": "previewMarket",
      "discriminator": [
        60,
        231,
        175,
        17,
        28,
        221,
        42,
        236
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        }
      ],
      "args": [],
      "returns": {
        "defined": {
          "name": "marketPreview"
        }
      }
    },
    {
      "name": "previewSwap",
      "discriminator": [
        98,
        74,
        197,
        115,
        135,
        154,
        188,
        70
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "assetInMint"
        },
        {
          "name": "assetOutMint"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "previewSwapArgs"
            }
          }
        }
      ],
      "returns": {
        "defined": {
          "name": "swapPreview"
        }
      }
    },
    {
      "name": "removeLiquidity",
      "discriminator": [
        80,
        85,
        209,
        72,
        24,
        206,
        177,
        108
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "srlpMint",
          "writable": true
        },
        {
          "name": "baseReserveVault",
          "writable": true
        },
        {
          "name": "quoteReserveVault",
          "writable": true
        },
        {
          "name": "ownerBaseAccount",
          "writable": true
        },
        {
          "name": "ownerQuoteAccount",
          "writable": true
        },
        {
          "name": "ownerSrlpAccount",
          "writable": true
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "removeLiquidityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "removeMarketManager",
      "docs": [
        "Immediately revoke the optional manager and its pending change, preserving owner announcements."
      ],
      "discriminator": [
        241,
        96,
        2,
        41,
        224,
        50,
        155,
        174
      ],
      "accounts": [
        {
          "name": "operator",
          "signer": true
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "repay",
      "discriminator": [
        234,
        103,
        67,
        82,
        208,
        234,
        219,
        166
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "docs": [
            "Token payer; need not own the borrow position."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "debtAssetMint"
        },
        {
          "name": "collateralAssetMint"
        },
        {
          "name": "reserveVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "repayArgs"
            }
          }
        }
      ]
    },
    {
      "name": "repayLeverage",
      "docs": [
        "Repays leverage from the signer's tokens without quoting or selling collateral.",
        "The update event's closeout_value is zero (unquoted)."
      ],
      "discriminator": [
        155,
        110,
        230,
        251,
        39,
        169,
        47,
        22
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "positionOwner"
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "debtMint"
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "debtReserveVault",
          "writable": true
        },
        {
          "name": "ownerDebtAccount",
          "writable": true
        },
        {
          "name": "referralPartner",
          "optional": true
        },
        {
          "name": "referralAccrual",
          "writable": true,
          "optional": true
        },
        {
          "name": "owner",
          "docs": [
            "Token payer; need not own the leverage position."
          ],
          "writable": true,
          "signer": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "addLeverageMarginArgs"
            }
          }
        }
      ]
    },
    {
      "name": "resolveOperatorChange",
      "docs": [
        "The operator may cancel any bundle; a manager may cancel its own. Anyone may close obsolete proposals."
      ],
      "discriminator": [
        173,
        4,
        208,
        219,
        60,
        231,
        129,
        124
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          },
          "relations": [
            "proposal"
          ]
        },
        {
          "name": "proposal",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  111,
                  112,
                  101,
                  114,
                  97,
                  116,
                  111,
                  114,
                  95,
                  99,
                  104,
                  97,
                  110,
                  103,
                  101
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "proposal.nonce",
                "account": "operatorProposal"
              }
            ]
          }
        },
        {
          "name": "rentRefund",
          "writable": true,
          "relations": [
            "proposal"
          ]
        },
        {
          "name": "operator",
          "signer": true,
          "optional": true
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "cancel",
          "type": "bool"
        }
      ]
    },
    {
      "name": "rotateHlpCohort",
      "discriminator": [
        163,
        66,
        186,
        91,
        40,
        131,
        194,
        235
      ],
      "accounts": [
        {
          "name": "payer",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "oldHlpMint"
        },
        {
          "name": "newHlpMint",
          "writable": true
        },
        {
          "name": "oldCohort",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  95,
                  99,
                  111,
                  104,
                  111,
                  114,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "oldHlpMint"
              }
            ]
          }
        },
        {
          "name": "newTokenMetadata",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  101,
                  116,
                  97,
                  100,
                  97,
                  116,
                  97
                ]
              },
              {
                "kind": "const",
                "value": [
                  11,
                  112,
                  101,
                  177,
                  227,
                  209,
                  124,
                  69,
                  56,
                  157,
                  82,
                  127,
                  107,
                  4,
                  195,
                  205,
                  88,
                  184,
                  108,
                  115,
                  26,
                  160,
                  253,
                  181,
                  73,
                  182,
                  209,
                  188,
                  3,
                  248,
                  41,
                  70
                ]
              },
              {
                "kind": "account",
                "path": "newHlpMint"
              }
            ],
            "program": {
              "kind": "const",
              "value": [
                11,
                112,
                101,
                177,
                227,
                209,
                124,
                69,
                56,
                157,
                82,
                127,
                107,
                4,
                195,
                205,
                88,
                184,
                108,
                115,
                26,
                160,
                253,
                181,
                73,
                182,
                209,
                188,
                3,
                248,
                41,
                70
              ]
            }
          }
        },
        {
          "name": "sysvarInstructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "tokenMetadataProgram",
          "address": "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s"
        },
        {
          "name": "systemProgram",
          "address": "11111111111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "rotateHlpCohortArgs"
            }
          }
        }
      ]
    },
    {
      "name": "setGlobalReduceOnly",
      "discriminator": [
        242,
        151,
        123,
        139,
        239,
        87,
        249,
        98
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true,
          "address": "3YL87sTCrHMB6DYKorE9CCN4dL45kZPahoREcMLDY6QV"
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "setGlobalReduceOnlyArgs"
            }
          }
        }
      ]
    },
    {
      "name": "setHarvestAuthority",
      "docs": [
        "Set or revoke a harvest caller independently of the yield recipient.",
        "Only the LP owner may update this authority; `None` revokes it."
      ],
      "discriminator": [
        59,
        181,
        149,
        163,
        99,
        148,
        106,
        133
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "lpMint"
        },
        {
          "name": "yieldAccount",
          "writable": true
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "setHarvestAuthorityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "setMarketReduceOnly",
      "discriminator": [
        178,
        78,
        219,
        198,
        188,
        185,
        181,
        88
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "authoritySigner",
          "signer": true,
          "address": "3YL87sTCrHMB6DYKorE9CCN4dL45kZPahoREcMLDY6QV"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "setMarketReduceOnlyArgs"
            }
          }
        }
      ]
    },
    {
      "name": "setReferralRecipient",
      "discriminator": [
        54,
        117,
        37,
        14,
        90,
        62,
        112,
        37
      ],
      "accounts": [
        {
          "name": "authority",
          "writable": true,
          "signer": true
        },
        {
          "name": "referralPartner",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  114,
                  101,
                  102,
                  101,
                  114,
                  114,
                  97,
                  108,
                  95,
                  112,
                  97,
                  114,
                  116,
                  110,
                  101,
                  114
                ]
              },
              {
                "kind": "account",
                "path": "authority"
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "setReferralRecipientArgs"
            }
          }
        }
      ]
    },
    {
      "name": "setYieldRecipient",
      "discriminator": [
        178,
        211,
        80,
        10,
        138,
        52,
        188,
        22
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "lpMint"
        },
        {
          "name": "yieldAccount",
          "writable": true
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "setYieldRecipientArgs"
            }
          }
        }
      ]
    },
    {
      "name": "settleFlashLiquidation",
      "discriminator": [
        161,
        93,
        89,
        56,
        133,
        124,
        79,
        20
      ],
      "accounts": [
        {
          "name": "accounts",
          "accounts": [
            {
              "name": "market",
              "writable": true,
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      109,
                      97,
                      114,
                      107,
                      101,
                      116,
                      95,
                      118,
                      50
                    ]
                  },
                  {
                    "kind": "account",
                    "path": "market.base_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.quote_side.asset_mint",
                    "account": "market"
                  },
                  {
                    "kind": "account",
                    "path": "market.params_hash",
                    "account": "market"
                  }
                ]
              }
            },
            {
              "name": "borrowPosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "leveragePosition",
              "writable": true,
              "optional": true
            },
            {
              "name": "buyer",
              "writable": true,
              "signer": true
            },
            {
              "name": "collateralMint"
            },
            {
              "name": "debtMint"
            },
            {
              "name": "collateralVault",
              "writable": true
            },
            {
              "name": "reserveVault",
              "writable": true
            },
            {
              "name": "buyerCollateralAccount",
              "writable": true
            },
            {
              "name": "buyerRefundAccount",
              "writable": true
            },
            {
              "name": "ownerDebtAccount",
              "writable": true
            },
            {
              "name": "futarchyAuthority",
              "pda": {
                "seeds": [
                  {
                    "kind": "const",
                    "value": [
                      102,
                      117,
                      116,
                      97,
                      114,
                      99,
                      104,
                      121,
                      95,
                      97,
                      117,
                      116,
                      104,
                      111,
                      114,
                      105,
                      116,
                      121
                    ]
                  }
                ]
              }
            },
            {
              "name": "referralPartner",
              "optional": true
            },
            {
              "name": "referralAccrual",
              "writable": true,
              "optional": true
            },
            {
              "name": "tokenProgram",
              "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            },
            {
              "name": "token2022Program",
              "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
            },
            {
              "name": "debtTokenProgram"
            }
          ]
        },
        {
          "name": "session",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  105,
                  113,
                  117,
                  105,
                  100,
                  97,
                  116,
                  105,
                  111,
                  110,
                  45,
                  115,
                  101,
                  115,
                  115,
                  105,
                  111,
                  110
                ]
              },
              {
                "kind": "account",
                "path": "session.position",
                "account": "liquidationSession"
              }
            ]
          }
        },
        {
          "name": "repaymentVault",
          "writable": true
        },
        {
          "name": "collateralReserveVault",
          "docs": [
            "Supplying the canonical opposite reserve selects direct Dusk execution",
            "with principal repayment netted inside the AMM settlement."
          ],
          "writable": true,
          "optional": true
        },
        {
          "name": "instructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "settleHlpFlash",
      "docs": [
        "Verify the fixed payment and restore the vault's opposite-token hedge."
      ],
      "discriminator": [
        215,
        124,
        153,
        104,
        195,
        91,
        118,
        209
      ],
      "accounts": [
        {
          "name": "accounts",
          "accounts": [
            {
              "name": "market",
              "writable": true
            },
            {
              "name": "futarchyAuthority"
            },
            {
              "name": "buyer",
              "writable": true,
              "signer": true
            },
            {
              "name": "targetMint"
            },
            {
              "name": "borrowedMint"
            },
            {
              "name": "targetReserve",
              "writable": true
            },
            {
              "name": "borrowedReserve",
              "writable": true
            },
            {
              "name": "buyerCollateralAccount",
              "writable": true
            },
            {
              "name": "buyerRefundAccount",
              "writable": true
            },
            {
              "name": "tokenProgram",
              "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
            },
            {
              "name": "token2022Program",
              "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
            },
            {
              "name": "borrowedTokenProgram"
            }
          ]
        },
        {
          "name": "session",
          "writable": true
        },
        {
          "name": "repaymentVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  45,
                  102,
                  108,
                  97,
                  115,
                  104,
                  45,
                  112,
                  97,
                  121,
                  109,
                  101,
                  110,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "session"
              }
            ]
          }
        },
        {
          "name": "instructions",
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": []
    },
    {
      "name": "settleProtocolAuction",
      "discriminator": [
        206,
        204,
        32,
        135,
        8,
        22,
        72,
        80
      ],
      "accounts": [
        {
          "name": "bidder",
          "writable": true,
          "signer": true
        },
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "soldMint"
        },
        {
          "name": "acceptedMint"
        },
        {
          "name": "soldVault",
          "writable": true
        },
        {
          "name": "bidderPaymentAccount",
          "writable": true
        },
        {
          "name": "bidderReceiveAccount",
          "writable": true
        },
        {
          "name": "treasuryPaymentAccount",
          "writable": true
        },
        {
          "name": "stakingVaultPaymentAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "settleProtocolAuctionArgs"
            }
          }
        }
      ]
    },
    {
      "name": "swap",
      "discriminator": [
        248,
        198,
        158,
        145,
        225,
        117,
        135,
        200
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "trader",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetInMint"
        },
        {
          "name": "assetOutMint"
        },
        {
          "name": "reserveInVault",
          "writable": true
        },
        {
          "name": "reserveOutVault",
          "writable": true
        },
        {
          "name": "traderAssetInAccount",
          "writable": true
        },
        {
          "name": "traderAssetOutAccount",
          "writable": true
        },
        {
          "name": "instructionsSysvar",
          "docs": [
            "during the configured launch rate-limit window."
          ],
          "address": "Sysvar1nstructions1111111111111111111111111"
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "swapArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateFutarchyAuthority",
      "discriminator": [
        15,
        196,
        157,
        217,
        113,
        226,
        89,
        25
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateFutarchyAuthorityArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateLeverageDelegation",
      "discriminator": [
        185,
        52,
        36,
        97,
        234,
        163,
        29,
        42
      ],
      "accounts": [
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "leveragePosition",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "leverageDelegation",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  100,
                  101,
                  108,
                  101,
                  103,
                  97,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateLeverageDelegationArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateLpMetadata",
      "discriminator": [
        189,
        1,
        111,
        232,
        230,
        30,
        12,
        245
      ],
      "accounts": [
        {
          "name": "operator",
          "signer": true
        },
        {
          "name": "market",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "lpMint"
        },
        {
          "name": "tokenMetadata",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  101,
                  116,
                  97,
                  100,
                  97,
                  116,
                  97
                ]
              },
              {
                "kind": "account",
                "path": "tokenMetadataProgram"
              },
              {
                "kind": "account",
                "path": "lpMint"
              }
            ],
            "program": {
              "kind": "account",
              "path": "tokenMetadataProgram"
            }
          }
        },
        {
          "name": "tokenMetadataProgram",
          "address": "metaqbxxUerdq28cj1RbAWkYQm3ybzjb6a8bt518x1s"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "initializeLpMetadataArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateProtocolAuctionConfig",
      "discriminator": [
        4,
        202,
        113,
        194,
        208,
        122,
        212,
        73
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateProtocolAuctionConfigArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateProtocolAuctionRecipients",
      "discriminator": [
        210,
        210,
        94,
        83,
        188,
        14,
        38,
        247
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateProtocolAuctionRecipientsArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateProtocolRevenue",
      "discriminator": [
        176,
        139,
        131,
        197,
        40,
        225,
        125,
        200
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateProtocolRevenueArgs"
            }
          }
        }
      ]
    },
    {
      "name": "updateRevenueRecipients",
      "discriminator": [
        116,
        179,
        137,
        47,
        118,
        167,
        65,
        217
      ],
      "accounts": [
        {
          "name": "authoritySigner",
          "writable": true,
          "signer": true
        },
        {
          "name": "futarchyAuthority",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "updateRevenueRecipientsArgs"
            }
          }
        }
      ]
    },
    {
      "name": "withdrawAllCollateral",
      "docs": [
        "Sweeps both collateral balances and closes a debt-free borrow position.",
        "Balances are read during execution so prior dust donations cannot block closure."
      ],
      "discriminator": [
        37,
        185,
        159,
        214,
        37,
        30,
        163,
        146
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "baseCollateralVault",
          "writable": true
        },
        {
          "name": "quoteCollateralVault",
          "writable": true
        },
        {
          "name": "ownerBaseAccount",
          "writable": true
        },
        {
          "name": "ownerQuoteAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "withdrawAllCollateralArgs"
            }
          }
        }
      ]
    },
    {
      "name": "withdrawCollateral",
      "discriminator": [
        115,
        135,
        168,
        106,
        139,
        214,
        138,
        150
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "futarchyAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  102,
                  117,
                  116,
                  97,
                  114,
                  99,
                  104,
                  121,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "assetMint"
        },
        {
          "name": "collateralVault",
          "writable": true
        },
        {
          "name": "ownerAssetAccount",
          "writable": true
        },
        {
          "name": "borrowPosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  98,
                  111,
                  114,
                  114,
                  111,
                  119,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "borrow_position.owner",
                "account": "borrowPosition"
              },
              {
                "kind": "account",
                "path": "borrow_position.position_id",
                "account": "borrowPosition"
              }
            ]
          }
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "withdrawCollateralArgs"
            }
          }
        }
      ]
    },
    {
      "name": "withdrawRepaidLeverage",
      "docs": [
        "Returns all remaining collateral to its owner after full leverage repayment."
      ],
      "discriminator": [
        7,
        253,
        16,
        195,
        214,
        10,
        116,
        51
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  109,
                  97,
                  114,
                  107,
                  101,
                  116,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market.base_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.quote_side.asset_mint",
                "account": "market"
              },
              {
                "kind": "account",
                "path": "market.params_hash",
                "account": "market"
              }
            ]
          }
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "leveragePosition",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  112,
                  111,
                  115,
                  105,
                  116,
                  105,
                  111,
                  110,
                  95,
                  118,
                  50
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "leverage_position.owner",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.namespace_authority",
                "account": "leveragePosition"
              },
              {
                "kind": "account",
                "path": "leverage_position.position_id",
                "account": "leveragePosition"
              }
            ]
          }
        },
        {
          "name": "collateralMint"
        },
        {
          "name": "collateralVault",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  108,
                  101,
                  118,
                  101,
                  114,
                  97,
                  103,
                  101,
                  95,
                  99,
                  111,
                  108,
                  108,
                  97,
                  116,
                  101,
                  114,
                  97,
                  108
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "collateralMint"
              }
            ]
          }
        },
        {
          "name": "ownerCollateralAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "withdrawRepaidLeverageArgs"
            }
          }
        }
      ]
    },
    {
      "name": "withdrawSingleSided",
      "discriminator": [
        243,
        84,
        228,
        99,
        122,
        147,
        252,
        62
      ],
      "accounts": [
        {
          "name": "market",
          "writable": true
        },
        {
          "name": "futarchyAuthority"
        },
        {
          "name": "owner",
          "writable": true,
          "signer": true
        },
        {
          "name": "baseMint"
        },
        {
          "name": "quoteMint"
        },
        {
          "name": "srlpMint",
          "writable": true
        },
        {
          "name": "targetHlpMint",
          "writable": true
        },
        {
          "name": "baseReserveVault",
          "writable": true
        },
        {
          "name": "quoteReserveVault",
          "writable": true
        },
        {
          "name": "ownerTargetAccount",
          "writable": true
        },
        {
          "name": "ownerHlpAccount",
          "writable": true
        },
        {
          "name": "hlpSrlpAccount",
          "writable": true,
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  104,
                  108,
                  112,
                  95,
                  121,
                  108,
                  112,
                  95,
                  118,
                  97,
                  117,
                  108,
                  116
                ]
              },
              {
                "kind": "account",
                "path": "market"
              },
              {
                "kind": "account",
                "path": "targetHlpMint"
              },
              {
                "kind": "account",
                "path": "srlpMint"
              }
            ]
          }
        },
        {
          "name": "baseYieldAccount",
          "writable": true
        },
        {
          "name": "quoteYieldAccount",
          "writable": true
        },
        {
          "name": "tokenProgram",
          "address": "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
        },
        {
          "name": "token2022Program",
          "address": "TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb"
        },
        {
          "name": "eventAuthority",
          "pda": {
            "seeds": [
              {
                "kind": "const",
                "value": [
                  95,
                  95,
                  101,
                  118,
                  101,
                  110,
                  116,
                  95,
                  97,
                  117,
                  116,
                  104,
                  111,
                  114,
                  105,
                  116,
                  121
                ]
              }
            ]
          }
        },
        {
          "name": "program"
        }
      ],
      "args": [
        {
          "name": "args",
          "type": {
            "defined": {
              "name": "withdrawSingleSidedArgs"
            }
          }
        }
      ]
    }
  ],
  "accounts": [
    {
      "name": "borrowPosition",
      "discriminator": [
        243,
        140,
        20,
        139,
        32,
        243,
        114,
        55
      ]
    },
    {
      "name": "futarchyAuthority",
      "discriminator": [
        175,
        247,
        160,
        182,
        140,
        128,
        211,
        226
      ]
    },
    {
      "name": "hlpCohort",
      "discriminator": [
        224,
        89,
        199,
        90,
        126,
        101,
        43,
        215
      ]
    },
    {
      "name": "hlpFlashSession",
      "discriminator": [
        212,
        216,
        161,
        138,
        241,
        116,
        166,
        126
      ]
    },
    {
      "name": "juniorCohort",
      "discriminator": [
        66,
        255,
        14,
        91,
        158,
        179,
        23,
        9
      ]
    },
    {
      "name": "juniorExitAccount",
      "discriminator": [
        186,
        158,
        208,
        250,
        7,
        219,
        13,
        26
      ]
    },
    {
      "name": "leverageDelegation",
      "discriminator": [
        49,
        60,
        29,
        23,
        243,
        219,
        16,
        214
      ]
    },
    {
      "name": "leveragePosition",
      "discriminator": [
        88,
        78,
        124,
        68,
        228,
        129,
        34,
        251
      ]
    },
    {
      "name": "liquidationSession",
      "discriminator": [
        198,
        19,
        76,
        58,
        102,
        166,
        134,
        164
      ]
    },
    {
      "name": "market",
      "discriminator": [
        219,
        190,
        213,
        55,
        0,
        227,
        198,
        154
      ]
    },
    {
      "name": "operatorProposal",
      "discriminator": [
        55,
        174,
        78,
        112,
        33,
        32,
        159,
        169
      ]
    },
    {
      "name": "operatorRevenueAccount",
      "discriminator": [
        137,
        103,
        226,
        155,
        153,
        98,
        227,
        65
      ]
    },
    {
      "name": "referralAccrual",
      "discriminator": [
        35,
        246,
        25,
        66,
        174,
        160,
        48,
        39
      ]
    },
    {
      "name": "referralPartner",
      "discriminator": [
        234,
        54,
        169,
        157,
        142,
        187,
        225,
        214
      ]
    },
    {
      "name": "yieldAccount",
      "discriminator": [
        233,
        241,
        119,
        6,
        2,
        14,
        106,
        156
      ]
    }
  ],
  "events": [
    {
      "name": "borrowInterestAccrued",
      "discriminator": [
        72,
        60,
        125,
        249,
        229,
        92,
        113,
        250
      ]
    },
    {
      "name": "borrowInterestPaid",
      "discriminator": [
        173,
        181,
        219,
        170,
        32,
        88,
        224,
        224
      ]
    },
    {
      "name": "borrowPositionLiquidated",
      "discriminator": [
        107,
        167,
        26,
        25,
        33,
        197,
        106,
        188
      ]
    },
    {
      "name": "debtFreePositionClosed",
      "discriminator": [
        220,
        198,
        224,
        150,
        204,
        65,
        184,
        31
      ]
    },
    {
      "name": "emergencyLiquidationSettled",
      "discriminator": [
        243,
        230,
        130,
        84,
        184,
        113,
        18,
        172
      ]
    },
    {
      "name": "flashLiquidationBegun",
      "discriminator": [
        198,
        250,
        117,
        184,
        74,
        48,
        48,
        151
      ]
    },
    {
      "name": "flashLiquidationSettled",
      "discriminator": [
        207,
        203,
        137,
        99,
        235,
        237,
        207,
        38
      ]
    },
    {
      "name": "harvestAuthorityUpdated",
      "discriminator": [
        232,
        18,
        21,
        9,
        229,
        230,
        173,
        86
      ]
    },
    {
      "name": "hlpClosed",
      "discriminator": [
        87,
        126,
        152,
        164,
        162,
        203,
        111,
        235
      ]
    },
    {
      "name": "hlpCohortRotated",
      "discriminator": [
        46,
        134,
        13,
        57,
        117,
        44,
        226,
        81
      ]
    },
    {
      "name": "hlpFlashSettled",
      "discriminator": [
        255,
        193,
        57,
        138,
        48,
        64,
        138,
        37
      ]
    },
    {
      "name": "hlpFlashStarted",
      "discriminator": [
        203,
        97,
        249,
        187,
        226,
        119,
        141,
        71
      ]
    },
    {
      "name": "hlpOpened",
      "discriminator": [
        188,
        231,
        244,
        52,
        5,
        151,
        236,
        84
      ]
    },
    {
      "name": "hlpRebalanced",
      "discriminator": [
        48,
        237,
        118,
        177,
        48,
        168,
        104,
        6
      ]
    },
    {
      "name": "hlpRetiredReceiptBurned",
      "discriminator": [
        31,
        252,
        3,
        205,
        166,
        215,
        14,
        49
      ]
    },
    {
      "name": "hlpTerminalLiquidated",
      "discriminator": [
        80,
        186,
        237,
        212,
        75,
        183,
        43,
        173
      ]
    },
    {
      "name": "juniorCohortInitialized",
      "discriminator": [
        18,
        109,
        85,
        200,
        65,
        58,
        228,
        243
      ]
    },
    {
      "name": "juniorSeedCompounded",
      "discriminator": [
        253,
        233,
        124,
        178,
        67,
        98,
        224,
        87
      ]
    },
    {
      "name": "juniorSeedFunded",
      "discriminator": [
        123,
        105,
        18,
        32,
        9,
        92,
        120,
        184
      ]
    },
    {
      "name": "leverageDelegationUpdated",
      "discriminator": [
        118,
        41,
        235,
        95,
        91,
        24,
        191,
        17
      ]
    },
    {
      "name": "leveragePositionClosed",
      "discriminator": [
        132,
        9,
        124,
        103,
        6,
        252,
        177,
        238
      ]
    },
    {
      "name": "leveragePositionLiquidated",
      "discriminator": [
        59,
        18,
        185,
        247,
        120,
        184,
        16,
        225
      ]
    },
    {
      "name": "leveragePositionOpened",
      "discriminator": [
        198,
        227,
        54,
        99,
        54,
        249,
        54,
        29
      ]
    },
    {
      "name": "leveragePositionUpdated",
      "discriminator": [
        195,
        171,
        245,
        43,
        32,
        163,
        44,
        170
      ]
    },
    {
      "name": "liquidationAuctionCancelled",
      "discriminator": [
        122,
        103,
        174,
        225,
        120,
        149,
        186,
        155
      ]
    },
    {
      "name": "liquidationAuctionStarted",
      "discriminator": [
        137,
        151,
        231,
        92,
        108,
        13,
        215,
        59
      ]
    },
    {
      "name": "liquidityAdded",
      "discriminator": [
        154,
        26,
        221,
        108,
        238,
        64,
        217,
        161
      ]
    },
    {
      "name": "liquidityRemoved",
      "discriminator": [
        225,
        105,
        216,
        39,
        124,
        116,
        169,
        189
      ]
    },
    {
      "name": "lpTransferred",
      "discriminator": [
        244,
        4,
        93,
        185,
        125,
        159,
        75,
        55
      ]
    },
    {
      "name": "managerChanged",
      "discriminator": [
        142,
        97,
        175,
        220,
        73,
        27,
        252,
        56
      ]
    },
    {
      "name": "marketCollateralDeposited",
      "discriminator": [
        41,
        53,
        157,
        172,
        249,
        159,
        63,
        60
      ]
    },
    {
      "name": "marketCollateralWithdrawn",
      "discriminator": [
        68,
        208,
        162,
        132,
        39,
        151,
        221,
        245
      ]
    },
    {
      "name": "marketCreated",
      "discriminator": [
        88,
        184,
        130,
        231,
        226,
        84,
        6,
        58
      ]
    },
    {
      "name": "marketDebtUpdated",
      "discriminator": [
        135,
        150,
        109,
        165,
        174,
        35,
        163,
        151
      ]
    },
    {
      "name": "marketHealthUpdated",
      "discriminator": [
        99,
        12,
        230,
        43,
        133,
        194,
        188,
        225
      ]
    },
    {
      "name": "marketReduceOnlyUpdated",
      "discriminator": [
        87,
        12,
        104,
        143,
        113,
        121,
        31,
        94
      ]
    },
    {
      "name": "operatorChangeAnnounced",
      "discriminator": [
        137,
        231,
        71,
        79,
        127,
        58,
        221,
        224
      ]
    },
    {
      "name": "operatorChangeResolved",
      "discriminator": [
        147,
        200,
        253,
        3,
        228,
        196,
        117,
        201
      ]
    },
    {
      "name": "operatorChanged",
      "discriminator": [
        231,
        79,
        62,
        226,
        190,
        139,
        176,
        51
      ]
    },
    {
      "name": "operatorRevenueClaimed",
      "discriminator": [
        187,
        177,
        199,
        199,
        220,
        87,
        89,
        74
      ]
    },
    {
      "name": "orphanedHlpClosed",
      "discriminator": [
        127,
        88,
        17,
        121,
        183,
        111,
        237,
        157
      ]
    },
    {
      "name": "protocolAuctionConfigUpdated",
      "discriminator": [
        178,
        169,
        215,
        69,
        170,
        59,
        80,
        160
      ]
    },
    {
      "name": "protocolAuctionConfigured",
      "discriminator": [
        114,
        47,
        219,
        227,
        0,
        0,
        171,
        52
      ]
    },
    {
      "name": "protocolAuctionRecipientsUpdated",
      "discriminator": [
        174,
        178,
        55,
        120,
        155,
        241,
        5,
        120
      ]
    },
    {
      "name": "protocolAuctionSettled",
      "discriminator": [
        11,
        230,
        199,
        245,
        28,
        133,
        107,
        3
      ]
    },
    {
      "name": "protocolAuctionSplitUpdated",
      "discriminator": [
        17,
        255,
        78,
        242,
        127,
        110,
        234,
        249
      ]
    },
    {
      "name": "protocolInterestMarkupCheckpointed",
      "discriminator": [
        164,
        132,
        177,
        23,
        186,
        43,
        200,
        39
      ]
    },
    {
      "name": "referralBound",
      "discriminator": [
        12,
        28,
        152,
        148,
        55,
        210,
        102,
        190
      ]
    },
    {
      "name": "referralInterestAccrued",
      "discriminator": [
        80,
        233,
        11,
        123,
        118,
        218,
        113,
        154
      ]
    },
    {
      "name": "referralInterestClaimed",
      "discriminator": [
        103,
        79,
        19,
        199,
        132,
        222,
        156,
        190
      ]
    },
    {
      "name": "referralInterestShareCapUpdated",
      "discriminator": [
        103,
        139,
        112,
        245,
        212,
        53,
        91,
        113
      ]
    },
    {
      "name": "referralPartnerConfigured",
      "discriminator": [
        60,
        230,
        246,
        232,
        67,
        30,
        217,
        223
      ]
    },
    {
      "name": "referralRecipientUpdated",
      "discriminator": [
        51,
        4,
        221,
        175,
        134,
        8,
        235,
        222
      ]
    },
    {
      "name": "retiredJuniorBurned",
      "discriminator": [
        29,
        56,
        158,
        137,
        97,
        193,
        230,
        93
      ]
    },
    {
      "name": "swapExecuted",
      "discriminator": [
        150,
        166,
        26,
        225,
        28,
        89,
        38,
        79
      ]
    },
    {
      "name": "trancheConverted",
      "discriminator": [
        249,
        121,
        88,
        27,
        39,
        181,
        244,
        199
      ]
    },
    {
      "name": "yieldClaimed",
      "discriminator": [
        177,
        201,
        94,
        68,
        19,
        200,
        227,
        27
      ]
    },
    {
      "name": "yieldRecipientUpdated",
      "discriminator": [
        154,
        113,
        25,
        74,
        11,
        107,
        114,
        170
      ]
    }
  ],
  "errors": [
    {
      "code": 6000,
      "name": "invalidOperator",
      "msg": "Only the current market operator may authorize this action"
    },
    {
      "code": 6001,
      "name": "operatorEpochMismatch",
      "msg": "Operator authority epoch changed"
    },
    {
      "code": 6002,
      "name": "operatorNonceMismatch",
      "msg": "Operator nonce is not current"
    },
    {
      "code": 6003,
      "name": "operatorFieldForbidden",
      "msg": "This field cannot be changed by an operator"
    },
    {
      "code": 6004,
      "name": "operatorPolicyExceeded",
      "msg": "Operator change exceeds the fixed protocol policy"
    },
    {
      "code": 6005,
      "name": "operatorProposalStale",
      "msg": "Operator bundle no longer matches the market"
    },
    {
      "code": 6006,
      "name": "operatorNoticeNotReady",
      "msg": "Operator change is still in its exit notice"
    },
    {
      "code": 6007,
      "name": "operatorProposalExpired",
      "msg": "Operator execution window expired"
    },
    {
      "code": 6008,
      "name": "operatorChangePending",
      "msg": "Operator change is still pending"
    },
    {
      "code": 6009,
      "name": "operatorRevenueArchiveRequired",
      "msg": "Prepare the previous recipient revenue archive before transferring future fees"
    },
    {
      "code": 6010,
      "name": "invalidDeployer",
      "msg": "Invalid deployer"
    },
    {
      "code": 6011,
      "name": "argumentMissing",
      "msg": "Argument missing"
    },
    {
      "code": 6012,
      "name": "invalidSwapFeeBps",
      "msg": "Invalid swap fee bps"
    },
    {
      "code": 6013,
      "name": "invalidInterestFeeBps",
      "msg": "Invalid interest fee bps"
    },
    {
      "code": 6014,
      "name": "invalidHalfLife",
      "msg": "Invalid half life"
    },
    {
      "code": 6015,
      "name": "invalidFutarchyAuthority",
      "msg": "Invalid futarchy authority"
    },
    {
      "code": 6016,
      "name": "invalidReduceOnlyAuthority",
      "msg": "Invalid reduce-only authority"
    },
    {
      "code": 6017,
      "name": "invalidProposalMetadata",
      "msg": "Invalid parameter proposal metadata"
    },
    {
      "code": 6018,
      "name": "invalidProposalUri",
      "msg": "Invalid parameter proposal description URI"
    },
    {
      "code": 6019,
      "name": "parameterUpdateNotMeaningful",
      "msg": "Parameter update would not change the active market parameters"
    },
    {
      "code": 6020,
      "name": "invalidParameterUpdate",
      "msg": "Invalid parameter update"
    },
    {
      "code": 6021,
      "name": "utilizationGuardExceeded",
      "msg": "Parameter execution is blocked while either lending side is at or above 80% utilization"
    },
    {
      "code": 6022,
      "name": "invalidArgument",
      "msg": "Invalid argument"
    },
    {
      "code": 6023,
      "name": "amountZero",
      "msg": "Amount cannot be zero"
    },
    {
      "code": 6024,
      "name": "insufficientAmount0In",
      "msg": "Insufficient amount0 in"
    },
    {
      "code": 6025,
      "name": "insufficientAmount1In",
      "msg": "Insufficient amount1 in"
    },
    {
      "code": 6026,
      "name": "borrowingPowerExceeded",
      "msg": "Borrowing power exceeded"
    },
    {
      "code": 6027,
      "name": "invalidTokenAccount",
      "msg": "Invalid token account"
    },
    {
      "code": 6028,
      "name": "invalidTokenProgram",
      "msg": "Invalid token program"
    },
    {
      "code": 6029,
      "name": "borrowExceedsReserve",
      "msg": "Borrow exceeds reserve"
    },
    {
      "code": 6030,
      "name": "insufficientAmount0",
      "msg": "Insufficient amount0"
    },
    {
      "code": 6031,
      "name": "insufficientAmount1",
      "msg": "Insufficient amount1"
    },
    {
      "code": 6032,
      "name": "insufficientOutputAmount",
      "msg": "Insufficient output amount"
    },
    {
      "code": 6033,
      "name": "slippageExceeded",
      "msg": "Output amount below minimum requested (slippage exceeded)"
    },
    {
      "code": 6034,
      "name": "insufficientLiquidity",
      "msg": "Insufficient liquidity"
    },
    {
      "code": 6035,
      "name": "insufficientCashReserve0",
      "msg": "Insufficient cash reserve0"
    },
    {
      "code": 6036,
      "name": "insufficientCashReserve1",
      "msg": "Insufficient cash reserve1"
    },
    {
      "code": 6037,
      "name": "overflow",
      "msg": "Arithmetic overflow"
    },
    {
      "code": 6038,
      "name": "undercollateralized",
      "msg": "undercollateralized"
    },
    {
      "code": 6039,
      "name": "insufficientBalanceForCollateral",
      "msg": "Insufficient balance for collateral"
    },
    {
      "code": 6040,
      "name": "insufficientAmount",
      "msg": "Insufficient amount"
    },
    {
      "code": 6041,
      "name": "insufficientBalance",
      "msg": "User balance insufficient to cover requested amount"
    },
    {
      "code": 6042,
      "name": "insufficientDebt",
      "msg": "Insufficient debt"
    },
    {
      "code": 6043,
      "name": "userPositionNotInitialized",
      "msg": "User position not initialized"
    },
    {
      "code": 6044,
      "name": "zeroDebtAmount",
      "msg": "Zero debt amount"
    },
    {
      "code": 6045,
      "name": "notUndercollateralized",
      "msg": "Not undercollateralized"
    },
    {
      "code": 6046,
      "name": "brokenInvariant",
      "msg": "Broken invariant"
    },
    {
      "code": 6047,
      "name": "invariantOverflow",
      "msg": "Math overflow during invariant calculation"
    },
    {
      "code": 6048,
      "name": "feeMathOverflow",
      "msg": "Math overflow during fee calculation."
    },
    {
      "code": 6049,
      "name": "outputAmountOverflow",
      "msg": "Math overflow during output amount calculation."
    },
    {
      "code": 6050,
      "name": "reserveOverflow",
      "msg": "Math overflow during reserve calculation."
    },
    {
      "code": 6051,
      "name": "reserveUnderflow",
      "msg": "Math underflow during reserve calculation."
    },
    {
      "code": 6052,
      "name": "cashReserveUnderflow",
      "msg": "Math underflow during cash reserve calculation."
    },
    {
      "code": 6053,
      "name": "denominatorOverflow",
      "msg": "Math overflow during denominator calculation."
    },
    {
      "code": 6054,
      "name": "liquidityMathOverflow",
      "msg": "Math overflow during liquidity calculation"
    },
    {
      "code": 6055,
      "name": "liquiditySqrtOverflow",
      "msg": "Math overflow during liquidity square root calculation"
    },
    {
      "code": 6056,
      "name": "liquidityUnderflow",
      "msg": "Math underflow during liquidity calculation"
    },
    {
      "code": 6057,
      "name": "liquidityConversionOverflow",
      "msg": "Math overflow during liquidity conversion"
    },
    {
      "code": 6058,
      "name": "supplyOverflow",
      "msg": "Math overflow during supply calculation"
    },
    {
      "code": 6059,
      "name": "supplyUnderflow",
      "msg": "Math underflow during supply calculation"
    },
    {
      "code": 6060,
      "name": "debtMathOverflow",
      "msg": "Math overflow during debt calculation"
    },
    {
      "code": 6061,
      "name": "debtShareMathOverflow",
      "msg": "Math overflow during debt share calculation"
    },
    {
      "code": 6062,
      "name": "debtShareDivisionOverflow",
      "msg": "Math overflow during debt share division"
    },
    {
      "code": 6063,
      "name": "debtUtilizationOverflow",
      "msg": "Math overflow during debt utilization calculation"
    },
    {
      "code": 6064,
      "name": "invalidMint",
      "msg": "Invalid mint"
    },
    {
      "code": 6065,
      "name": "invalidMintLen",
      "msg": "Invalid mint length"
    },
    {
      "code": 6066,
      "name": "invalidDistribution",
      "msg": "Invalid distribution - percentages must sum to 100%"
    },
    {
      "code": 6067,
      "name": "invalidAuctionConfig",
      "msg": "Invalid protocol auction config"
    },
    {
      "code": 6068,
      "name": "invalidAuctionClock",
      "msg": "Protocol auction slot precedes its last update"
    },
    {
      "code": 6069,
      "name": "insufficientAuctionPayment",
      "msg": "Protocol auction payment is insufficient"
    },
    {
      "code": 6070,
      "name": "invalidLpMintKey",
      "msg": "Invalid LP mint key"
    },
    {
      "code": 6071,
      "name": "invalidLpName",
      "msg": "Invalid LP name"
    },
    {
      "code": 6072,
      "name": "invalidLpSymbol",
      "msg": "Invalid LP symbol"
    },
    {
      "code": 6073,
      "name": "invalidLpUri",
      "msg": "Invalid LP URI"
    },
    {
      "code": 6074,
      "name": "accountNotEmpty",
      "msg": "Account not empty"
    },
    {
      "code": 6075,
      "name": "invalidMintAuthority",
      "msg": "Invalid mint authority"
    },
    {
      "code": 6076,
      "name": "frozenLpMint",
      "msg": "Frozen LP mint"
    },
    {
      "code": 6077,
      "name": "nonZeroSupply",
      "msg": "Non-zero supply"
    },
    {
      "code": 6078,
      "name": "wrongLpDecimals",
      "msg": "Wrong LP decimals"
    },
    {
      "code": 6079,
      "name": "unsupportedAssetDecimals",
      "msg": "Asset mint decimals exceed Dusk's 9-decimal AMM precision"
    },
    {
      "code": 6080,
      "name": "invalidVaultSameAccount",
      "msg": "Invalid vault - token_in_vault and token_out_vault must be different"
    },
    {
      "code": 6081,
      "name": "invalidVault",
      "msg": "Invalid vault"
    },
    {
      "code": 6082,
      "name": "invalidParamsHash",
      "msg": "Invalid params hash - hash does not match computed parameters"
    },
    {
      "code": 6083,
      "name": "invalidVersion",
      "msg": "Invalid version"
    },
    {
      "code": 6084,
      "name": "invalidTokenOrder",
      "msg": "Invalid token order"
    },
    {
      "code": 6085,
      "name": "invalidRateModel",
      "msg": "Invalid rate model - rate_model does not match market configuration"
    },
    {
      "code": 6086,
      "name": "invalidPositionMarket",
      "msg": "Invalid position market - position does not match market"
    },
    {
      "code": 6087,
      "name": "invalidUtilBounds",
      "msg": "Invalid utilization bounds - must satisfy: MIN <= start < end <= MAX"
    },
    {
      "code": 6088,
      "name": "invalidRateParams",
      "msg": "Invalid rate parameters - check half_life_ms, min_rate_bps, max_rate_bps, initial_rate_bps bounds"
    },
    {
      "code": 6089,
      "name": "reduceOnlyMode",
      "msg": "Operation blocked: reduce-only mode is active"
    },
    {
      "code": 6090,
      "name": "reduceOnlyHasDebt",
      "msg": "Cannot remove collateral in reduce-only mode while debt exists"
    },
    {
      "code": 6091,
      "name": "invalidInstructionsSysvar",
      "msg": "Invalid instructions sysvar"
    },
    {
      "code": 6092,
      "name": "insufficientPostWithdrawDebtCoverage",
      "msg": "Insufficient post-withdraw debt coverage"
    },
    {
      "code": 6093,
      "name": "invalidRecipient",
      "msg": "Invalid recipient - address does not match configured revenue recipient"
    },
    {
      "code": 6094,
      "name": "invalidMarket",
      "msg": "Invalid market"
    },
    {
      "code": 6095,
      "name": "invalidMarketConfig",
      "msg": "Invalid market config"
    },
    {
      "code": 6096,
      "name": "invalidSettlementPrice",
      "msg": "Invalid settlement price"
    },
    {
      "code": 6097,
      "name": "insufficientMarketShareBacking",
      "msg": "Market reserve share backing is insufficient"
    },
    {
      "code": 6098,
      "name": "invalidMarketSide",
      "msg": "Invalid market side"
    },
    {
      "code": 6099,
      "name": "invalidYieldAccount",
      "msg": "Invalid yield account"
    },
    {
      "code": 6100,
      "name": "invalidHlpVault",
      "msg": "Invalid hLP vault"
    },
    {
      "code": 6101,
      "name": "invalidHlpMintSupply",
      "msg": "Live hLP mint supply is inconsistent with stored vault supply"
    },
    {
      "code": 6102,
      "name": "notEnoughAccounts",
      "msg": "Not enough remaining accounts"
    },
    {
      "code": 6103,
      "name": "hlpSettlementUnavailable",
      "msg": "hLP settlement is unavailable"
    },
    {
      "code": 6104,
      "name": "hlpNotLiquidatable",
      "msg": "hLP funding position is not eligible for permissionless liquidation"
    },
    {
      "code": 6105,
      "name": "insufficientBorrowHeadroom",
      "msg": "Borrow headroom is insufficient"
    },
    {
      "code": 6106,
      "name": "insufficientMarketHealth",
      "msg": "Market health is insufficient"
    },
    {
      "code": 6107,
      "name": "invalidBorrowPosition",
      "msg": "Invalid borrow position"
    },
    {
      "code": 6108,
      "name": "positionNotLiquidatable",
      "msg": "Position is not liquidatable"
    },
    {
      "code": 6109,
      "name": "liquidationSocializationExceeded",
      "msg": "Socialized liquidation loss exceeds caller cap"
    },
    {
      "code": 6110,
      "name": "invalidClaimMint",
      "msg": "Claim mint must not charge transfer fees"
    },
    {
      "code": 6111,
      "name": "unbackedFeeLiability",
      "msg": "Fee liability is not backed by its custody balance"
    },
    {
      "code": 6112,
      "name": "invalidMarketFeeAuthority",
      "msg": "Invalid market fee authority"
    },
    {
      "code": 6113,
      "name": "invalidInitialLiquidityAuthority",
      "msg": "Invalid initial liquidity authority"
    },
    {
      "code": 6114,
      "name": "launchRateLimitSplitTransaction",
      "msg": "Launch rate limiter permits only one top-level market action per transaction"
    },
    {
      "code": 6115,
      "name": "marketReduceOnly",
      "msg": "Market is reduce-only"
    },
    {
      "code": 6116,
      "name": "marketNotStarted",
      "msg": "Market has not started"
    },
    {
      "code": 6117,
      "name": "marketMathOverflow",
      "msg": "Market math overflow"
    },
    {
      "code": 6118,
      "name": "dailyLimitExceeded",
      "msg": "Daily liquidity limit exceeded"
    },
    {
      "code": 6119,
      "name": "instructionNotLive",
      "msg": "Instruction is intentionally not live yet"
    },
    {
      "code": 6120,
      "name": "liquidationRepayTooLarge",
      "msg": "Liquidation repay amount exceeds partial liquidation cap"
    },
    {
      "code": 6121,
      "name": "leverageMultiplierTooHigh",
      "msg": "Leverage multiplier exceeds circuit breaker"
    },
    {
      "code": 6122,
      "name": "leverageInitialMarginTooLow",
      "msg": "Leverage position does not have enough initial margin"
    },
    {
      "code": 6123,
      "name": "leverageUnwindImpactTooHigh",
      "msg": "Leverage unwind impact exceeds limit"
    },
    {
      "code": 6124,
      "name": "leveragePositionNotLiquidatable",
      "msg": "Leverage position is not liquidatable"
    },
    {
      "code": 6125,
      "name": "invalidSigner",
      "msg": "Invalid signer"
    },
    {
      "code": 6126,
      "name": "invalidLeveragePosition",
      "msg": "Invalid leverage position"
    },
    {
      "code": 6127,
      "name": "invalidLeverageDelegation",
      "msg": "Invalid leverage delegation"
    },
    {
      "code": 6128,
      "name": "invalidReferralInterestShareBps",
      "msg": "Referral interest share exceeds the protocol hard cap"
    },
    {
      "code": 6129,
      "name": "invalidReferralPartner",
      "msg": "Invalid referral partner"
    },
    {
      "code": 6130,
      "name": "referralPartnerNotActive",
      "msg": "Referral partner is not active"
    },
    {
      "code": 6131,
      "name": "invalidReferralAccrual",
      "msg": "Invalid referral accrual account"
    },
    {
      "code": 6132,
      "name": "invalidLeverageCollateralMint",
      "msg": "Leverage collateral transfer fee must be immutable with no pending change"
    },
    {
      "code": 6133,
      "name": "freezableAssetMint",
      "msg": "Asset mint has an active freeze authority"
    },
    {
      "code": 6134,
      "name": "parameterUpdatesNotCanonical",
      "msg": "Parameter updates must name one to seven families, each once, in ascending family order"
    },
    {
      "code": 6135,
      "name": "reservedLiquidationClock",
      "msg": "Reserved retired liquidation clock error"
    },
    {
      "code": 6136,
      "name": "liquidationSessionActive",
      "msg": "Position has an active liquidation session"
    },
    {
      "code": 6137,
      "name": "invalidLiquidationSession",
      "msg": "Invalid atomic liquidation session or instruction pairing"
    },
    {
      "code": 6138,
      "name": "liquidationDoesNotImproveHealth",
      "msg": "Partial liquidation does not improve health after costs"
    },
    {
      "code": 6139,
      "name": "oracleAccountMissing",
      "msg": "The market's configured oracle account was not supplied"
    },
    {
      "code": 6140,
      "name": "oracleAuthenticationFailed",
      "msg": "Oracle account owner, identity or verification failed"
    },
    {
      "code": 6141,
      "name": "oracleInvalidObservation",
      "msg": "Oracle report is invalid, future-dated, halted or too uncertain"
    },
    {
      "code": 6142,
      "name": "oracleStale",
      "msg": "Oracle source observation is stale"
    },
    {
      "code": 6143,
      "name": "oracleReplay",
      "msg": "Oracle sequence or source observation regressed"
    },
    {
      "code": 6144,
      "name": "launchSettingsImmutable",
      "msg": "Launch-only settings are immutable after the market starts"
    },
    {
      "code": 6145,
      "name": "curveTailShareBelowMinimum",
      "msg": "Concentrated curve tails must hold at least 0.01% of liquidity; lower the peak amplification or narrow the core or fade"
    },
    {
      "code": 6146,
      "name": "concentratedSwapFeeBelowMinimum",
      "msg": "Concentrated curves require a base swap fee of at least 1 bps"
    },
    {
      "code": 6147,
      "name": "hlpFirstDepositTooSmall",
      "msg": "A first hLP deposit must borrow at least one atom of the opposite asset; see min_first_deposit_net in the hLP deposit capacity preview"
    },
    {
      "code": 6148,
      "name": "interestDeficit",
      "msg": "Market has an interest deficit: no new capital, credit or curve-priced exit"
    }
  ],
  "types": [
    {
      "name": "addLeverageMarginArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "amount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "addLiquidityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "baseDepositAmount",
            "type": "u64"
          },
          {
            "name": "quoteDepositAmount",
            "type": "u64"
          },
          {
            "name": "minSrlpAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "addLiquidityPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "requestedBaseAmount",
            "type": "u64"
          },
          {
            "name": "requestedQuoteAmount",
            "type": "u64"
          },
          {
            "name": "maxBaseReserveCredit",
            "type": "u64"
          },
          {
            "name": "maxQuoteReserveCredit",
            "type": "u64"
          },
          {
            "name": "baseTransferAmount",
            "type": "u64"
          },
          {
            "name": "quoteTransferAmount",
            "type": "u64"
          },
          {
            "name": "baseTransferFee",
            "type": "u64"
          },
          {
            "name": "quoteTransferFee",
            "type": "u64"
          },
          {
            "name": "baseReserveCredit",
            "type": "u64"
          },
          {
            "name": "quoteReserveCredit",
            "type": "u64"
          },
          {
            "name": "unusedBaseAmount",
            "type": "u64"
          },
          {
            "name": "unusedQuoteAmount",
            "type": "u64"
          },
          {
            "name": "srlpAmount",
            "type": "u64"
          },
          {
            "name": "srlpSupply",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "ammConfig",
      "docs": [
        "AMM controls. One-times peak amplification with zero widths selects the",
        "full-range CPMM branch of the same concentrated implementation."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "peakAmplificationNad",
            "type": "u64"
          },
          {
            "name": "coreHalfWidthBps",
            "type": "u16"
          },
          {
            "name": "fadeWidthBps",
            "type": "u16"
          },
          {
            "name": "centerEmaHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "volatilityHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "adjustmentStepNad",
            "type": "u64"
          },
          {
            "name": "volatilityShockCapNad",
            "type": "u64"
          },
          {
            "name": "volatilityCapNad",
            "type": "u64"
          },
          {
            "name": "divergenceFeeCoefficientNad",
            "type": "u64"
          },
          {
            "name": "volatilityFeeCoefficientNad",
            "type": "u64"
          },
          {
            "name": "swapFeeCollectMode",
            "docs": [
              "Asset in which swap, toxicity, volatility, and retained-recenter fees",
              "are denominated. Lending and hLP funding interest remain in the",
              "borrowed asset and are not affected by this setting."
            ],
            "type": "u8"
          },
          {
            "name": "compoundingFeeBps",
            "docs": [
              "Share of the LP-owned swap fee which becomes ordinary reserve",
              "principal instead of a claimable fee liability. Zero disables native",
              "compounding; `BPS_DENOMINATOR` compounds the complete LP share."
            ],
            "type": "u16"
          },
          {
            "name": "launchFeeStartBps",
            "docs": [
              "Optional launch-only base fee. The premium above `swap_fee_bps`",
              "decays from `start_time` and is zero after the configured duration."
            ],
            "type": "u16"
          },
          {
            "name": "launchFeeDurationSeconds",
            "type": "u64"
          },
          {
            "name": "launchFeeDecayMode",
            "type": "u8"
          },
          {
            "name": "launchMarketPriceStepBps",
            "docs": [
              "When all three values are zero, the launch fee follows the time",
              "schedule above. A fully nonzero tuple selects a price-milestone",
              "scheduler whose reference price is bound by the first liquidity seed."
            ],
            "type": "u16"
          },
          {
            "name": "launchMarketNumberOfPeriods",
            "type": "u16"
          },
          {
            "name": "launchMarketReductionFactorBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitAsset",
            "docs": [
              "Optional launch buy-size limiter. The configured asset is the asset",
              "being bought, not the input asset. Each full/partial reference amount",
              "after the first adds `launch_rate_limit_increment_bps`, capped by",
              "`launch_rate_limit_max_fee_bps`."
            ],
            "type": "u8"
          },
          {
            "name": "launchRateLimitReferenceNad",
            "type": "u64"
          },
          {
            "name": "launchRateLimitIncrementBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitMaxFeeBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitDurationSeconds",
            "type": "u64"
          },
          {
            "name": "reserved",
            "type": {
              "array": [
                "u8",
                0
              ]
            }
          }
        ]
      }
    },
    {
      "name": "ammState",
      "docs": [
        "Embedded mutable state for the concentrated curve, internal signals, and",
        "protected recenter liquidity."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "initialized",
            "type": "bool"
          },
          {
            "name": "concentrationRamp",
            "type": {
              "defined": {
                "name": "concentrationRamp"
              }
            }
          },
          {
            "name": "concentratedCurveCache",
            "docs": [
              "Concentrated CPMM-tail/band geometry. CPMM is represented by zero",
              "concentrated liquidity in this same cache."
            ],
            "type": {
              "defined": {
                "name": "concentratedCurveCache"
              }
            }
          },
          {
            "name": "hlpFundingBasePricingOffsetNad",
            "docs": [
              "Pricing-only translations between the ordinary ownership books and",
              "trading coordinates. Funding payments settle cash and liabilities;",
              "these non-redeemable offsets keep them outside trading principal."
            ],
            "type": "i128"
          },
          {
            "name": "hlpFundingQuotePricingOffsetNad",
            "type": "i128"
          },
          {
            "name": "centerPriceNad",
            "type": "u64"
          },
          {
            "name": "priceEmaNad",
            "type": "u64"
          },
          {
            "name": "lastTradePriceNad",
            "type": "u64"
          },
          {
            "name": "lastObservationSlot",
            "type": "u64"
          },
          {
            "name": "lastAdjustmentSlot",
            "type": "u64"
          },
          {
            "name": "launchReferencePriceNad",
            "docs": [
              "Immutable launch price reference bound by the first fully-backed",
              "liquidity seed. Zero is allowed only before that seed."
            ],
            "type": "u64"
          },
          {
            "name": "launchFeeProgressOffset",
            "docs": [
              "Fee-schedule progress already completed by a bootstrap adapter before",
              "the market graduates into GAMM."
            ],
            "type": "u16"
          },
          {
            "name": "volatilityAccumulatorNad",
            "type": "u64"
          },
          {
            "name": "curveDepthPerShareNad",
            "type": "u128"
          },
          {
            "name": "protectedFloorPerShareNad",
            "docs": [
              "srLP principal floor protected from funded recenter/ramp impairment."
            ],
            "type": "u128"
          },
          {
            "name": "retentionRequiredNad",
            "docs": [
              "Fresh protected-profit target that arms retained surcharge routing.",
              "This is a principal-budget target, never a cap on trader fees."
            ],
            "type": "u128"
          },
          {
            "name": "retentionStopNad",
            "docs": [
              "Hysteresis threshold below which retention remains armed."
            ],
            "type": "u128"
          },
          {
            "name": "retentionHardCapNad",
            "docs": [
              "Maximum protected principal one controller target may request/spend.",
              "It does not clip divergence or volatility surcharge amounts."
            ],
            "type": "u128"
          },
          {
            "name": "retainDynamicSurcharge",
            "docs": [
              "When true, dynamic surcharge is locked in the non-quoteable protected",
              "recenter bucket; when false, the identical trader charge is routed to",
              "claimable srLP fee accounting."
            ],
            "type": "bool"
          },
          {
            "name": "retentionTargetSaturated",
            "docs": [
              "The requested protection target exceeded its principal-budget cap."
            ],
            "type": "bool"
          },
          {
            "name": "retentionTargetStale",
            "docs": [
              "The protected bucket changed after the last exact forward-target solve.",
              "While stale, retention stays on until a decision point refreshes the",
              "target or executes a funded recenter."
            ],
            "type": "bool"
          },
          {
            "name": "deferredControllerTarget",
            "docs": [
              "Exact unfunded controller target retried by later real operations."
            ],
            "type": {
              "defined": {
                "name": "deferredControllerTarget"
              }
            }
          },
          {
            "name": "frozenHlpMask",
            "docs": [
              "A distressed hLP cannot be reconstructed as positive one-sided equity.",
              "Each bit freezes only that vault's share/debt hedge during swaps."
            ],
            "type": "u8"
          },
          {
            "name": "frozenBaseVaultBaseOffsetNad",
            "docs": [
              "Fixed virtual-coordinate adjustment captured when the vault freezes.",
              "It preserves the pre-freeze executable price without treating the",
              "vault's negative equity as spendable token inventory."
            ],
            "type": "i128"
          },
          {
            "name": "frozenBaseVaultQuoteOffsetNad",
            "type": "i128"
          },
          {
            "name": "frozenQuoteVaultBaseOffsetNad",
            "type": "i128"
          },
          {
            "name": "frozenQuoteVaultQuoteOffsetNad",
            "type": "i128"
          },
          {
            "name": "reserved",
            "type": {
              "array": [
                "u8",
                0
              ]
            }
          }
        ]
      }
    },
    {
      "name": "announceOperatorChangeArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "nonce",
            "type": "u64"
          },
          {
            "name": "expectedEpoch",
            "type": "u64"
          },
          {
            "name": "updates",
            "type": {
              "vec": {
                "defined": {
                  "name": "marketParameterUpdate"
                }
              }
            }
          },
          {
            "name": "nextOperator",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "nextManager",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "revenueRecipient",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "interestShareBps",
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "proposalMetadataV1"
              }
            }
          }
        ]
      }
    },
    {
      "name": "beginFlashLiquidationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "maxRepayment",
            "type": "u64"
          },
          {
            "name": "maxPayment",
            "type": "u64"
          },
          {
            "name": "minCollateralCredit",
            "type": "u64"
          },
          {
            "name": "minBuyerCredit",
            "docs": [
              "Minimum final debt-token credit for the paired Dusk-AMM settlement.",
              "External routes must use zero and enforce their own route slippage."
            ],
            "type": "u64"
          },
          {
            "name": "full",
            "type": "bool"
          },
          {
            "name": "settleIndex",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "beginHlpFlashArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "maxPayment",
            "type": "u64"
          },
          {
            "name": "allowFull",
            "type": "bool"
          },
          {
            "name": "maxSocializedLoss",
            "type": "u64"
          },
          {
            "name": "maxCollateralDebit",
            "type": "u64"
          },
          {
            "name": "minCollateralCredit",
            "type": "u64"
          },
          {
            "name": "settleIndex",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "borrowArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "borrowAmount",
            "type": "u64"
          },
          {
            "name": "minDebtAmountOut",
            "type": "u64"
          },
          {
            "name": "minLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "referrer",
            "type": {
              "option": "pubkey"
            }
          }
        ]
      }
    },
    {
      "name": "borrowCapacityPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "collateralAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "debtAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "collateralValueNad",
            "type": "u128"
          },
          {
            "name": "maxDebtByHealth",
            "type": "u64"
          },
          {
            "name": "maxDebtByCash",
            "type": "u64"
          },
          {
            "name": "maxDebtByDailyLimit",
            "type": "u64"
          },
          {
            "name": "maxDebt",
            "type": "u64"
          },
          {
            "name": "maxBorrowAmount",
            "type": "u64"
          },
          {
            "name": "borrowMarketHealthFloorBps",
            "type": "u16"
          },
          {
            "name": "globalHealthContributionCapBps",
            "type": "u16"
          },
          {
            "name": "projectedBorrowAmount",
            "type": "u64"
          },
          {
            "name": "projectedDebtAmount",
            "type": "u64"
          },
          {
            "name": "projectedHealthBps",
            "type": "u64"
          },
          {
            "name": "projectedGlobalMarketHealthBps",
            "type": "u64"
          },
          {
            "name": "projectedGlobalHealthContribution",
            "type": "u64"
          },
          {
            "name": "projectedEffectiveExistingDebtNad",
            "type": "u128"
          },
          {
            "name": "maxCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationDebtPerCollateralPriceNad",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "borrowInterestAccrued",
      "docs": [
        "Interest recognized by one committed borrow-index checkpoint. Amounts are",
        "raw atoms of `asset_mint`, separately floored in each debt-share bucket.",
        "This is accrued interest, not a payment or a protocol-revenue allocation."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "assetSide",
            "type": "u8"
          },
          {
            "name": "fromSlot",
            "type": "u64"
          },
          {
            "name": "toSlot",
            "type": "u64"
          },
          {
            "name": "borrowIndexBeforeNad",
            "type": "u128"
          },
          {
            "name": "borrowIndexAfterNad",
            "type": "u128"
          },
          {
            "name": "creditInterest",
            "type": "u128"
          },
          {
            "name": "marginInterest",
            "type": "u128"
          },
          {
            "name": "hlpInterest",
            "type": "u128"
          },
          {
            "name": "protocolCredit",
            "docs": [
              "Split of the interest recognized by this accrual: protocol share",
              "(paid only), operator and LP credits, and hLP vault public interest",
              "netted against its funding debt."
            ],
            "type": "u64"
          },
          {
            "name": "operatorCredit",
            "type": "u64"
          },
          {
            "name": "lpCredit",
            "type": "u64"
          },
          {
            "name": "vaultNetted",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "borrowInterestPaid",
      "docs": [
        "Canonical interest-payment record. Lifecycle and referral events may",
        "repeat these amounts for context and must not be summed a second time."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "assetSide",
            "type": "u8"
          },
          {
            "name": "source",
            "type": {
              "defined": {
                "name": "debtSource"
              }
            }
          },
          {
            "name": "position",
            "docs": [
              "None for aggregate hLP funding debt; `asset_side` identifies its vault."
            ],
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "interestPaid",
            "docs": [
              "Interest collected. It stays in reserve cash, credited to holders at",
              "accrual; only the protocol share leaves cash."
            ],
            "type": "u64"
          },
          {
            "name": "protocolInterestRevenue",
            "docs": [
              "Protocol share of `interest_paid`, before the referral allocation."
            ],
            "type": "u64"
          },
          {
            "name": "referralAmount",
            "type": "u64"
          },
          {
            "name": "callerBounty",
            "docs": [
              "Gross terminal hLP caller bounty; zero for ordinary payments."
            ],
            "type": "u64"
          },
          {
            "name": "slot",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "borrowPosition",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "baseCollateral",
            "type": "u64"
          },
          {
            "name": "quoteCollateral",
            "type": "u64"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "baseReferralPartner",
            "type": "pubkey"
          },
          {
            "name": "quoteReferralPartner",
            "type": "pubkey"
          },
          {
            "name": "baseReferralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "quoteReferralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "fixedBaseShares",
            "type": "u128"
          },
          {
            "name": "fixedQuoteShares",
            "type": "u128"
          },
          {
            "name": "fixedBasePrincipal",
            "docs": [
              "Original base borrowed by this position that has not been repaid or written off."
            ],
            "type": "u64"
          },
          {
            "name": "fixedQuotePrincipal",
            "docs": [
              "Original quote borrowed by this position that has not been repaid or written off."
            ],
            "type": "u64"
          },
          {
            "name": "activeLiquidationSession",
            "type": "pubkey"
          },
          {
            "name": "auctionDebtAsset",
            "type": "u8"
          },
          {
            "name": "auctionStartTime",
            "type": "i64"
          },
          {
            "name": "auctionStartPriceNad",
            "type": "u64"
          },
          {
            "name": "auctionFloorPriceNad",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "borrowPositionCapacityKind",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "borrow"
          },
          {
            "name": "withdraw"
          }
        ]
      }
    },
    {
      "name": "borrowPositionCapacityPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "collateralAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "debtAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "currentCollateralAmount",
            "type": "u64"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "existingDebtAmount",
            "type": "u128"
          },
          {
            "name": "maxBorrowAmount",
            "type": {
              "option": "u64"
            }
          },
          {
            "name": "maxWithdrawAmount",
            "type": {
              "option": "u64"
            }
          },
          {
            "name": "projectedBorrowAmount",
            "type": "u64"
          },
          {
            "name": "projectedDebtAmount",
            "type": "u128"
          },
          {
            "name": "collateralValueNad",
            "type": "u128"
          },
          {
            "name": "maxCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationDebtPerCollateralPriceNad",
            "type": "u64"
          },
          {
            "name": "borrowAllowed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "borrowPositionLiquidated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "borrowPosition",
            "type": "pubkey"
          },
          {
            "name": "borrower",
            "type": "pubkey"
          },
          {
            "name": "liquidator",
            "type": "pubkey"
          },
          {
            "name": "debtAssetSide",
            "docs": [
              "`0` for base debt and `1` for quote debt. The collateral is the other side."
            ],
            "type": "u8"
          },
          {
            "name": "repaidAmount",
            "type": "u64"
          },
          {
            "name": "collateralSeized",
            "type": "u64"
          },
          {
            "name": "collateralToLiquidator",
            "docs": [
              "Gross collateral debited for the liquidator's transfer. Token-2022 may",
              "reduce the liquidator's net account credit."
            ],
            "type": "u64"
          },
          {
            "name": "collateralCredit",
            "docs": [
              "Net collateral credited to the liquidator after any transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "socializedLoss",
            "type": "u64"
          },
          {
            "name": "remainingDebt",
            "type": "u128"
          },
          {
            "name": "baseCollateral",
            "docs": [
              "The position's state after the liquidation."
            ],
            "type": "u64"
          },
          {
            "name": "quoteCollateral",
            "type": "u64"
          },
          {
            "name": "fixedBaseShares",
            "type": "u128"
          },
          {
            "name": "fixedQuoteShares",
            "type": "u128"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "auctionDebtAsset",
            "docs": [
              "`255` once the auction is cleared."
            ],
            "type": "u8"
          },
          {
            "name": "closed",
            "docs": [
              "The liquidation emptied the position and closed its account."
            ],
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "borrowPositionPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "baseCollateral",
            "type": "u64"
          },
          {
            "name": "quoteCollateral",
            "type": "u64"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "fixedBaseDebt",
            "type": "u128"
          },
          {
            "name": "fixedQuoteDebt",
            "type": "u128"
          },
          {
            "name": "baseDebt",
            "type": {
              "defined": {
                "name": "positionDebtSidePreview"
              }
            }
          },
          {
            "name": "quoteDebt",
            "type": {
              "defined": {
                "name": "positionDebtSidePreview"
              }
            }
          }
        ]
      }
    },
    {
      "name": "burnRetiredHlpReceiptArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "amount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "burnRetiredJuniorArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "amount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "claimOperatorRevenueArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "revenueEpoch",
            "type": "u64"
          },
          {
            "name": "maxDebit",
            "type": "u64"
          },
          {
            "name": "minimumCredit",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "closeApprovalQuote",
      "docs": [
        "Dusk-owned, transaction-local approval context. Written immediately before",
        "the read-only delegate callback and cleared before settlement. A standalone",
        "delegate invocation cannot authenticate an off-chain or old quote with it."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "closeBps",
            "type": "u16"
          },
          {
            "name": "collateralCredit",
            "type": "u64"
          },
          {
            "name": "selectedOutput",
            "type": "u64"
          },
          {
            "name": "reserved",
            "docs": [
              "Reserved to preserve the position account layout."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "closeInsolventHlpArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "maxSocializedLoss",
            "type": "u64"
          },
          {
            "name": "minCallerBountyOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "closeLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "minAmountOut",
            "type": "u64"
          },
          {
            "name": "closeBps",
            "docs": [
              "Percentage of current collateral and debt to close, in basis points."
            ],
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "closeLeverageDelegationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "position",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "concentratedCurveCache",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "mathRevision",
            "type": "u8"
          },
          {
            "name": "peakAmplificationNad",
            "type": "u64"
          },
          {
            "name": "coreHalfWidthBps",
            "type": "u16"
          },
          {
            "name": "fadeWidthBps",
            "type": "u16"
          },
          {
            "name": "tailLiquidity",
            "type": "u128"
          },
          {
            "name": "concentratedLiquidity",
            "type": "u128"
          },
          {
            "name": "coreLowerSqrtPriceNad",
            "type": "u128"
          },
          {
            "name": "coreUpperSqrtPriceNad",
            "type": "u128"
          },
          {
            "name": "outerLowerSqrtPriceNad",
            "type": "u128"
          },
          {
            "name": "outerUpperSqrtPriceNad",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "concentratedCurveParameters",
      "docs": [
        "Operator configuration surface for the concentrated curve.",
        "",
        "`peak_amplification_nad` is center liquidity depth relative to a CPMM with",
        "the same center reserves. `core_half_width_bps` keeps that complete depth",
        "active around the sticky center. `fade_width_bps` adds one deterministic",
        "half-depth shoulder before the nonzero full-range CPMM tail. One-times",
        "amplification with zero widths is exact CPMM."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "peakAmplificationNad",
            "type": "u64"
          },
          {
            "name": "coreHalfWidthBps",
            "type": "u16"
          },
          {
            "name": "fadeWidthBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "concentrationRamp",
      "docs": [
        "Scheduled targets do not mutate live geometry until a guarded step succeeds."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "active",
            "type": "bool"
          },
          {
            "name": "start",
            "type": {
              "defined": {
                "name": "concentratedCurveParameters"
              }
            }
          },
          {
            "name": "target",
            "type": {
              "defined": {
                "name": "concentratedCurveParameters"
              }
            }
          },
          {
            "name": "startSlot",
            "type": "u64"
          },
          {
            "name": "endSlot",
            "type": "u64"
          },
          {
            "name": "lastAttemptSlot",
            "docs": [
              "Successful or rejected steps are attempted at most once per slot."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "configureProtocolAuctionArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "lane",
            "type": {
              "defined": {
                "name": "protocolAuctionLane"
              }
            }
          },
          {
            "name": "source",
            "type": {
              "defined": {
                "name": "protocolRevenueSource"
              }
            }
          },
          {
            "name": "soldMint",
            "type": "pubkey"
          },
          {
            "name": "acceptedMint",
            "docs": [
              "None uses the lane's current default; an explicit mint configures this",
              "curve independently. Stored reserves always retain their payment mint."
            ],
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "params",
            "docs": [
              "Sets both virtual reserves and the streaming rate, restarting this",
              "curve at the current slot. Actual fee inventory is unaffected."
            ],
            "type": {
              "defined": {
                "name": "protocolAuctionParams"
              }
            }
          }
        ]
      }
    },
    {
      "name": "configureReferralPartnerArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referrer",
            "type": "pubkey"
          },
          {
            "name": "interestShareBps",
            "type": "u16"
          },
          {
            "name": "active",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "createLeverageDelegationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "delegatedProgram",
            "type": "pubkey"
          },
          {
            "name": "approvedActions",
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "dailyBorrowBucket",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "borrowedBucket",
            "docs": [
              "Principal lent out through the public borrow path, net of principal",
              "repaid through the public repay path. Internal hLP funding and isolated",
              "leverage do not consume this capacity. This is a 24-hour leaky/token",
              "bucket, not an exact trailing-window sum: it permits a full burst after",
              "idle and then refills at the configured daily rate."
            ],
            "type": "u64"
          },
          {
            "name": "lastDecaySlot",
            "type": "u64"
          },
          {
            "name": "decayRemainderMs",
            "docs": [
              "Numerator remainder from `limit * elapsed_ms / MS_PER_DAY`. For a fixed",
              "absolute limit, carrying it makes refill independent of how often the",
              "bucket is checkpointed. The bps-derived absolute limit can still move",
              "when conservative market depth changes."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "debt",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "fixedBaseShares",
            "type": "u128"
          },
          {
            "name": "fixedQuoteShares",
            "type": "u128"
          },
          {
            "name": "baseBorrowIndexNad",
            "type": "u128"
          },
          {
            "name": "quoteBorrowIndexNad",
            "type": "u128"
          },
          {
            "name": "baseBorrowIndexRemainder",
            "docs": [
              "Fractional index growth carried across checkpoints. Denominator is",
              "`NAD * MS_PER_YEAR`, so frequent checkpoints cannot discard interest."
            ],
            "type": "u128"
          },
          {
            "name": "quoteBorrowIndexRemainder",
            "type": "u128"
          },
          {
            "name": "baseBorrowAprNad",
            "type": "u128"
          },
          {
            "name": "quoteBorrowAprNad",
            "type": "u128"
          },
          {
            "name": "baseBorrowAprFractionE18",
            "docs": [
              "Fractional NAD APR carried by the exponential controller (scale 1e9)."
            ],
            "type": "u64"
          },
          {
            "name": "quoteBorrowAprFractionE18",
            "type": "u64"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLastAccrualSlot",
            "type": "u64"
          },
          {
            "name": "quoteLastAccrualSlot",
            "type": "u64"
          },
          {
            "name": "fixedBasePrincipal",
            "docs": [
              "Aggregate outstanding *principal* (borrowed token amount, excluding",
              "accrued interest) backing fixed margin debt on each side. Accrued",
              "interest is `fixed_*_debt - fixed_*_principal`; tracked so interest is",
              "credited to holders instead of compounding into reserves. Principal is",
              "a raw token-atom balance and is therefore bounded by the corresponding",
              "`u64` reserve custody domain."
            ],
            "type": "u64"
          },
          {
            "name": "fixedQuotePrincipal",
            "type": "u64"
          },
          {
            "name": "isolatedBaseShares",
            "docs": [
              "Aggregate isolated leverage debt. This debt contributes to utilization",
              "and interest, but is intentionally not utilized as normal margin debt.",
              "Shares remain `u128`; raw principal remains in the token account's",
              "`u64` amount domain."
            ],
            "type": "u128"
          },
          {
            "name": "isolatedQuoteShares",
            "type": "u128"
          },
          {
            "name": "isolatedBasePrincipal",
            "type": "u64"
          },
          {
            "name": "isolatedQuotePrincipal",
            "type": "u64"
          },
          {
            "name": "leverageBaseCollateral",
            "docs": [
              "Gross collateral atoms in debt-bearing leverage positions. Counts all",
              "owners and namespaces; custody donations cannot create exposure credit."
            ],
            "type": "u64"
          },
          {
            "name": "leverageQuoteCollateral",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "debtFreePositionClosed",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "leverage",
            "type": "bool"
          },
          {
            "name": "baseReceived",
            "type": "u64"
          },
          {
            "name": "quoteReceived",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "debtSource",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "credit"
          },
          {
            "name": "margin"
          },
          {
            "name": "hlp"
          }
        ]
      }
    },
    {
      "name": "decreaseLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "minRepayOut",
            "type": "u64"
          },
          {
            "name": "maxSurplusOut",
            "docs": [
              "Maximum gross debt-token remainder returned after repayment. Zero",
              "prevents wallet payouts; a bounded value permits final 1x rounding."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "deferredControllerTarget",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "kind",
            "docs": [
              "0 = none, 2 = center move."
            ],
            "type": "u8"
          },
          {
            "name": "centerPriceNad",
            "type": "u64"
          },
          {
            "name": "requiredNad",
            "type": "u128"
          },
          {
            "name": "evaluatedBaseReserveNad",
            "type": "u128"
          },
          {
            "name": "evaluatedQuoteReserveNad",
            "type": "u128"
          },
          {
            "name": "createdSlot",
            "type": "u64"
          },
          {
            "name": "saturated",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "delegatedCloseLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "minAmountOut",
            "type": "u64"
          },
          {
            "name": "closeBps",
            "docs": [
              "Proportion of the current position to close. `10_000` preserves the",
              "existing full-close behavior."
            ],
            "type": "u16"
          },
          {
            "name": "delegated",
            "type": {
              "defined": {
                "name": "delegatedCpiArgs"
              }
            }
          }
        ]
      }
    },
    {
      "name": "delegatedCpiArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "beforeIxData",
            "type": "bytes"
          },
          {
            "name": "afterIxData",
            "type": "bytes"
          },
          {
            "name": "beforeAccountsLen",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "depositCollateralArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "depositAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "depositSingleSidedArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "depositAmount",
            "type": "u64"
          },
          {
            "name": "minHlpAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "donateCollateralArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "depositAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "emergencyLiquidationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "collateralDebit",
            "docs": [
              "Collateral the caller priced. A partial sale debits exactly this",
              "amount; a full sale debits all live collateral, which must be at least",
              "this amount."
            ],
            "type": "u64"
          },
          {
            "name": "full",
            "type": "bool"
          },
          {
            "name": "minRewardCredit",
            "type": "u64"
          },
          {
            "name": "minSwapOutput",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "emergencyLiquidationQuote",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referencePriceNad",
            "docs": [
              "Symmetric collateral-price EMA (debt per collateral, NAD), not live spot."
            ],
            "type": "u64"
          },
          {
            "name": "referenceDepthNad",
            "docs": [
              "Smoothed total active curve depth used only for settlement sizing."
            ],
            "type": "u128"
          },
          {
            "name": "full",
            "type": "bool"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "collateralCredit",
            "type": "u64"
          },
          {
            "name": "swapOutput",
            "type": "u64"
          },
          {
            "name": "repayment",
            "type": "u64"
          },
          {
            "name": "sharesToBurn",
            "type": "u128"
          },
          {
            "name": "rewardCredit",
            "type": "u64"
          },
          {
            "name": "rewardDebit",
            "type": "u64"
          },
          {
            "name": "fee",
            "type": {
              "defined": {
                "name": "liquidationFeeAllocation"
              }
            }
          },
          {
            "name": "juniorFeeDebit",
            "type": "u64"
          },
          {
            "name": "revenueFeeDebit",
            "type": "u64"
          },
          {
            "name": "ownerDebit",
            "type": "u64"
          },
          {
            "name": "ownerCredit",
            "type": "u64"
          },
          {
            "name": "loss",
            "type": {
              "defined": {
                "name": "liquidationLossAllocation"
              }
            }
          },
          {
            "name": "healthBefore",
            "type": {
              "defined": {
                "name": "liquidationHealth"
              }
            }
          },
          {
            "name": "healthAfter",
            "type": {
              "defined": {
                "name": "liquidationHealth"
              }
            }
          },
          {
            "name": "rates",
            "type": {
              "defined": {
                "name": "liquidationRates"
              }
            }
          }
        ]
      }
    },
    {
      "name": "emergencyLiquidationSettled",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "caller",
            "type": "pubkey"
          },
          {
            "name": "leverage",
            "type": "bool"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "emergencyLiquidationQuote"
              }
            }
          },
          {
            "name": "remainingCollateral",
            "type": "u64"
          },
          {
            "name": "remainingDebt",
            "type": "u64"
          },
          {
            "name": "positionState",
            "docs": [
              "Complete post-settlement position state for event-only indexers."
            ],
            "type": {
              "defined": {
                "name": "liquidationPositionState"
              }
            }
          }
        ]
      }
    },
    {
      "name": "feeProfile",
      "docs": [
        "Complete mutable fee surface. The fields remain embedded in their existing",
        "`MarketConfig`/`AmmConfig` locations so this view can be used by typed",
        "operator updates without duplicating fee state."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "baseFeeBps",
            "type": "u16"
          },
          {
            "name": "divergenceFeeShareCapBps",
            "type": "u16"
          },
          {
            "name": "volatilityFeeShareCapBps",
            "type": "u16"
          },
          {
            "name": "divergenceFeeCoefficientNad",
            "type": "u64"
          },
          {
            "name": "volatilityFeeCoefficientNad",
            "type": "u64"
          },
          {
            "name": "volatilityHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "volatilityShockCapNad",
            "type": "u64"
          },
          {
            "name": "volatilityAccumulatorCapNad",
            "type": "u64"
          },
          {
            "name": "swapFeeCollectMode",
            "type": "u8"
          },
          {
            "name": "compoundingFeeBps",
            "type": "u16"
          },
          {
            "name": "launchFeeStartBps",
            "type": "u16"
          },
          {
            "name": "launchFeeDurationSeconds",
            "type": "u64"
          },
          {
            "name": "launchFeeDecayMode",
            "type": "u8"
          },
          {
            "name": "launchMarketPriceStepBps",
            "type": "u16"
          },
          {
            "name": "launchMarketNumberOfPeriods",
            "type": "u16"
          },
          {
            "name": "launchMarketReductionFactorBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitAsset",
            "type": "u8"
          },
          {
            "name": "launchRateLimitReferenceNad",
            "type": "u64"
          },
          {
            "name": "launchRateLimitIncrementBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitMaxFeeBps",
            "type": "u16"
          },
          {
            "name": "launchRateLimitDurationSeconds",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "fees",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "junior",
            "type": {
              "defined": {
                "name": "trancheIncome"
              }
            }
          },
          {
            "name": "ledger",
            "type": {
              "defined": {
                "name": "interestLedger"
              }
            }
          },
          {
            "name": "swapFeeGrowthIndexQ64",
            "type": "u128"
          },
          {
            "name": "interestGrowthIndexQ64",
            "docs": [
              "Ordinary srLP interest lane. Its denominator is srLP supply less junior",
              "reserve shares and both hLP vaults' srLP."
            ],
            "type": "u128"
          },
          {
            "name": "swapFeeGrowthRemainderScaled",
            "docs": [
              "Scaled fee entitlement not yet representable by the integer growth",
              "index. The corresponding whole-token backing already sits in",
              "`swap_fee_liability`; it must never be redistributed as unallocated",
              "revenue."
            ],
            "type": "u64"
          },
          {
            "name": "interestGrowthRemainderScaled",
            "docs": [
              "Interest counterpart of `swap_fee_growth_remainder_scaled`."
            ],
            "type": "u64"
          },
          {
            "name": "swapFeeCustodyBalance",
            "docs": [
              "Claimable swap fees physically held in the reserve vault but excluded",
              "from executable cash and live reserves."
            ],
            "type": "u64"
          },
          {
            "name": "swapFeeLiability",
            "type": "u64"
          },
          {
            "name": "unallocatedSwapFeeLiability",
            "type": "u64"
          },
          {
            "name": "swapProtocolFeeLiability",
            "type": "u64"
          },
          {
            "name": "swapBuybackFeeLiability",
            "type": "u64"
          },
          {
            "name": "interestProtocolFeeLiability",
            "docs": [
              "Booked protocol interest revenue. Its atoms sit in the reserve vault",
              "outside `cash_reserve`."
            ],
            "type": "u64"
          },
          {
            "name": "interestBuybackFeeLiability",
            "type": "u64"
          },
          {
            "name": "referralInterestLiability",
            "type": "u64"
          },
          {
            "name": "feeSwapAuction",
            "type": {
              "defined": {
                "name": "protocolAuctionState"
              }
            }
          },
          {
            "name": "feeInterestAuction",
            "type": {
              "defined": {
                "name": "protocolAuctionState"
              }
            }
          },
          {
            "name": "buybackSwapAuction",
            "type": {
              "defined": {
                "name": "protocolAuctionState"
              }
            }
          },
          {
            "name": "buybackInterestAuction",
            "type": {
              "defined": {
                "name": "protocolAuctionState"
              }
            }
          }
        ]
      }
    },
    {
      "name": "flashAmmLiquidationQuote",
      "docs": [
        "Complete quote for the optional Dusk-AMM settlement route. The buyer first",
        "receives `liquidation.collateral_credit`, returns that amount to Dusk for",
        "the paired swap, and finally receives `buyer_credit` debt tokens after the",
        "liquidation obligation and debt-token transfer fee."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "liquidation",
            "type": {
              "defined": {
                "name": "flashLiquidationQuote"
              }
            }
          },
          {
            "name": "swapOutput",
            "type": "u64"
          },
          {
            "name": "obligation",
            "type": "u64"
          },
          {
            "name": "buyerDebit",
            "type": "u64"
          },
          {
            "name": "buyerCredit",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "flashLiquidationBegun",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "session",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "flashLiquidationQuote"
              }
            }
          }
        ]
      }
    },
    {
      "name": "flashLiquidationQuote",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "full",
            "type": "bool"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "collateralCredit",
            "type": "u64"
          },
          {
            "name": "payment",
            "docs": [
              "Bound net spendable payment before distribution, including repayment,",
              "liquidation fee and any full-purchase proceeds belonging to the owner."
            ],
            "type": "u64"
          },
          {
            "name": "repayment",
            "type": "u64"
          },
          {
            "name": "ownerSurplus",
            "type": "u64"
          },
          {
            "name": "fee",
            "type": {
              "defined": {
                "name": "liquidationFeeAllocation"
              }
            }
          },
          {
            "name": "debtSharesToBurn",
            "type": "u128"
          },
          {
            "name": "healthBefore",
            "type": {
              "defined": {
                "name": "liquidationHealth"
              }
            }
          },
          {
            "name": "healthAfter",
            "type": {
              "defined": {
                "name": "liquidationHealth"
              }
            }
          },
          {
            "name": "rates",
            "type": {
              "defined": {
                "name": "liquidationRates"
              }
            }
          }
        ]
      }
    },
    {
      "name": "flashLiquidationSettled",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "leverage",
            "type": "bool"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "debtRepaid",
            "type": "u64"
          },
          {
            "name": "ownerSurplus",
            "type": "u64"
          },
          {
            "name": "fee",
            "type": {
              "defined": {
                "name": "liquidationFeeAllocation"
              }
            }
          },
          {
            "name": "loss",
            "type": {
              "defined": {
                "name": "liquidationLossAllocation"
              }
            }
          },
          {
            "name": "remainingCollateral",
            "type": "u64"
          },
          {
            "name": "remainingDebt",
            "type": "u64"
          },
          {
            "name": "positionState",
            "docs": [
              "Complete post-settlement position state for event-only indexers."
            ],
            "type": {
              "defined": {
                "name": "liquidationPositionState"
              }
            }
          }
        ]
      }
    },
    {
      "name": "futarchyAuthority",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "type": "u8"
          },
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "recipients",
            "type": {
              "defined": {
                "name": "revenueRecipients"
              }
            }
          },
          {
            "name": "revenueShare",
            "type": {
              "defined": {
                "name": "revenueShare"
              }
            }
          },
          {
            "name": "maxReferralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "revenueDistribution",
            "type": {
              "defined": {
                "name": "revenueDistribution"
              }
            }
          },
          {
            "name": "protocolAuctionSplit",
            "type": {
              "defined": {
                "name": "protocolAuctionSplit"
              }
            }
          },
          {
            "name": "feeAuction",
            "type": {
              "defined": {
                "name": "protocolAuctionConfig"
              }
            }
          },
          {
            "name": "buybackAuction",
            "type": {
              "defined": {
                "name": "protocolAuctionConfig"
              }
            }
          },
          {
            "name": "globalReduceOnly",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "harvestArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "tokenKind",
            "type": {
              "defined": {
                "name": "yieldTokenKind"
              }
            }
          }
        ]
      }
    },
    {
      "name": "harvestAuthorityUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "lpMint",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "type": "u8"
          },
          {
            "name": "harvestAuthority",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "hlpClosed",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "assetSide",
            "docs": [
              "`0` for base hLP and `1` for quote hLP."
            ],
            "type": "u8"
          },
          {
            "name": "hlpAmount",
            "type": "u64"
          },
          {
            "name": "srlpAmount",
            "type": "u64"
          },
          {
            "name": "amountOut",
            "docs": [
              "Amount credited to the owner after any output transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "debtRepaid",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "srlpSupply",
            "type": "u64"
          },
          {
            "name": "hlpSupply",
            "type": "u64"
          },
          {
            "name": "baseLiveReserve",
            "type": "u128"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "hlpCohort",
      "docs": [
        "The mint-specific lifetime of one hLP receipt cohort. While current, the",
        "market vault owns the live accounting. After terminal recovery, this account",
        "holds the final yield indexes and supply so old receipts can be transferred,",
        "harvested and burned without acquiring backing from a new deposit cohort."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "mint",
            "type": "pubkey"
          },
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "retired",
            "type": "bool"
          },
          {
            "name": "finalVault",
            "type": {
              "defined": {
                "name": "hlpVault"
              }
            }
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "hlpCohortRotated",
      "docs": [
        "A terminal hLP cohort retains its funded yield rights while a new mint",
        "becomes the receipt for future single-sided deposits on the same market."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "retiredMint",
            "type": "pubkey"
          },
          {
            "name": "newMint",
            "type": "pubkey"
          },
          {
            "name": "retiredSupply",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpDepositCapacityPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "targetAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "hlpMint",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "epoch",
            "type": "u64"
          },
          {
            "name": "status",
            "type": {
              "defined": {
                "name": "hlpDepositStatus"
              }
            }
          },
          {
            "name": "fundingLimitGross",
            "docs": [
              "Exact funding ceiling, NOT a promise that all smaller amounts execute.",
              "Actual deposits still enforce rounding, settlement, custody and slippage.",
              "Gross wallet debit, including the current epoch's transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "fundingLimitNet",
            "docs": [
              "Greatest net target reserve credit supported by opposite-asset funding."
            ],
            "type": "u64"
          },
          {
            "name": "minFirstDepositNet",
            "docs": [
              "Net first deposit that opens this side's empty vault; zero once the",
              "side has receipts. A first deposit must borrow at least one atom of",
              "the opposite asset or it fails `HlpFirstDepositTooSmall`. This quotes",
              "two atoms' worth at the reserve ratio behind `funding_limit_net`,",
              "after the recenter-bucket premium, so somewhat smaller first deposits",
              "can still pass; simulate the deposit for the exact boundary."
            ],
            "type": "u64"
          },
          {
            "name": "minFirstDepositGross",
            "docs": [
              "`min_first_deposit_net` as a wallet debit at the current epoch's",
              "transfer fee."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpDepositStatus",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "ready"
          },
          {
            "name": "notStarted"
          },
          {
            "name": "reduceOnly"
          },
          {
            "name": "noLiquidity"
          },
          {
            "name": "rebalanceRequired"
          },
          {
            "name": "cashConstrained"
          },
          {
            "name": "unhedgeable"
          },
          {
            "name": "noFundingCapacity"
          },
          {
            "name": "noNetDeposit"
          },
          {
            "name": "frozen"
          }
        ]
      }
    },
    {
      "name": "hlpFlashQuote",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "collateralCredit",
            "type": "u64"
          },
          {
            "name": "borrowedClaim",
            "docs": [
              "Borrowed-token srLP claim frozen when the quote is created. A full",
              "terminal session uses this value even if an interleaved Dusk swap moves",
              "the live pro-rata srLP reserve ratio before settlement."
            ],
            "type": "u64"
          },
          {
            "name": "payment",
            "docs": [
              "Spendable atoms required in the session's payment vault; includes the",
              "transfer fee from that vault to the market reserve."
            ],
            "type": "u64"
          },
          {
            "name": "reserveCredit",
            "type": "u64"
          },
          {
            "name": "discountBps",
            "type": "u16"
          },
          {
            "name": "full",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "hlpFlashSession",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "hlpFlashQuote"
              }
            }
          },
          {
            "name": "maxSocializedLoss",
            "type": "u64"
          },
          {
            "name": "paymentBalanceBefore",
            "type": "u64"
          },
          {
            "name": "hlpSupply",
            "type": "u64"
          },
          {
            "name": "beginIndex",
            "type": "u16"
          },
          {
            "name": "settleIndex",
            "type": "u16"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "hlpFlashSettled",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "hlpFlashQuote"
              }
            }
          },
          {
            "name": "baseHlpSrlpMinted",
            "docs": [
              "Internal srLP changes made by this flash recovery. They are not user",
              "liquidity deposits or exits and are included here to avoid a second",
              "event CPI on the compute-constrained atomic settlement path."
            ],
            "type": "u64"
          },
          {
            "name": "baseHlpSrlpBurned",
            "type": "u64"
          },
          {
            "name": "quoteHlpSrlpMinted",
            "type": "u64"
          },
          {
            "name": "quoteHlpSrlpBurned",
            "type": "u64"
          },
          {
            "name": "fundingInterestPaid",
            "type": {
              "array": [
                "u64",
                2
              ]
            }
          },
          {
            "name": "loss",
            "type": {
              "defined": {
                "name": "liquidationLossAllocation"
              }
            }
          },
          {
            "name": "surplusCredit",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpFlashStarted",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "hlpFlashQuote"
              }
            }
          }
        ]
      }
    },
    {
      "name": "hlpOpened",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "assetSide",
            "docs": [
              "`0` for base hLP and `1` for quote hLP."
            ],
            "type": "u8"
          },
          {
            "name": "depositAmount",
            "docs": [
              "Net reserve-vault credit after any input transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "borrowedAmount",
            "type": "u64"
          },
          {
            "name": "srlpAmount",
            "type": "u64"
          },
          {
            "name": "hlpAmount",
            "type": "u64"
          },
          {
            "name": "srlpSupply",
            "type": "u64"
          },
          {
            "name": "hlpSupply",
            "type": "u64"
          },
          {
            "name": "baseLiveReserve",
            "type": "u128"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "hlpOrderTriggerPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "principalNavPerTokenNad",
            "type": "u64"
          },
          {
            "name": "fundingAprEmaNad",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "hlpRebalanced",
      "docs": [
        "Internal vault-owned srLP changes from one completed hLP hedge transition.",
        "Ordinary srLP deposits and exits continue to use `LiquidityAdded` and",
        "`LiquidityRemoved`. This event includes both vaults because one operation",
        "can burn shares in one vault and mint them in the other. Debt changes are",
        "indexed-debt changes; funding interest is also reported by the canonical",
        "`BorrowInterestPaid` event and must not be counted twice as revenue."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "baseHlpSrlpMinted",
            "type": "u64"
          },
          {
            "name": "baseHlpSrlpBurned",
            "type": "u64"
          },
          {
            "name": "quoteHlpSrlpMinted",
            "type": "u64"
          },
          {
            "name": "quoteHlpSrlpBurned",
            "type": "u64"
          },
          {
            "name": "baseHlpSrlpSharesAfter",
            "type": "u64"
          },
          {
            "name": "quoteHlpSrlpSharesAfter",
            "type": "u64"
          },
          {
            "name": "srlpSupplyAfter",
            "type": "u64"
          },
          {
            "name": "baseHlpDebtIncrease",
            "docs": [
              "Quote-token debt of the base-target hLP."
            ],
            "type": "u64"
          },
          {
            "name": "baseHlpDebtDecrease",
            "type": "u64"
          },
          {
            "name": "baseHlpDebtAfter",
            "type": "u64"
          },
          {
            "name": "quoteHlpDebtIncrease",
            "docs": [
              "Base-token debt of the quote-target hLP."
            ],
            "type": "u64"
          },
          {
            "name": "quoteHlpDebtDecrease",
            "type": "u64"
          },
          {
            "name": "quoteHlpDebtAfter",
            "type": "u64"
          },
          {
            "name": "baseHlpFundingInterestPaid",
            "docs": [
              "Quote funding interest the base-target hLP paid. Only its protocol",
              "share leaves reserve cash."
            ],
            "type": "u64"
          },
          {
            "name": "quoteHlpFundingInterestPaid",
            "docs": [
              "Base funding interest the quote-target hLP paid."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpRetiredReceiptBurned",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "mint",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "remainingSupply",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpTerminalLiquidated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "caller",
            "type": "pubkey"
          },
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "debtClosed",
            "type": "u64"
          },
          {
            "name": "srlpBurned",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "docs": [
              "Borrowed-asset funding interest credited to srLP after caller bounty and",
              "transfer fees."
            ],
            "type": "u64"
          },
          {
            "name": "callerBounty",
            "docs": [
              "Borrowed-asset amount credited to the caller after transfer fees."
            ],
            "type": "u64"
          },
          {
            "name": "socializedLoss",
            "docs": [
              "Residual funded principal loss. Unpaid interest is reported separately."
            ],
            "type": "u64"
          },
          {
            "name": "interestCanceled",
            "type": "u64"
          },
          {
            "name": "remainingHlpSupply",
            "docs": [
              "Existing holder tokens remain burnable for zero principal while their",
              "already-checkpointed fee claims remain independently claimable."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "hlpVault",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "flashCollateralDebit",
            "docs": [
              "Collateral committed to one atomic flash recovery. Receipt supply is",
              "fixed until settlement; retail operations on other positions may run."
            ],
            "type": "u64"
          },
          {
            "name": "srlpVault",
            "type": "pubkey"
          },
          {
            "name": "srlpShares",
            "type": "u64"
          },
          {
            "name": "baseHlpLiveReserve",
            "docs": [
              "hLP-owned live reserve depth that is not backed by reserve cash or",
              "normal cash-backed debt. This is the explicit synthetic live component",
              "in `r_virtual = r_cash + r_cash_backed_debt + r_hlp_live`."
            ],
            "type": "u64"
          },
          {
            "name": "quoteHlpLiveReserve",
            "type": "u64"
          },
          {
            "name": "debtShares",
            "docs": [
              "Funding debt used by the hLP vault. It accrues interest and counts",
              "toward utilization, but is not same-side cash-backed reserve debt."
            ],
            "type": "u128"
          },
          {
            "name": "debtPrincipal",
            "docs": [
              "Raw borrowed token atoms; products and indexed shares stay `u128`."
            ],
            "type": "u64"
          },
          {
            "name": "hlpSupply",
            "type": "u64"
          },
          {
            "name": "residualExposure",
            "type": "i128"
          },
          {
            "name": "baseSwapFeeGrowthIndexQ64",
            "type": "u128"
          },
          {
            "name": "baseInterestGrowthIndexQ64",
            "docs": [
              "Holder index of interest credited to this vault at accrual."
            ],
            "type": "u128"
          },
          {
            "name": "quoteSwapFeeGrowthIndexQ64",
            "type": "u128"
          },
          {
            "name": "quoteInterestGrowthIndexQ64",
            "type": "u128"
          },
          {
            "name": "baseSwapFeeCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "quoteSwapFeeCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "baseSwapFeeRemainderQ64",
            "docs": [
              "Aggregate sub-atom srLP swap-fee entitlement carried across hLP",
              "checkpoints. Distinct from each holder YieldAccount remainder: this",
              "layer converts vault-owned srLP growth into hLP growth without",
              "double-flooring."
            ],
            "type": "u64"
          },
          {
            "name": "quoteSwapFeeRemainderQ64",
            "type": "u64"
          },
          {
            "name": "baseSwapFeeGrowthRemainderScaled",
            "docs": [
              "Sub-index distribution carry for the second, srLP-to-hLP allocation",
              "layer. Whole-token backing represented here has already left the",
              "corresponding `unallocated_*` bucket."
            ],
            "type": "u64"
          },
          {
            "name": "baseInterestGrowthRemainderScaled",
            "type": "u64"
          },
          {
            "name": "quoteSwapFeeGrowthRemainderScaled",
            "type": "u64"
          },
          {
            "name": "quoteInterestGrowthRemainderScaled",
            "type": "u64"
          },
          {
            "name": "unallocatedBaseSwapFeeAmount",
            "type": "u64"
          },
          {
            "name": "unallocatedBaseInterestAmount",
            "type": "u64"
          },
          {
            "name": "unallocatedQuoteSwapFeeAmount",
            "type": "u64"
          },
          {
            "name": "unallocatedQuoteInterestAmount",
            "type": "u64"
          },
          {
            "name": "lastNavNad",
            "type": "u128"
          },
          {
            "name": "cachedSettlementPriceNad",
            "docs": [
              "Base quoted in quote NAD units for either target asset; zero means unset."
            ],
            "type": "u128"
          },
          {
            "name": "fundingAprEmaNad",
            "docs": [
              "Smoothed APR of the opposite asset borrowed by this target-asset hLP.",
              "The fixed twelve-hour half-life gives Stop Rate orders stable semantics."
            ],
            "type": "u128"
          },
          {
            "name": "fundingAprEmaLastSlot",
            "type": "u64"
          },
          {
            "name": "heldBaseInterest",
            "docs": [
              "Public interest credited to the vault's srLP while it was frozen,",
              "net of funding netting. It stays in `credited` for the vault's",
              "creditors: a terminal close applies it to the vault's debt, and a",
              "recovery that unfreezes the vault publishes it to the holders."
            ],
            "type": "u64"
          },
          {
            "name": "heldQuoteInterest",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "increaseLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "debtAmount",
            "type": "u64"
          },
          {
            "name": "marginAmount",
            "docs": [
              "Gross debt-token funding from the owner. Zero increases size using borrowing only."
            ],
            "type": "u64"
          },
          {
            "name": "minCollateralOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "initFutarchyAuthorityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "swapBps",
            "docs": [
              "None uses DEFAULT_PROTOCOL_REVENUE_SHARE_BPS; Some(0) explicitly disables the share."
            ],
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "interestBps",
            "docs": [
              "Global additive interest markup. None uses the protocol default; Some(0) disables markup."
            ],
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "maxReferralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "futarchyTreasury",
            "type": "pubkey"
          },
          {
            "name": "futarchyTreasuryBps",
            "type": "u16"
          },
          {
            "name": "buybacksVault",
            "type": "pubkey"
          },
          {
            "name": "buybacksVaultBps",
            "type": "u16"
          },
          {
            "name": "teamTreasury",
            "type": "pubkey"
          },
          {
            "name": "teamTreasuryBps",
            "type": "u16"
          },
          {
            "name": "stakingVault",
            "type": "pubkey"
          },
          {
            "name": "feeAuctionAcceptedMint",
            "type": "pubkey"
          },
          {
            "name": "buybackAuctionAcceptedMint",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "initializeJuniorArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "generation",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "initializeLpMetadataArgs"
              }
            }
          }
        ]
      }
    },
    {
      "name": "initializeLpMetadataArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "name",
            "type": "string"
          },
          {
            "name": "symbol",
            "type": "string"
          },
          {
            "name": "uri",
            "type": "string"
          }
        ]
      }
    },
    {
      "name": "initializeMarketArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "paramsHash",
            "docs": [
              "First in the wire payload so account validation reads only the PDA seed."
            ],
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "config",
            "type": {
              "defined": {
                "name": "marketConfig"
              }
            }
          },
          {
            "name": "operatorInterestShareBps",
            "docs": [
              "Operator share of base interest; protocol markup is global and additive."
            ],
            "type": "u16"
          },
          {
            "name": "oracle",
            "docs": [
              "Initial oracle policy, installed atomically with the market. None uses",
              "native pricing. First liquidity authenticates a current report when",
              "the selected weight is positive. Oracle sources/policy are creation-only."
            ],
            "type": {
              "option": {
                "defined": {
                  "name": "oraclePolicy"
                }
              }
            }
          },
          {
            "name": "bootstrapPriceNad",
            "docs": [
              "Optional final bootstrap price imported by a permissionless launch",
              "adapter. Zero binds the reference to the first fully-backed seed."
            ],
            "type": "u64"
          },
          {
            "name": "launchFeeProgressOffset",
            "docs": [
              "Number of price-fee periods already completed before graduation."
            ],
            "type": "u16"
          },
          {
            "name": "srlpMetadata",
            "docs": [
              "Metadata for the three LP mints, created atomically with the market."
            ],
            "type": {
              "defined": {
                "name": "initializeLpMetadataArgs"
              }
            }
          },
          {
            "name": "baseHlpMetadata",
            "type": {
              "defined": {
                "name": "initializeLpMetadataArgs"
              }
            }
          },
          {
            "name": "quoteHlpMetadata",
            "type": {
              "defined": {
                "name": "initializeLpMetadataArgs"
              }
            }
          }
        ]
      }
    },
    {
      "name": "initializeYieldAccountsArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "type": {
              "defined": {
                "name": "yieldTokenKind"
              }
            }
          }
        ]
      }
    },
    {
      "name": "interestLedger",
      "docs": [
        "Per-asset interest ledger. Interest is credited to holders when it",
        "accrues; claims are paid from reserve cash.",
        "",
        "With `C = cash_reserve + flash_receivable`, `D` borrower principal,",
        "`I = public_recognized + funding_recognized`, `Q = credited`,",
        "`Pu = protocol_unpaid` and `Δ = deficit`, every instruction preserves",
        "`C + D + I + Δ = curve_reserve + Q + Pu`."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "publicRecognized",
            "docs": [
              "Public fixed and isolated interest outstanding (debt minus principal,",
              "clamped as in `public_unpaid_interest`) as last recognized."
            ],
            "type": "u128"
          },
          {
            "name": "fundingRecognized",
            "docs": [
              "The opposite hLP vault's indexed funding debt in this asset minus its",
              "`debt_principal` (including carried funding) as last recognized."
            ],
            "type": "u128"
          },
          {
            "name": "credited",
            "docs": [
              "Credited, unclaimed interest of every holder lane, the junior seed,",
              "both hLP holder indexes, checkpointed holder balances, the operator,",
              "and index rounding dust. Includes `operator_claimable`."
            ],
            "type": "u128"
          },
          {
            "name": "protocolUnpaid",
            "docs": [
              "Protocol share of recognized interest not yet paid or written off."
            ],
            "type": "u128"
          },
          {
            "name": "operatorClaimable",
            "docs": [
              "Current operator recipient's credited, unclaimed share."
            ],
            "type": "u128"
          },
          {
            "name": "protocolFractionQ64",
            "docs": [
              "Q64 sub-atom carries of the accrual split."
            ],
            "type": "u64"
          },
          {
            "name": "operatorFractionQ64",
            "type": "u64"
          },
          {
            "name": "protocolPending",
            "docs": [
              "Protocol share already removed from `cash_reserve`, still in the",
              "reserve vault, awaiting `book_protocol_interest`."
            ],
            "type": "u64"
          },
          {
            "name": "deficit",
            "docs": [
              "Pool loss that LP capital could not absorb: the amount by which",
              "credited interest and the protocol's unpaid share exceed everything",
              "the pool holds or is owed. `curve_reserve` is zero while it is",
              "nonzero. Credited claims are not reduced; they are paid from cash as",
              "it allows. It never decreases."
            ],
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "juniorCohort",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "mint",
            "type": "pubkey"
          },
          {
            "name": "generation",
            "type": "u64"
          },
          {
            "name": "retired",
            "type": "bool"
          },
          {
            "name": "finalIncome",
            "type": {
              "array": [
                {
                  "defined": {
                    "name": "trancheIncome"
                  }
                },
                2
              ]
            }
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "juniorCohortInitialized",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "mint",
            "type": "pubkey"
          },
          {
            "name": "generation",
            "type": "u64"
          },
          {
            "name": "previousMint",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "juniorExitAccount",
      "docs": [
        "Burned receipt units in this account remain junior claims. They earn income",
        "through the owner's yield accounts and cannot be transferred or spent twice."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "mint",
            "type": "pubkey"
          },
          {
            "name": "ticket",
            "type": {
              "defined": {
                "name": "juniorExitTicket"
              }
            }
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "juniorExitConfig",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "minimumNoticeSlots",
            "type": "u64"
          },
          {
            "name": "maximumNoticeSlots",
            "type": "u64"
          },
          {
            "name": "exerciseWindowSlots",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "juniorExitTicket",
      "docs": [
        "Notice uses scheduled slots. The exercise window counts only slots without",
        "a verified conversion restriction; notice itself is not paused. Handlers",
        "authenticate owner/escrow and derive blocked time from protocol records."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "generation",
            "type": "u64"
          },
          {
            "name": "receipts",
            "type": "u64"
          },
          {
            "name": "readyAt",
            "type": "u64"
          },
          {
            "name": "expiresAt",
            "docs": [
              "Exclusive end before adding verified blocked time after ready_at."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "juniorSeedCompounded",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "baseAmount",
            "type": "u64"
          },
          {
            "name": "quoteAmount",
            "type": "u64"
          },
          {
            "name": "reserveShares",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "juniorSeedFunded",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "asset",
            "type": "pubkey"
          },
          {
            "name": "interestDebit",
            "type": "u64"
          },
          {
            "name": "reserveCredit",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "leverageDelegation",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "delegatedProgram",
            "type": "pubkey"
          },
          {
            "name": "approvedActions",
            "type": "u32"
          },
          {
            "name": "openCurveRevision",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "leverageDelegationUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "delegation",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "delegatedProgram",
            "type": "pubkey"
          },
          {
            "name": "approvedActions",
            "type": "u32"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "leverageMarginTerms",
      "docs": [
        "Entry terms are snapshotted in collateral units. Price, LP activity and",
        "another trader's position cannot passively rebase an existing position."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referenceCollateral",
            "type": "u64"
          },
          {
            "name": "maintenanceBoundariesBps",
            "type": {
              "array": [
                "u16",
                2
              ]
            }
          },
          {
            "name": "maintenanceRatesBps",
            "type": {
              "array": [
                "u16",
                3
              ]
            }
          },
          {
            "name": "entryBufferBps",
            "type": "u16"
          },
          {
            "name": "admissionEquityCollateralNad",
            "docs": [
              "Collateral atoms times NAD, not a fixed debt-token or dollar amount.",
              "Retained on equity extraction; released proportionally on size reduction."
            ],
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "leveragePosition",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "namespaceAuthority",
            "docs": [
              "Funding signer that established this position. Ordinary opens use the",
              "owner; sponsored entry orders use their owner-created order PDA."
            ],
            "type": "pubkey"
          },
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "referralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "marginTerms",
            "type": {
              "defined": {
                "name": "leverageMarginTerms"
              }
            }
          },
          {
            "name": "marginAmount",
            "docs": [
              "Entry equity valued in debt-token atoms, for the collateral still held.",
              "A partial close releases the sold share in proportion to collateral."
            ],
            "type": "u64"
          },
          {
            "name": "openNotional",
            "docs": [
              "Entry notional for the collateral still held, released like `margin_amount`."
            ],
            "type": "u64"
          },
          {
            "name": "debtPrincipal",
            "type": "u128"
          },
          {
            "name": "debtShares",
            "type": "u128"
          },
          {
            "name": "multiplierBps",
            "type": "u64"
          },
          {
            "name": "openedAt",
            "type": "i64"
          },
          {
            "name": "openedSlot",
            "type": "u64"
          },
          {
            "name": "openCurveRevision",
            "docs": [
              "Market curve revision committed by this opening. A recreated PDA gets",
              "a new revision even if it reopens in the same slot."
            ],
            "type": "u64"
          },
          {
            "name": "activeLiquidationSession",
            "type": "pubkey"
          },
          {
            "name": "closeApproval",
            "type": {
              "defined": {
                "name": "closeApprovalQuote"
              }
            }
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "leveragePositionClosed",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "debtAssetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralAssetMint",
            "type": "pubkey"
          },
          {
            "name": "debtRepaid",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "collateralSold",
            "type": "u64"
          },
          {
            "name": "closeoutValue",
            "type": "u64"
          },
          {
            "name": "residual",
            "type": "u64"
          },
          {
            "name": "swap",
            "type": {
              "defined": {
                "name": "leverageSwapReceipt"
              }
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "leveragePositionLiquidated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "liquidator",
            "type": "pubkey"
          },
          {
            "name": "debtAssetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralAssetMint",
            "type": "pubkey"
          },
          {
            "name": "debtRepaid",
            "type": "u64"
          },
          {
            "name": "socializedLoss",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "principalWrittenOff",
            "type": "u64"
          },
          {
            "name": "collateralSold",
            "type": "u64"
          },
          {
            "name": "closeoutValue",
            "type": "u64"
          },
          {
            "name": "liquidatorAmount",
            "type": "u64"
          },
          {
            "name": "ownerResidual",
            "type": "u64"
          },
          {
            "name": "swap",
            "type": {
              "defined": {
                "name": "leverageSwapReceipt"
              }
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "leveragePositionOpened",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "debtAssetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralAssetMint",
            "type": "pubkey"
          },
          {
            "name": "marginAmount",
            "type": "u64"
          },
          {
            "name": "borrowedAmount",
            "type": "u64"
          },
          {
            "name": "debtAmount",
            "type": "u64"
          },
          {
            "name": "debtShares",
            "type": "u128"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "marginTerms",
            "type": {
              "defined": {
                "name": "leverageMarginTerms"
              }
            }
          },
          {
            "name": "closeoutValue",
            "type": "u64"
          },
          {
            "name": "equity",
            "type": "u64"
          },
          {
            "name": "multiplierBps",
            "type": "u64"
          },
          {
            "name": "swap",
            "type": {
              "defined": {
                "name": "leverageSwapReceipt"
              }
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "leveragePositionUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "debtAssetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralAssetMint",
            "type": "pubkey"
          },
          {
            "name": "ownerDebit",
            "docs": [
              "Gross debt-token payment from the wallet, including any transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "borrowedAmount",
            "type": "u64"
          },
          {
            "name": "debtDelta",
            "type": "i128"
          },
          {
            "name": "collateralDelta",
            "type": "i128"
          },
          {
            "name": "debtAmount",
            "type": "u64"
          },
          {
            "name": "debtShares",
            "type": "u128"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "marginTerms",
            "type": {
              "defined": {
                "name": "leverageMarginTerms"
              }
            }
          },
          {
            "name": "closeoutValue",
            "docs": [
              "Executable closeout quote, or zero when unquoted by repayment or an",
              "operation leaving debt-free collateral. Zero is not a collateral valuation."
            ],
            "type": "u64"
          },
          {
            "name": "ownerCredit",
            "docs": [
              "Net tokens paid to the owner by this update, if any."
            ],
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "docs": [
              "Interest actually repaid by this action, in debt-token atoms."
            ],
            "type": "u64"
          },
          {
            "name": "swap",
            "type": {
              "option": {
                "defined": {
                  "name": "leverageSwapReceipt"
                }
              }
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "leverageSwapReceipt",
      "docs": [
        "Supporting AMM receipt embedded in a leverage action. `SwapExecuted` is",
        "the authoritative swap/fee record; do not count this receipt again.",
        "`None` on `LeveragePositionUpdated` means the action was margin-only."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "assetInSide",
            "type": "u8"
          },
          {
            "name": "feeAssetSide",
            "type": "u8"
          },
          {
            "name": "amountIn",
            "type": "u64"
          },
          {
            "name": "amountOut",
            "type": "u64"
          },
          {
            "name": "grossAmountOut",
            "type": "u64"
          },
          {
            "name": "amountInAfterFee",
            "type": "u64"
          },
          {
            "name": "baseFee",
            "type": "u64"
          },
          {
            "name": "divergenceFee",
            "type": "u64"
          },
          {
            "name": "volatilityFee",
            "type": "u64"
          },
          {
            "name": "retainedFee",
            "type": "u64"
          },
          {
            "name": "compoundedFee",
            "type": "u64"
          },
          {
            "name": "claimableFeeCredit",
            "docs": [
              "Actual reserve-vault credit after any Token-2022 transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "baseLiveReserve",
            "docs": [
              "Final executable reserves after retention and inline hLP correction."
            ],
            "type": "u128"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "liquidationAuctionCancelled",
      "docs": [
        "A fill or backstop found the position healthy again and cleared its",
        "auction without liquidating anything."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "debtAssetSide",
            "docs": [
              "Debt side of the cancelled auction: `0` for base and `1` for quote."
            ],
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "liquidationAuctionStarted",
      "docs": [
        "A liquidation auction opened on a borrow position."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "auctionDebtAsset",
            "docs": [
              "`0` for base debt and `1` for quote debt."
            ],
            "type": "u8"
          },
          {
            "name": "auctionStartTime",
            "type": "i64"
          },
          {
            "name": "auctionStartPriceNad",
            "type": "u64"
          },
          {
            "name": "auctionFloorPriceNad",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "liquidationFeeAllocation",
      "docs": [
        "Whole spendable atoms. Transfer-fee gross-ups are separate from the net fee",
        "obligation. The collected fee is never counted again as debt repayment."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "total",
            "type": "u64"
          },
          {
            "name": "protocol",
            "type": "u64"
          },
          {
            "name": "junior",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "liquidationHealth",
      "docs": [
        "Linear symmetric-EMA collateral value and actual indexed debt, both in debt",
        "token atoms. Execution prices never determine reference eligibility."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "collateralValue",
            "type": "u64"
          },
          {
            "name": "debt",
            "type": "u64"
          },
          {
            "name": "maintenanceBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "liquidationLossAllocation",
      "docs": [
        "A completed debt leg. `sale_recovery` is net of the caller reward and actual",
        "transfer costs. Unpaid borrower/leverage interest is canceled."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "principalRepaid",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "principalWrittenOff",
            "type": "u64"
          },
          {
            "name": "interestCanceled",
            "type": "u64"
          },
          {
            "name": "surplus",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "liquidationPositionState",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "baseCollateral",
            "type": "u64"
          },
          {
            "name": "quoteCollateral",
            "type": "u64"
          },
          {
            "name": "fixedBaseShares",
            "type": "u128"
          },
          {
            "name": "fixedQuoteShares",
            "type": "u128"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "leverageCollateralAmount",
            "type": "u64"
          },
          {
            "name": "leverageDebtShares",
            "type": "u128"
          },
          {
            "name": "closed",
            "docs": [
              "Economic closure: no collateral and no debt shares remain. The",
              "position account stays open until its owner withdraws through",
              "`withdraw_all_collateral` or `withdraw_repaid_leverage`."
            ],
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "liquidationRates",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "buyerDiscountBps",
            "type": "u16"
          },
          {
            "name": "emergencyRewardBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "liquidationSession",
      "docs": [
        "Exists only from begin through the exact paired settle in one transaction.",
        "Original debt and collateral allocations remain on the locked position."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "buyer",
            "type": "pubkey"
          },
          {
            "name": "collateralMint",
            "type": "pubkey"
          },
          {
            "name": "debtMint",
            "type": "pubkey"
          },
          {
            "name": "collateralVault",
            "type": "pubkey"
          },
          {
            "name": "buyerCollateralAccount",
            "type": "pubkey"
          },
          {
            "name": "repaymentVault",
            "type": "pubkey"
          },
          {
            "name": "buyerRefundAccount",
            "type": "pubkey"
          },
          {
            "name": "ownerDebtAccount",
            "type": "pubkey"
          },
          {
            "name": "originalCollateral",
            "type": "u64"
          },
          {
            "name": "originalDebtShares",
            "type": "u128"
          },
          {
            "name": "originalPrincipal",
            "type": "u128"
          },
          {
            "name": "borrowIndex",
            "type": "u128"
          },
          {
            "name": "paymentBalanceBefore",
            "type": "u64"
          },
          {
            "name": "minBuyerCredit",
            "docs": [
              "Minimum final debt-token credit when the paired Dusk AMM funds settle.",
              "External settlement routes bind their own output and leave this zero."
            ],
            "type": "u64"
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "flashLiquidationQuote"
              }
            }
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "leverage",
            "type": "bool"
          },
          {
            "name": "beginIndex",
            "type": "u16"
          },
          {
            "name": "settleIndex",
            "type": "u16"
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "liquidityAdded",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "baseReserveCredit",
            "type": "u64"
          },
          {
            "name": "quoteReserveCredit",
            "type": "u64"
          },
          {
            "name": "srlpAmount",
            "type": "u64"
          },
          {
            "name": "srlpSupply",
            "type": "u64"
          },
          {
            "name": "baseLiveReserve",
            "type": "u128"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u128"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "liquidityRemoved",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "srlpAmount",
            "type": "u64"
          },
          {
            "name": "baseReserveDebit",
            "docs": [
              "Gross amounts debited from the reserve vaults."
            ],
            "type": "u64"
          },
          {
            "name": "quoteReserveDebit",
            "type": "u64"
          },
          {
            "name": "baseOwnerCredit",
            "docs": [
              "Net amounts credited to the owner after any Token-2022 transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "quoteOwnerCredit",
            "type": "u64"
          },
          {
            "name": "srlpSupply",
            "type": "u64"
          },
          {
            "name": "baseLiveReserve",
            "type": "u128"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u128"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "lpTransferred",
      "docs": [
        "One LP transfer checkpointed by the Dusk Token-2022 transfer hook. Every LP",
        "mint's extra-account list includes the event authority and Dusk program,",
        "so every LP transfer publishes it."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "lpMint",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "docs": [
              "`0` for srLP and `1` for hLP."
            ],
            "type": "u8"
          },
          {
            "name": "sourceOwner",
            "type": "pubkey"
          },
          {
            "name": "destinationOwner",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "managerChanged",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "manager",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "market",
      "docs": [
        "Token amounts stored in reserves, positions, and shares are raw atoms.",
        "Internal curve quantities, risk depths, hLP NAV/exposure, and normalized",
        "debt/collateral values use `max(MIN_AMOUNT_DECIMALS, base_side.asset_decimals,",
        "quote_side.asset_decimals)` decimal places, twelve or more, including",
        "quantity fields with the historical `_nad` suffix. Prices, rates, and",
        "per-share ratios always retain nine-decimal NAD scaling. The quantity scale",
        "is immutable per market."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "oracle",
            "type": {
              "defined": {
                "name": "oracleState"
              }
            }
          },
          {
            "name": "version",
            "type": "u8"
          },
          {
            "name": "srlpMint",
            "type": "pubkey"
          },
          {
            "name": "baseSide",
            "type": {
              "defined": {
                "name": "marketSide"
              }
            }
          },
          {
            "name": "quoteSide",
            "type": {
              "defined": {
                "name": "marketSide"
              }
            }
          },
          {
            "name": "config",
            "type": {
              "defined": {
                "name": "marketConfig"
              }
            }
          },
          {
            "name": "amm",
            "type": {
              "defined": {
                "name": "ammState"
              }
            }
          },
          {
            "name": "debt",
            "type": {
              "defined": {
                "name": "debt"
              }
            }
          },
          {
            "name": "tranches",
            "docs": [
              "One shared junior capital budget across both reserve/debt books."
            ],
            "type": {
              "defined": {
                "name": "trancheCapital"
              }
            }
          },
          {
            "name": "juniorExitConfig",
            "type": {
              "defined": {
                "name": "juniorExitConfig"
              }
            }
          },
          {
            "name": "tranchePolicy",
            "type": {
              "defined": {
                "name": "tranchePolicy"
              }
            }
          },
          {
            "name": "juniorMint",
            "type": "pubkey"
          },
          {
            "name": "baseHlpVault",
            "type": {
              "defined": {
                "name": "hlpVault"
              }
            }
          },
          {
            "name": "quoteHlpVault",
            "type": {
              "defined": {
                "name": "hlpVault"
              }
            }
          },
          {
            "name": "risk",
            "type": {
              "defined": {
                "name": "risk"
              }
            }
          },
          {
            "name": "paramsHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "initialLiquidityAuthority",
            "docs": [
              "One-shot signer allowed to provide the first fully-backed Base/Quote",
              "seed. It is cleared permanently once srLP supply becomes nonzero."
            ],
            "type": "pubkey"
          },
          {
            "name": "operator",
            "docs": [
              "Sole per-market authority; token ownership carries no configuration rights."
            ],
            "type": {
              "defined": {
                "name": "operatorState"
              }
            }
          },
          {
            "name": "protocolInterestMarkupBps",
            "docs": [
              "Internal mirror of the global FutarchyAuthority markup, never an operator parameter."
            ],
            "type": "u16"
          },
          {
            "name": "parameterRevisions",
            "docs": [
              "Independent monotone revisions for fee, concentration, IRM, EMA,",
              "daily-borrow-limit, center-controller, and tranche parameter families."
            ],
            "type": {
              "array": [
                "u64",
                7
              ]
            }
          },
          {
            "name": "lastMarginalObservationNad",
            "docs": [
              "Latest trader-visible marginal price committed by a curve mutation."
            ],
            "type": "u64"
          },
          {
            "name": "curveRevision",
            "docs": [
              "Monotone revision for executable-curve mutations."
            ],
            "type": "u64"
          },
          {
            "name": "riskRevision",
            "docs": [
              "Curve revision represented by the materialized lending-risk snapshot."
            ],
            "type": "u64"
          },
          {
            "name": "lastUpdateSlot",
            "type": "u64"
          },
          {
            "name": "reduceOnly",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "marketAsset",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "base"
          },
          {
            "name": "quote"
          }
        ]
      }
    },
    {
      "name": "marketCollateralDeposited",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralCredit",
            "type": "u64"
          },
          {
            "name": "baseCollateral",
            "type": "u64"
          },
          {
            "name": "quoteCollateral",
            "type": "u64"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          },
          {
            "name": "position",
            "docs": [
              "Borrow position written by this deposit; the first deposit creates it."
            ],
            "type": "pubkey"
          },
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "auctionDebtAsset",
            "docs": [
              "Post-deposit auction side, `255` when none is active. A deposit that",
              "restores health cancels an active auction."
            ],
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "marketCollateralWithdrawn",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "assetCredit",
            "type": "u64"
          },
          {
            "name": "baseCollateral",
            "type": "u64"
          },
          {
            "name": "quoteCollateral",
            "type": "u64"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "closed",
            "docs": [
              "The withdrawal emptied the position and closed its account."
            ],
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "marketConfig",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "swapFeeBps",
            "type": "u16"
          },
          {
            "name": "divergenceFeeShareCapBps",
            "type": "u16"
          },
          {
            "name": "volatilityFeeShareCapBps",
            "type": "u16"
          },
          {
            "name": "targetHlpLeverageBps",
            "type": "u16"
          },
          {
            "name": "settlementDivergenceBps",
            "type": "u16"
          },
          {
            "name": "emaHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "directionalEmaHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "curveDepthEmaHalfLifeMs",
            "type": "u64"
          },
          {
            "name": "maxDailyBorrowBps",
            "type": "u16"
          },
          {
            "name": "globalHealthContributionCapBps",
            "type": "u16"
          },
          {
            "name": "borrowMarketHealthFloorBps",
            "type": "u16"
          },
          {
            "name": "amm",
            "type": {
              "defined": {
                "name": "ammConfig"
              }
            }
          },
          {
            "name": "irm",
            "type": {
              "defined": {
                "name": "riskRateConfig"
              }
            }
          },
          {
            "name": "startTime",
            "type": "i64"
          }
        ]
      }
    },
    {
      "name": "marketCreated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "baseMint",
            "type": "pubkey"
          },
          {
            "name": "quoteMint",
            "type": "pubkey"
          },
          {
            "name": "srlpMint",
            "type": "pubkey"
          },
          {
            "name": "baseCollateralVault",
            "type": "pubkey"
          },
          {
            "name": "quoteCollateralVault",
            "type": "pubkey"
          },
          {
            "name": "baseHlpMint",
            "type": "pubkey"
          },
          {
            "name": "quoteHlpMint",
            "type": "pubkey"
          },
          {
            "name": "targetHlpLeverageBps",
            "type": "u16"
          },
          {
            "name": "swapFeeBps",
            "type": "u16"
          },
          {
            "name": "config",
            "type": {
              "defined": {
                "name": "marketConfig"
              }
            }
          },
          {
            "name": "operator",
            "type": "pubkey"
          },
          {
            "name": "operatorRevenueRecipient",
            "type": "pubkey"
          },
          {
            "name": "operatorInterestShareBps",
            "type": "u16"
          },
          {
            "name": "protocolInterestMarkupBps",
            "type": "u16"
          },
          {
            "name": "oracle",
            "docs": [
              "Initial policy; an empty policy identifies an oracleless launch."
            ],
            "type": {
              "defined": {
                "name": "oraclePolicy"
              }
            }
          },
          {
            "name": "paramsHash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "initialLiquidityAuthority",
            "type": "pubkey"
          },
          {
            "name": "launchReferencePriceNad",
            "type": "u64"
          },
          {
            "name": "launchFeeProgressOffset",
            "type": "u16"
          },
          {
            "name": "version",
            "type": "u8"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          },
          {
            "name": "baseDecimals",
            "docs": [
              "Asset mint decimals, which scale every price and amount of the market."
            ],
            "type": "u8"
          },
          {
            "name": "quoteDecimals",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "marketDebtUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "debtAssetMint",
            "type": "pubkey"
          },
          {
            "name": "debtDelta",
            "type": "i128"
          },
          {
            "name": "cashDebit",
            "docs": [
              "Gross source-account debit and net destination-account credit."
            ],
            "type": "u64"
          },
          {
            "name": "cashCredit",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "fixedBaseDebt",
            "docs": [
              "Market-wide fixed debt after the update, not this position's debt."
            ],
            "type": "u128"
          },
          {
            "name": "fixedQuoteDebt",
            "type": "u128"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "baseLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "quoteLiquidationCfBps",
            "type": "u16"
          },
          {
            "name": "baseDebtHealthBps",
            "type": "u64"
          },
          {
            "name": "quoteDebtHealthBps",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          },
          {
            "name": "fixedBaseShares",
            "docs": [
              "The position's fixed debt shares after the update."
            ],
            "type": "u128"
          },
          {
            "name": "fixedQuoteShares",
            "type": "u128"
          },
          {
            "name": "auctionDebtAsset",
            "docs": [
              "Post-update auction side, `255` when none is active. A repayment that",
              "restores health cancels an active auction."
            ],
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "marketEventMetadata",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "signer",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "slot",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "marketHealth",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "effectiveBaseDebtNad",
            "type": "u128"
          },
          {
            "name": "effectiveQuoteDebtNad",
            "type": "u128"
          },
          {
            "name": "baseDebtHealthBps",
            "type": "u64"
          },
          {
            "name": "quoteDebtHealthBps",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "marketHealthUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "globalHealthBaseContributionForQuoteDebt",
            "type": "u64"
          },
          {
            "name": "globalHealthQuoteContributionForBaseDebt",
            "type": "u64"
          },
          {
            "name": "effectiveBaseDebtNad",
            "type": "u128"
          },
          {
            "name": "effectiveQuoteDebtNad",
            "type": "u128"
          },
          {
            "name": "baseDebtHealthBps",
            "type": "u64"
          },
          {
            "name": "quoteDebtHealthBps",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "marketParameterUpdate",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "fee",
            "fields": [
              {
                "defined": {
                  "name": "feeProfile"
                }
              }
            ]
          },
          {
            "name": "concentration",
            "fields": [
              {
                "name": "peakAmplificationNad",
                "type": "u64"
              },
              {
                "name": "coreHalfWidthBps",
                "type": "u16"
              },
              {
                "name": "fadeWidthBps",
                "type": "u16"
              },
              {
                "name": "rampDurationSlots",
                "type": "u64"
              }
            ]
          },
          {
            "name": "irm",
            "fields": [
              {
                "defined": {
                  "name": "riskRateUpdate"
                }
              }
            ]
          },
          {
            "name": "emaHalfLives",
            "fields": [
              {
                "name": "priceMs",
                "type": "u64"
              },
              {
                "name": "directionalPriceMs",
                "type": "u64"
              },
              {
                "name": "curveDepthMs",
                "type": "u64"
              },
              {
                "name": "centerPriceMs",
                "type": "u64"
              }
            ]
          },
          {
            "name": "dailyBorrowLimit",
            "fields": [
              {
                "name": "maxDailyBorrowBps",
                "type": "u16"
              }
            ]
          },
          {
            "name": "centerController",
            "fields": [
              {
                "name": "adjustmentStepNad",
                "type": "u64"
              }
            ]
          },
          {
            "name": "tranche",
            "fields": [
              {
                "name": "juniorIncomeShareBps",
                "type": "u16"
              }
            ]
          }
        ]
      }
    },
    {
      "name": "marketPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "base",
            "type": {
              "defined": {
                "name": "previewSide"
              }
            }
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "previewSide"
              }
            }
          },
          {
            "name": "liquidityNad",
            "type": "u128"
          },
          {
            "name": "health",
            "type": {
              "defined": {
                "name": "marketHealth"
              }
            }
          },
          {
            "name": "amm",
            "type": {
              "defined": {
                "name": "previewAmm"
              }
            }
          }
        ]
      }
    },
    {
      "name": "marketReduceOnlyUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "reduceOnly",
            "type": "bool"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "marketSide",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "assetDecimals",
            "type": "u8"
          },
          {
            "name": "hlpMint",
            "type": "pubkey"
          },
          {
            "name": "reserveVault",
            "type": "pubkey"
          },
          {
            "name": "collateralVault",
            "type": "pubkey"
          },
          {
            "name": "reserves",
            "type": {
              "defined": {
                "name": "reserves"
              }
            }
          },
          {
            "name": "shares",
            "type": {
              "defined": {
                "name": "reserveShares"
              }
            }
          },
          {
            "name": "fees",
            "type": {
              "defined": {
                "name": "fees"
              }
            }
          },
          {
            "name": "dailyBorrowBucket",
            "type": {
              "defined": {
                "name": "dailyBorrowBucket"
              }
            }
          }
        ]
      }
    },
    {
      "name": "marketSideSnapshot",
      "docs": [
        "One side of the market after a swap. Prices quote this side's asset in",
        "the opposite asset and equal `preview_market` for the same state and slot."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "spotPriceNad",
            "docs": [
              "Marginal price at this post-swap state. A later controller step or",
              "market update can change it before another trade is quoted."
            ],
            "type": "u64"
          },
          {
            "name": "priceEmaNad",
            "docs": [
              "Symmetric risk EMA of the spot price."
            ],
            "type": "u64"
          },
          {
            "name": "swapFeeGrowthIndexQ64",
            "docs": [
              "Per-srLP-share swap-fee growth, scaled by 2^64."
            ],
            "type": "u128"
          },
          {
            "name": "interestGrowthIndexQ64",
            "docs": [
              "Per-srLP-share interest growth, scaled by 2^64."
            ],
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "openLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "positionId",
            "type": "pubkey"
          },
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "marginAmount",
            "type": "u64"
          },
          {
            "name": "multiplierBps",
            "type": "u64"
          },
          {
            "name": "minCollateralOut",
            "type": "u64"
          },
          {
            "name": "referrer",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "positionOwner",
            "docs": [
              "Optional beneficiary for sponsored/delegated opens. The funding signer",
              "still supplies the margin, while the resulting position belongs to this",
              "key. `None` preserves the ordinary self-funded path."
            ],
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "limitPriceNad",
            "docs": [
              "All-in average execution limit in Quote-per-Base NAD. Zero disables the",
              "limit. Long Base requires price <= limit; long Quote requires >= limit."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "operatorChangeAnnounced",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "proposal",
            "type": "pubkey"
          },
          {
            "name": "operator",
            "type": "pubkey"
          },
          {
            "name": "nonce",
            "type": "u64"
          },
          {
            "name": "digest",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "executeAfterSlot",
            "type": "u64"
          },
          {
            "name": "deadlineSlot",
            "type": "u64"
          },
          {
            "name": "epoch",
            "type": "u64"
          },
          {
            "name": "policyVersion",
            "type": "u64"
          },
          {
            "name": "updates",
            "type": {
              "vec": {
                "defined": {
                  "name": "marketParameterUpdate"
                }
              }
            }
          },
          {
            "name": "nextOperator",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "nextManager",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "revenueRecipient",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "interestShareBps",
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "proposalMetadataV1"
              }
            }
          },
          {
            "name": "familyRevisions",
            "type": {
              "array": [
                "u64",
                7
              ]
            }
          }
        ]
      }
    },
    {
      "name": "operatorChangeResolved",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "proposal",
            "type": "pubkey"
          },
          {
            "name": "executed",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "operatorChanged",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "operator",
            "type": "pubkey"
          },
          {
            "name": "epoch",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "operatorProposal",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "operator",
            "type": "pubkey"
          },
          {
            "name": "epoch",
            "type": "u64"
          },
          {
            "name": "nonce",
            "type": "u64"
          },
          {
            "name": "policyVersion",
            "type": "u64"
          },
          {
            "name": "updates",
            "type": {
              "vec": {
                "defined": {
                  "name": "marketParameterUpdate"
                }
              }
            }
          },
          {
            "name": "nextOperator",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "nextManager",
            "docs": [
              "Some(zero) clears the manager; None leaves it unchanged."
            ],
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "revenueRecipient",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "interestShareBps",
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "proposalMetadataV1"
              }
            }
          },
          {
            "name": "familyRevisions",
            "type": {
              "array": [
                "u64",
                7
              ]
            }
          },
          {
            "name": "announcedAtSlot",
            "type": "u64"
          },
          {
            "name": "executeAfterSlot",
            "type": "u64"
          },
          {
            "name": "deadlineSlot",
            "type": "u64"
          },
          {
            "name": "rentRefund",
            "type": "pubkey"
          },
          {
            "name": "digest",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "executed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "operatorRevenueAccount",
      "docs": [
        "A sealed recipient's credited, unclaimed operator interest per asset (base,",
        "quote). Claims are paid from reserve cash as it allows."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "revenueEpoch",
            "type": "u64"
          },
          {
            "name": "claimable",
            "type": {
              "array": [
                "u128",
                2
              ]
            }
          },
          {
            "name": "sealed",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "operatorRevenueClaimed",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "revenueEpoch",
            "type": "u64"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "grossDebit",
            "type": "u64"
          },
          {
            "name": "netCredit",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "operatorState",
      "docs": [
        "Operator authority is independent from LP ownership. A governance program",
        "can hold it using a signer PDA; voting and token issuance belong outside Dusk."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "manager",
            "docs": [
              "Optional parameter delegate; operator ownership and revenue stay with authority."
            ],
            "type": "pubkey"
          },
          {
            "name": "epoch",
            "type": "u64"
          },
          {
            "name": "revenueEpoch",
            "type": "u64"
          },
          {
            "name": "nextNonce",
            "docs": [
              "Monotone across authority transfers; a closed proposal PDA cannot be reused."
            ],
            "type": "u64"
          },
          {
            "name": "pending",
            "type": "pubkey"
          },
          {
            "name": "pendingAuthor",
            "docs": [
              "Prevents a manager from replacing an operator-authored bundle."
            ],
            "type": "pubkey"
          },
          {
            "name": "revenueRecipient",
            "type": "pubkey"
          },
          {
            "name": "interestShareBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "oracleObservation",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "priceNad",
            "type": "u64"
          },
          {
            "name": "confidenceNad",
            "type": "u64"
          },
          {
            "name": "publishTime",
            "type": "i64"
          },
          {
            "name": "postedSlot",
            "type": "u64"
          },
          {
            "name": "sequence",
            "type": "u64"
          },
          {
            "name": "hash",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "sourceTimes",
            "type": {
              "array": [
                "i64",
                2
              ]
            }
          },
          {
            "name": "sourceSlots",
            "type": {
              "array": [
                "u64",
                2
              ]
            }
          },
          {
            "name": "sourceSequences",
            "docs": [
              "Independent counters retain replay protection when only one leg updates."
            ],
            "type": {
              "array": [
                "u64",
                2
              ]
            }
          },
          {
            "name": "sourceHashes",
            "docs": [
              "Each normalized report is immutable at an already observed counter."
            ],
            "type": {
              "array": [
                {
                  "array": [
                    "u8",
                    32
                  ]
                },
                2
              ]
            }
          }
        ]
      }
    },
    {
      "name": "oraclePolicy",
      "docs": [
        "Creation selects an optional policy atomically; omission uses native pricing.",
        "The policy, provider and feed identity are immutable after creation."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "format",
            "type": "u8"
          },
          {
            "name": "provider",
            "type": "pubkey"
          },
          {
            "name": "baseAccount",
            "type": "pubkey"
          },
          {
            "name": "quoteAccount",
            "type": "pubkey"
          },
          {
            "name": "baseFeedId",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "quoteFeedId",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "lambdaBps",
            "type": "u16"
          },
          {
            "name": "adjustmentCapNad",
            "type": "u64"
          },
          {
            "name": "maxAgeSeconds",
            "type": "u32"
          },
          {
            "name": "maxAgeSlots",
            "type": "u64"
          },
          {
            "name": "maxConfidenceBps",
            "type": "u16"
          },
          {
            "name": "maxPublishSkewSeconds",
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "oracleState",
      "docs": [
        "Persisted policy and replay protection. `runtime` occupies zero wire bytes",
        "and is reset on every account deserialization, including a second CPI."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "policy",
            "type": {
              "defined": {
                "name": "oraclePolicy"
              }
            }
          },
          {
            "name": "lastObservation",
            "type": {
              "defined": {
                "name": "oracleObservation"
              }
            }
          },
          {
            "name": "revision",
            "type": "u64"
          },
          {
            "name": "recognizedTailLiquidity",
            "docs": [
              "Recognized native-tail depth cannot grow merely because an OP trade",
              "moves to a different native invariant. Real ordinary LP capital scales",
              "the ceiling through its share supply; losses reduce it immediately."
            ],
            "type": "u128"
          },
          {
            "name": "recognizedOrdinarySupply",
            "type": "u64"
          },
          {
            "name": "runtime",
            "type": {
              "defined": {
                "name": "runtimePricing"
              }
            }
          }
        ]
      }
    },
    {
      "name": "orphanedHlpClosed",
      "docs": [
        "A complete direct burn left an hLP side with value but no receipts; anyone",
        "unwound it through `withdraw_single_sided` for the whole stored supply. The",
        "vault's debt was repaid from its srLP backing and the released target-asset",
        "value was booked as protocol revenue."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "caller",
            "type": "pubkey"
          },
          {
            "name": "assetSide",
            "docs": [
              "`0` for base hLP and `1` for quote hLP."
            ],
            "type": "u8"
          },
          {
            "name": "hlpAmount",
            "type": "u64"
          },
          {
            "name": "srlpAmount",
            "type": "u64"
          },
          {
            "name": "protocolRevenue",
            "type": "u64"
          },
          {
            "name": "debtRepaid",
            "type": "u64"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "positionDebtSidePreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "collateralAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "fixedDebt",
            "type": "u128"
          },
          {
            "name": "collateralAmount",
            "type": "u64"
          },
          {
            "name": "globalHealthContribution",
            "type": "u64"
          },
          {
            "name": "collateralValueNad",
            "type": "u128"
          },
          {
            "name": "healthBps",
            "type": "u64"
          },
          {
            "name": "maxCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationCfBps",
            "type": "u16"
          },
          {
            "name": "liquidationReferencePriceNad",
            "type": "u64"
          },
          {
            "name": "liquidationHealthBps",
            "type": "u64"
          },
          {
            "name": "isLiquidatable",
            "type": "bool"
          },
          {
            "name": "maxRepayAmount",
            "docs": [
              "Maximum debt-token credit that the current liquidation policy permits."
            ],
            "type": "u64"
          },
          {
            "name": "liquidationHealth",
            "type": {
              "defined": {
                "name": "liquidationHealth"
              }
            }
          },
          {
            "name": "liquidationRates",
            "type": {
              "option": {
                "defined": {
                  "name": "liquidationRates"
                }
              }
            }
          }
        ]
      }
    },
    {
      "name": "previewAddLiquidityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "baseDepositAmount",
            "type": "u64"
          },
          {
            "name": "quoteDepositAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "previewAmm",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "initialized",
            "type": "bool"
          },
          {
            "name": "executableBaseReserve",
            "type": "u64"
          },
          {
            "name": "executableQuoteReserve",
            "type": "u64"
          },
          {
            "name": "centerPriceNad",
            "type": "u64"
          },
          {
            "name": "priceEmaNad",
            "type": "u64"
          },
          {
            "name": "lastTradePriceNad",
            "type": "u64"
          },
          {
            "name": "lastObservationSlot",
            "type": "u64"
          },
          {
            "name": "lastAdjustmentSlot",
            "type": "u64"
          },
          {
            "name": "volatilityAccumulatorNad",
            "type": "u64"
          },
          {
            "name": "decayedVolatilityNad",
            "type": "u64"
          },
          {
            "name": "curveDepthNad",
            "type": "u128"
          },
          {
            "name": "curveDepthPerShareNad",
            "type": "u128"
          },
          {
            "name": "protectedFloorPerShareNad",
            "type": "u128"
          },
          {
            "name": "protectedProfitPerShareNad",
            "type": "u128"
          },
          {
            "name": "retentionRequiredNad",
            "type": "u128"
          },
          {
            "name": "retentionStopNad",
            "type": "u128"
          },
          {
            "name": "retentionHardCapNad",
            "type": "u128"
          },
          {
            "name": "retentionActive",
            "type": "bool"
          },
          {
            "name": "retentionTargetSaturated",
            "type": "bool"
          },
          {
            "name": "retentionTargetStale",
            "type": "bool"
          },
          {
            "name": "protectedRecenterBaseReserve",
            "type": "u64"
          },
          {
            "name": "protectedRecenterQuoteReserve",
            "type": "u64"
          },
          {
            "name": "peakAmplificationNad",
            "type": "u64"
          },
          {
            "name": "coreHalfWidthBps",
            "type": "u16"
          },
          {
            "name": "fadeWidthBps",
            "type": "u16"
          },
          {
            "name": "lowerRangePriceNad",
            "type": "u64"
          },
          {
            "name": "upperRangePriceNad",
            "type": "u64"
          },
          {
            "name": "concentratedCurveBranch",
            "type": "u8"
          },
          {
            "name": "ordinaryBaseReserveNad",
            "type": "u128"
          },
          {
            "name": "ordinaryQuoteReserveNad",
            "type": "u128"
          }
        ]
      }
    },
    {
      "name": "previewBorrowCapacityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "collateralAmount",
            "docs": [
              "Net deposit credit in the collateral vault. Capacity also accounts",
              "for the current fee when that collateral later exits the vault."
            ],
            "type": "u64"
          },
          {
            "name": "projectedBorrowAmount",
            "type": {
              "option": "u64"
            }
          }
        ]
      }
    },
    {
      "name": "previewBorrowPositionCapacityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "capacityKind",
            "type": {
              "defined": {
                "name": "borrowPositionCapacityKind"
              }
            }
          },
          {
            "name": "collateralChange",
            "docs": [
              "Net collateral credit (positive) or vault debit (negative), in raw mint units."
            ],
            "type": "i128"
          },
          {
            "name": "projectedBorrowAmount",
            "docs": [
              "Additional debt to draw. None quotes the maximum additional draw."
            ],
            "type": {
              "option": "u64"
            }
          }
        ]
      }
    },
    {
      "name": "previewEmergencyLiquidationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "collateralDebit",
            "type": "u64"
          },
          {
            "name": "full",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "previewFlashAmmLiquidationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "maxRepayment",
            "type": "u64"
          },
          {
            "name": "full",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "previewFlashLiquidationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "maxRepayment",
            "type": "u64"
          },
          {
            "name": "full",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "previewHlpOrderTriggerArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "hlpAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "previewSide",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "liveReserve",
            "type": "u128"
          },
          {
            "name": "cashReserve",
            "type": "u64"
          },
          {
            "name": "baseHlpBackingInventory",
            "type": "u64"
          },
          {
            "name": "quoteHlpBackingInventory",
            "type": "u64"
          },
          {
            "name": "srlpSupply",
            "type": "u64"
          },
          {
            "name": "srlpExchangeRateNad",
            "type": "u128"
          },
          {
            "name": "spotPriceNad",
            "type": "u64"
          },
          {
            "name": "priceEmaNad",
            "type": "u64"
          },
          {
            "name": "directionalPriceEmaNad",
            "type": "u64"
          },
          {
            "name": "conservativeDepthNad",
            "type": "u128"
          },
          {
            "name": "borrowIndexNad",
            "type": "u128"
          },
          {
            "name": "borrowAprNad",
            "type": "u128"
          },
          {
            "name": "utilizationBps",
            "type": "u64"
          },
          {
            "name": "fixedDebt",
            "type": "u128"
          },
          {
            "name": "isolatedDebt",
            "type": "u128"
          },
          {
            "name": "hlpFundingDebt",
            "type": "u128"
          },
          {
            "name": "totalDebt",
            "type": "u128"
          },
          {
            "name": "dailyBorrowLimit",
            "type": "u64"
          },
          {
            "name": "dailyBorrowRemaining",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "previewSwapArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "exactAssetIn",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "proposalMetadataV1",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "version",
            "type": "u8"
          },
          {
            "name": "title",
            "type": "string"
          },
          {
            "name": "descriptionUri",
            "type": "string"
          },
          {
            "name": "descriptionSha256",
            "type": {
              "array": [
                "u8",
                32
              ]
            }
          },
          {
            "name": "descriptionLen",
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionConfig",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "acceptedMint",
            "docs": [
              "Default payment mint for newly configured curves. Each curve stores its",
              "own mint; changing this default never reinterprets existing reserves."
            ],
            "type": "pubkey"
          },
          {
            "name": "recipients",
            "type": {
              "defined": {
                "name": "protocolAuctionRecipients"
              }
            }
          }
        ]
      }
    },
    {
      "name": "protocolAuctionConfigUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "lane",
            "type": "u8"
          },
          {
            "name": "acceptedMint",
            "type": "pubkey"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionConfigured",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "lane",
            "type": "u8"
          },
          {
            "name": "source",
            "type": "u8"
          },
          {
            "name": "side",
            "type": "u8"
          },
          {
            "name": "soldMint",
            "type": "pubkey"
          },
          {
            "name": "acceptedMint",
            "type": "pubkey"
          },
          {
            "name": "virtualSoldReserve",
            "type": "u64"
          },
          {
            "name": "virtualPaymentReserve",
            "type": "u64"
          },
          {
            "name": "soldRatePerDay",
            "type": "u64"
          },
          {
            "name": "startSlot",
            "type": "u64"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionLane",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "fee"
          },
          {
            "name": "buyback"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionParams",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "virtualSoldReserve",
            "docs": [
              "Initial virtual inventory in raw sold-token atoms, independent of custody."
            ],
            "type": "u64"
          },
          {
            "name": "virtualPaymentReserve",
            "docs": [
              "Initial virtual payment reserve in raw accepted-token atoms."
            ],
            "type": "u64"
          },
          {
            "name": "soldRatePerDay",
            "docs": [
              "Virtual sold-token atoms streamed per nominal protocol day. Zero stops",
              "streaming while preserving constant-product sales at the configured depth."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionRecipients",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "treasury",
            "type": "pubkey"
          },
          {
            "name": "stakingVault",
            "type": "pubkey"
          },
          {
            "name": "treasuryBps",
            "type": "u16"
          },
          {
            "name": "stakingVaultBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionRecipientsUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "lane",
            "type": "u8"
          },
          {
            "name": "treasury",
            "type": "pubkey"
          },
          {
            "name": "stakingVault",
            "type": "pubkey"
          },
          {
            "name": "treasuryBps",
            "type": "u16"
          },
          {
            "name": "stakingVaultBps",
            "type": "u16"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionSettled",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "lane",
            "type": "u8"
          },
          {
            "name": "source",
            "type": "u8"
          },
          {
            "name": "side",
            "type": "u8"
          },
          {
            "name": "bidder",
            "type": "pubkey"
          },
          {
            "name": "soldMint",
            "type": "pubkey"
          },
          {
            "name": "acceptedMint",
            "type": "pubkey"
          },
          {
            "name": "soldAmount",
            "type": "u64"
          },
          {
            "name": "soldNetAmount",
            "type": "u64"
          },
          {
            "name": "paymentAmount",
            "type": "u64"
          },
          {
            "name": "treasuryAmount",
            "type": "u64"
          },
          {
            "name": "stakingVaultAmount",
            "type": "u64"
          },
          {
            "name": "virtualSoldReserve",
            "type": "u128"
          },
          {
            "name": "virtualPaymentReserve",
            "type": "u128"
          },
          {
            "name": "remainingFeeLiability",
            "type": "u64"
          },
          {
            "name": "remainingBuybackLiability",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "protocolAuctionSplit",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "feeAuctionBps",
            "type": "u16"
          },
          {
            "name": "buybackAuctionBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionSplitUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "feeAuctionBps",
            "type": "u16"
          },
          {
            "name": "buybackAuctionBps",
            "type": "u16"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "protocolAuctionState",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "acceptedMint",
            "docs": [
              "A configured curve binds raw payment reserves to this specific mint."
            ],
            "type": "pubkey"
          },
          {
            "name": "virtualSoldReserve",
            "type": "u128"
          },
          {
            "name": "virtualPaymentReserve",
            "type": "u128"
          },
          {
            "name": "soldRatePerDay",
            "type": "u64"
          },
          {
            "name": "lastUpdateSlot",
            "docs": [
              "Initialized by governance, then advanced only by successful settlements.",
              "Fee arrivals and exhaustion of actual inventory never restart this clock."
            ],
            "type": "u64"
          },
          {
            "name": "streamRemainder",
            "docs": [
              "Fractional streamed atoms, with a denominator of nominal slots per day."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "protocolInterestMarkupCheckpointed",
      "docs": [
        "A global markup change becomes prospective after the market closes its",
        "elapsed interest under the prior setting."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "previousBps",
            "type": "u16"
          },
          {
            "name": "markupBps",
            "type": "u16"
          },
          {
            "name": "slot",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "protocolRevenueSource",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "swap"
          },
          {
            "name": "interest"
          }
        ]
      }
    },
    {
      "name": "referralAccrual",
      "docs": [
        "Claimable referral revenue for one partner, market, and debt asset."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "amount",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "referralBound",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "referrer",
            "type": "pubkey"
          },
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "interestShareBps",
            "type": "u16"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "referralInterestAccrued",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "referrer",
            "type": "pubkey"
          },
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "referralAccrual",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "interestPaid",
            "type": "u64"
          },
          {
            "name": "protocolInterestRevenue",
            "type": "u64"
          },
          {
            "name": "interestShareBps",
            "type": "u16"
          },
          {
            "name": "accruedAmount",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "referralInterestClaimed",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "referralAccrual",
            "type": "pubkey"
          },
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "vaultDebit",
            "type": "u64"
          },
          {
            "name": "recipientCredit",
            "type": "u64"
          },
          {
            "name": "remainingAccrual",
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "referralInterestShareCapUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "maxReferralInterestShareBps",
            "type": "u16"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "referralPartner",
      "docs": [
        "A permissioned, protocol-wide referral registry entry."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "interestShareBps",
            "type": "u16"
          },
          {
            "name": "active",
            "type": "bool"
          },
          {
            "name": "bump",
            "type": "u8"
          }
        ]
      }
    },
    {
      "name": "referralPartnerConfigured",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "interestShareBps",
            "type": "u16"
          },
          {
            "name": "active",
            "type": "bool"
          },
          {
            "name": "signer",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "referralRecipientUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "referralPartner",
            "type": "pubkey"
          },
          {
            "name": "authority",
            "type": "pubkey"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "removeLiquidityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "srlpAmount",
            "type": "u64"
          },
          {
            "name": "minBaseAmountOut",
            "type": "u64"
          },
          {
            "name": "minQuoteAmountOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "repayArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "repayAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "reserveShares",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "srlpSupply",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "reserves",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "flashReceivable",
            "docs": [
              "Same-transaction collateral receivable. Included in backing, excluded",
              "from cash available to swaps, loans and withdrawals."
            ],
            "type": "u64"
          },
          {
            "name": "liveReserve",
            "docs": [
              "Wider than SPL custody: includes cash, indexed public debt and synthetic",
              "hLP backing. Unpaid interest never becomes executable curve inventory."
            ],
            "type": "u128"
          },
          {
            "name": "cashReserve",
            "type": "u64"
          },
          {
            "name": "baseHlpBackingInventory",
            "docs": [
              "Physical reserve-vault atoms removed from executable AMM inventory by",
              "base-hLP deleveraging. They are conservation-only bookkeeping, excluded",
              "from hLP NAV and exit output, and return to executable cash pro rata as",
              "base hLP exits."
            ],
            "type": "u64"
          },
          {
            "name": "quoteHlpBackingInventory",
            "docs": [
              "Quote-hLP counterpart of `base_hlp_backing_inventory`; never a second",
              "hLP NAV or withdrawal claim."
            ],
            "type": "u64"
          },
          {
            "name": "protectedRecenterReserve",
            "docs": [
              "Physical reserve-vault atoms retained from toxicity surcharge for a",
              "future protected recenter. They are custody-backed but excluded from",
              "executable cash/live reserves, srLP NAV, and every withdrawal claim."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "retiredJuniorBurned",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "mint",
            "type": "pubkey"
          },
          {
            "name": "walletAmount",
            "type": "u64"
          },
          {
            "name": "escrowAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "revenueDistribution",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "futarchyTreasuryBps",
            "type": "u16"
          },
          {
            "name": "buybacksVaultBps",
            "type": "u16"
          },
          {
            "name": "teamTreasuryBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "revenueRecipients",
      "docs": [
        "Revenue recipient wallet addresses. Recipient token accounts are derived or",
        "validated against these owners when protocol fees are claimed."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "futarchyTreasury",
            "type": "pubkey"
          },
          {
            "name": "buybacksVault",
            "type": "pubkey"
          },
          {
            "name": "teamTreasury",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "revenueShare",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "swapBps",
            "type": "u16"
          },
          {
            "name": "interestBps",
            "docs": [
              "Global markup added to base borrowing interest. Each market closes",
              "elapsed interest at its previous value before binding a changed markup."
            ],
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "risk",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "basePriceEmaNad",
            "type": "u64"
          },
          {
            "name": "quotePriceEmaNad",
            "type": "u64"
          },
          {
            "name": "directionalBasePriceEmaNad",
            "type": "u64"
          },
          {
            "name": "directionalQuotePriceEmaNad",
            "type": "u64"
          },
          {
            "name": "cachedSpotBasePriceNad",
            "type": "u64"
          },
          {
            "name": "cachedSpotQuotePriceNad",
            "type": "u64"
          },
          {
            "name": "observedCurveDepthNad",
            "docs": [
              "Last observed total active curve depth in market amount units (see Market)."
            ],
            "type": "u128"
          },
          {
            "name": "curveDepthEmaNad",
            "docs": [
              "EMA of total active curve depth in market amount units (see Market)."
            ],
            "type": "u128"
          },
          {
            "name": "lastSnapshotSlot",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "riskRateConfig",
      "docs": [
        "Coverage-and-utilization controller configuration. Initial APR is creation-only."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "lowerSignalNad",
            "type": "u64"
          },
          {
            "name": "upperSignalNad",
            "type": "u64"
          },
          {
            "name": "lowerUtilizationBps",
            "type": "u16"
          },
          {
            "name": "upperUtilizationBps",
            "type": "u16"
          },
          {
            "name": "halfLifeMs",
            "type": "u64"
          },
          {
            "name": "initialAprNad",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "riskRateUpdate",
      "docs": [
        "Prospective controller settings. Initial APR and the protocol-wide floor",
        "cannot be changed after pool creation."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "lowerSignalNad",
            "type": "u64"
          },
          {
            "name": "upperSignalNad",
            "type": "u64"
          },
          {
            "name": "lowerUtilizationBps",
            "type": "u16"
          },
          {
            "name": "upperUtilizationBps",
            "type": "u16"
          },
          {
            "name": "halfLifeMs",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "rotateHlpCohortArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "targetAsset",
            "type": "u8"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "initializeLpMetadataArgs"
              }
            }
          }
        ]
      }
    },
    {
      "name": "runtimePricing",
      "type": {
        "kind": "struct",
        "fields": []
      }
    },
    {
      "name": "setGlobalReduceOnlyArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "reduceOnly",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "setHarvestAuthorityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "tokenKind",
            "type": {
              "defined": {
                "name": "yieldTokenKind"
              }
            }
          },
          {
            "name": "harvestAuthority",
            "docs": [
              "`None` revokes the independent caller; the recipient is unchanged."
            ],
            "type": {
              "option": "pubkey"
            }
          }
        ]
      }
    },
    {
      "name": "setMarketReduceOnlyArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "reduceOnly",
            "type": "bool"
          }
        ]
      }
    },
    {
      "name": "setReferralRecipientArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "recipient",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "setYieldRecipientArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "tokenKind",
            "type": {
              "defined": {
                "name": "yieldTokenKind"
              }
            }
          },
          {
            "name": "recipient",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "settleProtocolAuctionArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "lane",
            "type": {
              "defined": {
                "name": "protocolAuctionLane"
              }
            }
          },
          {
            "name": "source",
            "type": {
              "defined": {
                "name": "protocolRevenueSource"
              }
            }
          },
          {
            "name": "soldAmount",
            "type": "u64"
          },
          {
            "name": "maxPaymentAmount",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "swapArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "exactAssetIn",
            "type": "u64"
          },
          {
            "name": "minAssetOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "swapExecuted",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "trader",
            "docs": [
              "Beneficial owner of the trade, including delegated leverage actions."
            ],
            "type": "pubkey"
          },
          {
            "name": "actor",
            "type": "pubkey"
          },
          {
            "name": "position",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "origin",
            "type": {
              "defined": {
                "name": "swapOrigin"
              }
            }
          },
          {
            "name": "slot",
            "type": "u64"
          },
          {
            "name": "assetInSide",
            "docs": [
              "`0` for base input and `1` for quote input."
            ],
            "type": "u8"
          },
          {
            "name": "amountIn",
            "docs": [
              "AMM input before trading fees, after any input transfer fee. Includes",
              "internally borrowed principal; this is not the owner's wallet debit."
            ],
            "type": "u64"
          },
          {
            "name": "amountOut",
            "docs": [
              "AMM output after trading fees, before any output transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "grossAmountOut",
            "docs": [
              "Curve output before an output-denominated fee and transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "feeAssetSide",
            "docs": [
              "`0` for Base and `1` for Quote."
            ],
            "type": "u8"
          },
          {
            "name": "amountInAfterFee",
            "docs": [
              "Input applied to the invariant after all swap fees."
            ],
            "type": "u64"
          },
          {
            "name": "baseFee",
            "type": "u64"
          },
          {
            "name": "divergenceFee",
            "type": "u64"
          },
          {
            "name": "volatilityFee",
            "type": "u64"
          },
          {
            "name": "retainedFee",
            "docs": [
              "Dynamic surcharge retained outside executable/srLP inventory until an",
              "admitted center move deploys it."
            ],
            "type": "u64"
          },
          {
            "name": "compoundedFee",
            "docs": [
              "LP-owned fee compounded into reserve principal."
            ],
            "type": "u64"
          },
          {
            "name": "hlpRecoveryTargetAsset",
            "docs": [
              "Extra output funded by deleveraging the stressed hLP."
            ],
            "type": "u8"
          },
          {
            "name": "hlpRecoveryFundingGap",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryMatchedInput",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryBonusOutput",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryDiscountBps",
            "type": "u16"
          },
          {
            "name": "hlpRecoveryCritical",
            "type": "bool"
          },
          {
            "name": "baseLiveReserve",
            "docs": [
              "Final executable reserves after retention and inline hLP correction."
            ],
            "type": "u128"
          },
          {
            "name": "quoteLiveReserve",
            "type": "u128"
          },
          {
            "name": "srlpSupply",
            "docs": [
              "Internal srLP share supply after the swap."
            ],
            "type": "u64"
          },
          {
            "name": "startPriceNad",
            "docs": [
              "Base price used to quote this execution, after any deferred controller step."
            ],
            "type": "u64"
          },
          {
            "name": "base",
            "docs": [
              "Each side's price, price EMA, and srLP growth indexes after the swap."
            ],
            "type": {
              "defined": {
                "name": "marketSideSnapshot"
              }
            }
          },
          {
            "name": "quote",
            "type": {
              "defined": {
                "name": "marketSideSnapshot"
              }
            }
          }
        ]
      }
    },
    {
      "name": "swapOrigin",
      "docs": [
        "Instruction that caused an actual AMM execution. Fee attribution follows",
        "this origin; borrowing interest is reported separately by debt source."
      ],
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "spot"
          },
          {
            "name": "leverageOpen"
          },
          {
            "name": "leverageIncrease"
          },
          {
            "name": "leverageDecrease"
          },
          {
            "name": "leverageClose"
          },
          {
            "name": "leverageLiquidation"
          },
          {
            "name": "creditLiquidation"
          }
        ]
      }
    },
    {
      "name": "swapPreview",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "assetIn",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "assetOut",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "exactAssetIn",
            "type": "u64"
          },
          {
            "name": "transferFee",
            "type": "u64"
          },
          {
            "name": "reserveCredit",
            "docs": [
              "Actual credit received by the reserve vault from the user transfer."
            ],
            "type": "u64"
          },
          {
            "name": "feeAsset",
            "type": {
              "defined": {
                "name": "marketAsset"
              }
            }
          },
          {
            "name": "amountOut",
            "docs": [
              "Output reserve vault debit after Dusk trading fees, before the output mint transfer fee."
            ],
            "type": "u64"
          },
          {
            "name": "grossAmountOut",
            "docs": [
              "Curve output before Dusk trading fees."
            ],
            "type": "u64"
          },
          {
            "name": "reserveInLiveReserve",
            "type": "u128"
          },
          {
            "name": "reserveOutLiveReserve",
            "type": "u128"
          },
          {
            "name": "baseFeeDebit",
            "type": "u64"
          },
          {
            "name": "divergenceSurchargeDebit",
            "type": "u64"
          },
          {
            "name": "volatilitySurchargeDebit",
            "type": "u64"
          },
          {
            "name": "dynamicSurchargeDebit",
            "type": "u64"
          },
          {
            "name": "totalFeeDebit",
            "type": "u64"
          },
          {
            "name": "retainedSurcharge",
            "type": "u64"
          },
          {
            "name": "distributedSurchargeDebit",
            "type": "u64"
          },
          {
            "name": "claimableFeeDebit",
            "type": "u64"
          },
          {
            "name": "compoundedFeeDebit",
            "docs": [
              "LP-owned fee converted into reserve principal at the configured rate."
            ],
            "type": "u64"
          },
          {
            "name": "compoundingFeeBps",
            "type": "u16"
          },
          {
            "name": "amountInForQuote",
            "type": "u64"
          },
          {
            "name": "reserveInputCredit",
            "type": "u64"
          },
          {
            "name": "baseFeeCredit",
            "type": "u64"
          },
          {
            "name": "distributedSurchargeCredit",
            "type": "u64"
          },
          {
            "name": "claimableFeeCredit",
            "type": "u64"
          },
          {
            "name": "baseFeeRateNad",
            "type": "u64"
          },
          {
            "name": "divergenceFeeRateNad",
            "type": "u64"
          },
          {
            "name": "volatilityFeeRateNad",
            "type": "u64"
          },
          {
            "name": "totalFeeRateNad",
            "type": "u64"
          },
          {
            "name": "startPriceNad",
            "type": "u64"
          },
          {
            "name": "tradeEndPriceNad",
            "docs": [
              "Invariant-preserving executable trade endpoint."
            ],
            "type": "u64"
          },
          {
            "name": "reserveEndPriceNad",
            "docs": [
              "Final executable marginal price. A protected retained surcharge is",
              "non-quoteable, so it does not change this value."
            ],
            "type": "u64"
          },
          {
            "name": "centerPriceNad",
            "type": "u64"
          },
          {
            "name": "priceEmaNad",
            "type": "u64"
          },
          {
            "name": "decayedVolatilityNad",
            "type": "u64"
          },
          {
            "name": "postSuccessVolatilityNad",
            "type": "u64"
          },
          {
            "name": "retentionActive",
            "type": "bool"
          },
          {
            "name": "retentionTargetSaturated",
            "type": "bool"
          },
          {
            "name": "protectedRecenterBaseReserve",
            "type": "u64"
          },
          {
            "name": "protectedRecenterQuoteReserve",
            "type": "u64"
          },
          {
            "name": "protectedProfitPerShareNad",
            "type": "u128"
          },
          {
            "name": "projectedProtectedProfitPerShareNad",
            "type": "u128"
          },
          {
            "name": "retentionRequiredNad",
            "type": "u128"
          },
          {
            "name": "retentionStopNad",
            "type": "u128"
          },
          {
            "name": "retentionHardCapNad",
            "type": "u128"
          },
          {
            "name": "lowerRangePriceNad",
            "docs": [
              "Concentrated range metadata. Zeroes mean the curve has no concentrated",
              "ranges: a CPMM curve, or an AMM that is not yet initialized."
            ],
            "type": "u64"
          },
          {
            "name": "upperRangePriceNad",
            "type": "u64"
          },
          {
            "name": "concentratedCurveBranch",
            "docs": [
              "0=lower tail, 1=lower shoulder, 2=inner band,",
              "3=upper shoulder, 4=upper tail."
            ],
            "type": "u8"
          },
          {
            "name": "ordinaryBaseReserveNad",
            "type": "u128"
          },
          {
            "name": "ordinaryQuoteReserveNad",
            "type": "u128"
          },
          {
            "name": "finalSpotPriceNad",
            "type": "u64"
          },
          {
            "name": "baseHlpQuoteDebtDelta",
            "type": "i128"
          },
          {
            "name": "quoteHlpBaseDebtDelta",
            "type": "i128"
          },
          {
            "name": "hlpRecoveryTargetAsset",
            "docs": [
              "Funding recovery funded exclusively by the stressed hLP."
            ],
            "type": "u8"
          },
          {
            "name": "hlpRecoveryFundingGap",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryMatchedInput",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryBonusOutput",
            "type": "u64"
          },
          {
            "name": "hlpRecoveryDiscountBps",
            "type": "u16"
          },
          {
            "name": "hlpRecoveryCritical",
            "type": "bool"
          },
          {
            "name": "outputTransferFee",
            "docs": [
              "Token-2022 fee withheld when the output vault transfers `amount_out`."
            ],
            "type": "u64"
          },
          {
            "name": "netAmountOut",
            "docs": [
              "Spendable output credited to the recipient; the value checked by `min_asset_out`."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "trancheAction",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "enter",
            "fields": [
              {
                "name": "seniorAmount",
                "type": "u64"
              },
              {
                "name": "minimumJunior",
                "type": "u64"
              }
            ]
          },
          {
            "name": "requestExit",
            "fields": [
              {
                "name": "juniorAmount",
                "type": "u64"
              }
            ]
          },
          {
            "name": "convertExit",
            "fields": [
              {
                "name": "minimumSenior",
                "type": "u64"
              }
            ]
          },
          {
            "name": "cancelExit"
          }
        ]
      }
    },
    {
      "name": "trancheCapital",
      "docs": [
        "Junior's portion of the AMM's existing reserve shares. Senior receipts stay",
        "one-for-one with the remaining reserve shares, including hLP-held receipts.",
        "Junior receipts have their own exchange rate after income, losses and fees."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "juniorReserveShares",
            "type": "u64"
          },
          {
            "name": "juniorReceiptSupply",
            "type": "u64"
          },
          {
            "name": "permanentReceipts",
            "docs": [
              "Funded, nonredeemable protocol receipts; included in junior supply."
            ],
            "type": "u64"
          },
          {
            "name": "queuedReceipts",
            "docs": [
              "Escrow remains junior until a successful conversion or cancellation."
            ],
            "type": "u64"
          },
          {
            "name": "generation",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "trancheConverted",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "action",
            "type": "u8"
          },
          {
            "name": "seniorAmount",
            "type": "u64"
          },
          {
            "name": "juniorAmount",
            "type": "u64"
          },
          {
            "name": "juniorFee",
            "type": "u64"
          },
          {
            "name": "readyAt",
            "type": "u64"
          },
          {
            "name": "expiresAt",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "trancheIncome",
      "docs": [
        "Custody-backed junior income. Cached ownership is synchronized by every",
        "capital transition; the market invariant checks it against the shared book."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "initialized",
            "type": "bool"
          },
          {
            "name": "incomeShareBps",
            "type": "u16"
          },
          {
            "name": "reserveShares",
            "type": "u64"
          },
          {
            "name": "receiptSupply",
            "type": "u64"
          },
          {
            "name": "swapGrowthQ64",
            "type": "u128"
          },
          {
            "name": "interestGrowthQ64",
            "type": "u128"
          },
          {
            "name": "swapRemainder",
            "type": "u64"
          },
          {
            "name": "interestRemainder",
            "type": "u64"
          },
          {
            "name": "seedSwapAmount",
            "type": "u64"
          },
          {
            "name": "seedInterestAmount",
            "type": "u64"
          },
          {
            "name": "seedSwapCheckpoint",
            "type": "u128"
          },
          {
            "name": "seedInterestCheckpoint",
            "type": "u128"
          },
          {
            "name": "seedSwapRemainder",
            "type": "u64"
          },
          {
            "name": "seedInterestRemainder",
            "type": "u64"
          },
          {
            "name": "carry",
            "type": {
              "defined": {
                "name": "trancheRevenueCarry"
              }
            }
          }
        ]
      }
    },
    {
      "name": "tranchePolicy",
      "docs": [
        "Operator-configured junior income allocation. Exit timing and the request and",
        "liquidation fees remain fixed by the protocol."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "juniorIncomeShareBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "trancheRevenueCarry",
      "docs": [
        "Carry sub-basis-point atoms across credits so splitting a payment into many",
        "small transfers cannot change either tranche's governed allocation."
      ],
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "interestRemainderBps",
            "type": "u16"
          },
          {
            "name": "swapRemainderBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "updateFutarchyAuthorityArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "newAuthority",
            "type": "pubkey"
          }
        ]
      }
    },
    {
      "name": "updateLeverageDelegationArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "debtAsset",
            "type": "u8"
          },
          {
            "name": "delegatedProgram",
            "type": "pubkey"
          },
          {
            "name": "approvedActions",
            "type": "u32"
          }
        ]
      }
    },
    {
      "name": "updateProtocolAuctionConfigArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "lane",
            "type": {
              "defined": {
                "name": "protocolAuctionLane"
              }
            }
          },
          {
            "name": "acceptedMint",
            "docs": [
              "Default for newly configured auctions; existing curves retain their mint."
            ],
            "type": {
              "option": "pubkey"
            }
          }
        ]
      }
    },
    {
      "name": "updateProtocolAuctionRecipientsArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "lane",
            "type": {
              "defined": {
                "name": "protocolAuctionLane"
              }
            }
          },
          {
            "name": "treasury",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "stakingVault",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "treasuryBps",
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "stakingVaultBps",
            "type": {
              "option": "u16"
            }
          }
        ]
      }
    },
    {
      "name": "updateProtocolRevenueArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "swapBps",
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "interestBps",
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "maxReferralInterestShareBps",
            "type": {
              "option": "u16"
            }
          },
          {
            "name": "revenueDistribution",
            "type": {
              "option": {
                "defined": {
                  "name": "revenueDistribution"
                }
              }
            }
          },
          {
            "name": "protocolAuctionSplit",
            "type": {
              "option": {
                "defined": {
                  "name": "protocolAuctionSplit"
                }
              }
            }
          }
        ]
      }
    },
    {
      "name": "updateRevenueRecipientsArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "futarchyTreasury",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "buybacksVault",
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "teamTreasury",
            "type": {
              "option": "pubkey"
            }
          }
        ]
      }
    },
    {
      "name": "withdrawAllCollateralArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "minBaseOut",
            "type": "u64"
          },
          {
            "name": "minQuoteOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "withdrawCollateralArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "withdrawAmount",
            "type": "u64"
          },
          {
            "name": "minAssetAmountOut",
            "type": "u64"
          },
          {
            "name": "minLiquidationCfBps",
            "type": "u16"
          }
        ]
      }
    },
    {
      "name": "withdrawRepaidLeverageArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "minCollateralOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "withdrawSingleSidedArgs",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "hlpAmount",
            "type": "u64"
          },
          {
            "name": "minTargetAmountOut",
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "yieldAccount",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "lpMint",
            "docs": [
              "LP mint whose balance earns this account's revenue stream. This keeps",
              "base-hLP, quote-hLP, and srLP entitlements in disjoint PDA namespaces."
            ],
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "type": "u8"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "swapFeeCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "interestCheckpointQ64",
            "type": "u128"
          },
          {
            "name": "accruedSwapFeeAmount",
            "type": "u64"
          },
          {
            "name": "accruedInterestAmount",
            "type": "u64"
          },
          {
            "name": "swapFeeRemainderQ64",
            "docs": [
              "Sub-token fixed-point entitlement carried across checkpoints. Keeping",
              "this remainder prevents transfer/checkpoint frequency from destroying",
              "holder yield through repeated flooring."
            ],
            "type": "u64"
          },
          {
            "name": "interestRemainderQ64",
            "type": "u64"
          },
          {
            "name": "bump",
            "type": "u8"
          },
          {
            "name": "harvestAuthority",
            "docs": [
              "Optional caller allowed to harvest to the recipient without controlling",
              "the LP or changing either yield permission. Only the owner may set it."
            ],
            "type": {
              "option": "pubkey"
            }
          },
          {
            "name": "escrowBalance",
            "docs": [
              "Owner's junior exit escrow receipts. They keep earning junior interest",
              "and are checkpointed alongside the liquid balance."
            ],
            "type": "u64"
          }
        ]
      }
    },
    {
      "name": "yieldClaimed",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "lpMint",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "type": "u8"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "swapFeeAmount",
            "type": "u64"
          },
          {
            "name": "interestAmount",
            "docs": [
              "Interest paid now, limited by reserve cash."
            ],
            "type": "u64"
          },
          {
            "name": "interestRemaining",
            "docs": [
              "Credited interest still claimable by the holder after this claim."
            ],
            "type": "u64"
          },
          {
            "name": "recipientCredit",
            "docs": [
              "Total amount credited to the recipient after transfer fees."
            ],
            "type": "u64"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "yieldRecipientUpdated",
      "type": {
        "kind": "struct",
        "fields": [
          {
            "name": "market",
            "type": "pubkey"
          },
          {
            "name": "owner",
            "type": "pubkey"
          },
          {
            "name": "lpMint",
            "type": "pubkey"
          },
          {
            "name": "assetMint",
            "type": "pubkey"
          },
          {
            "name": "tokenKind",
            "type": "u8"
          },
          {
            "name": "recipient",
            "type": "pubkey"
          },
          {
            "name": "metadata",
            "type": {
              "defined": {
                "name": "marketEventMetadata"
              }
            }
          }
        ]
      }
    },
    {
      "name": "yieldTokenKind",
      "type": {
        "kind": "enum",
        "variants": [
          {
            "name": "srlp"
          },
          {
            "name": "hlp"
          },
          {
            "name": "junior"
          }
        ]
      }
    }
  ],
  "constants": [
    {
      "name": "borrowPositionSeedPrefix",
      "type": "bytes",
      "value": "[98, 111, 114, 114, 111, 119, 95, 112, 111, 115, 105, 116, 105, 111, 110, 95, 118, 50]"
    },
    {
      "name": "bpsDenominator",
      "type": "u16",
      "value": "10000"
    },
    {
      "name": "defaultJuniorIncomeShareBps",
      "type": "u16",
      "value": "5000"
    },
    {
      "name": "defaultProtocolRevenueShareBps",
      "docs": [
        "Initial DAO share of base swap fees and paid interest, and the protocol",
        "share of liquidation fees. Governance can override swap and interest shares."
      ],
      "type": "u16",
      "value": "2000"
    },
    {
      "name": "futarchyAuthoritySeedPrefix",
      "type": "bytes",
      "value": "[102, 117, 116, 97, 114, 99, 104, 121, 95, 97, 117, 116, 104, 111, 114, 105, 116, 121]"
    },
    {
      "name": "hlpSrlpVaultSeedPrefix",
      "type": "bytes",
      "value": "[104, 108, 112, 95, 121, 108, 112, 95, 118, 97, 117, 108, 116]"
    },
    {
      "name": "hlpTerminalCallerBps",
      "docs": [
        "Caller reward for closing a terminal hLP vault, paid from recovered funding",
        "interest so it cannot increase the bad-debt waterfall."
      ],
      "type": "u16",
      "value": "50"
    },
    {
      "name": "juniorExitFeeBps",
      "type": "u16",
      "value": "50"
    },
    {
      "name": "juniorMaxNoticeSlots",
      "docs": [
        "Maximum junior notice; operator changes wait this plus one protocol day."
      ],
      "type": "u64",
      "value": "4320000"
    },
    {
      "name": "leverageCollateralVaultSeedPrefix",
      "type": "bytes",
      "value": "[108, 101, 118, 101, 114, 97, 103, 101, 95, 99, 111, 108, 108, 97, 116, 101, 114, 97, 108]"
    },
    {
      "name": "leverageDelegationSeedPrefix",
      "type": "bytes",
      "value": "[108, 101, 118, 101, 114, 97, 103, 101, 95, 100, 101, 108, 101, 103, 97, 116, 105, 111, 110, 95, 118, 50]"
    },
    {
      "name": "leverageMaxMultiplierBps",
      "type": "u64",
      "value": "200000"
    },
    {
      "name": "leveragePositionSeedPrefix",
      "type": "bytes",
      "value": "[108, 101, 118, 101, 114, 97, 103, 101, 95, 112, 111, 115, 105, 116, 105, 111, 110, 95, 118, 50]"
    },
    {
      "name": "liquidationAuctionDurationSeconds",
      "docs": [
        "External bids have this fixed window before the permissionless internal",
        "unwind becomes executable."
      ],
      "type": "i64",
      "value": "300"
    },
    {
      "name": "liquidationBackstopCallerBps",
      "docs": [
        "V1-style keeper reward paid from collateral consumed by the permissionless",
        "lending-auction floor. This is deliberately independent from the dynamic",
        "incentive used by externally funded auction bids."
      ],
      "type": "u16",
      "value": "50"
    },
    {
      "name": "liquidationCloseFactorBps",
      "type": "u16",
      "value": "5000"
    },
    {
      "name": "liquidationFeeBps",
      "type": "u16",
      "value": "300"
    },
    {
      "name": "liquidationIncentiveBps",
      "type": "u16",
      "value": "100"
    },
    {
      "name": "liquidationMaxIncentiveBps",
      "type": "u16",
      "value": "500"
    },
    {
      "name": "ltvBufferBps",
      "type": "u16",
      "value": "500"
    },
    {
      "name": "marketCollateralVaultSeedPrefix",
      "type": "bytes",
      "value": "[109, 97, 114, 107, 101, 116, 95, 99, 111, 108, 108, 97, 116, 101, 114, 97, 108]"
    },
    {
      "name": "marketCreationFeeLamports",
      "type": "u64",
      "value": "200000000"
    },
    {
      "name": "marketLayoutVersion",
      "docs": [
        "Serialized `Market` account layout discriminator, and the only layout the",
        "program reads. An account at any other layout is rejected before any of",
        "its quantities are read, never reinterpreted.",
        "",
        "This layout counts token amounts in at least `MIN_AMOUNT_DECIMALS`",
        "decimals and sets independent lower/upper utilization rate targets.",
        "Aggregate virtual reserves use u128; physical token amounts remain u64.",
        "Separate hLP funding offsets preserve pricing principal through payment.",
        "Interest is credited at accrual through a per-asset interest ledger and",
        "per-lane growth indexes."
      ],
      "type": "u8",
      "value": "19"
    },
    {
      "name": "marketParamsHashDomain",
      "docs": [
        "Domain tag of the market parameters hash, the third market-address seed."
      ],
      "type": "bytes",
      "value": "[100, 117, 115, 107, 58, 109, 97, 114, 107, 101, 116, 45, 112, 97, 114, 97, 109, 115, 58, 118, 49]"
    },
    {
      "name": "marketReserveVaultSeedPrefix",
      "type": "bytes",
      "value": "[109, 97, 114, 107, 101, 116, 95, 114, 101, 115, 101, 114, 118, 101]"
    },
    {
      "name": "marketV2SeedPrefix",
      "type": "bytes",
      "value": "[109, 97, 114, 107, 101, 116, 95, 118, 50]"
    },
    {
      "name": "maxBorrowHalfLifeMs",
      "type": "u64",
      "value": "2592000000"
    },
    {
      "name": "maxCollateralFactorBps",
      "type": "u16",
      "value": "8500"
    },
    {
      "name": "maxJuniorIncomeShareBps",
      "type": "u16",
      "value": "9000"
    },
    {
      "name": "maxOperatorInterestShareBps",
      "docs": [
        "The operator may retain up to all interest left after the protocol markup;",
        "LPs keep swap fees. An increase waits the full operator notice."
      ],
      "type": "u16",
      "value": "10000"
    },
    {
      "name": "maxParameterFeeBps",
      "docs": [
        "Absolute cap shared by the three configurable swap-fee components.",
        "Their configured component caps must also sum to no more than this value."
      ],
      "type": "u16",
      "value": "5000"
    },
    {
      "name": "maxReferralInterestShareBps",
      "type": "u16",
      "value": "10000"
    },
    {
      "name": "metadataSeedPrefix",
      "type": "bytes",
      "value": "[109, 101, 116, 97, 100, 97, 116, 97]"
    },
    {
      "name": "minimumBorrowAprNad",
      "docs": [
        "Minimum economic borrowing APR for every Dusk market. There is no",
        "configurable economic ceiling; checked arithmetic bounds representation."
      ],
      "type": "u64",
      "value": "10000000"
    },
    {
      "name": "minAmountDecimals",
      "docs": [
        "Fewest decimals a market counts token amounts in. A market's amount scale",
        "is the largest of this, its base decimals and its quote decimals. Three",
        "decimals beyond NAD give each atom of a nine-decimal token 1,000 internal",
        "units, so payouts, which floor to whole atoms, absorb the few units of",
        "rounding that rebuilding a concentrated curve from reserves can leave.",
        "Prices, rates and ratios remain NAD."
      ],
      "type": "u8",
      "value": "12"
    },
    {
      "name": "minBorrowHalfLifeMs",
      "type": "u64",
      "value": "43200000"
    },
    {
      "name": "minConcentratedSwapFeeBps",
      "docs": [
        "Minimum base swap fee of a concentrated curve. It exceeds the round-trip",
        "excess that curve reconstruction can leave at the minimum tail share."
      ],
      "type": "u16",
      "value": "1"
    },
    {
      "name": "minConcentrationRampSlots",
      "type": "u64",
      "value": "432000"
    },
    {
      "name": "minJuniorIncomeShareBps",
      "type": "u16",
      "value": "1000"
    },
    {
      "name": "nad",
      "docs": [
        "NAD: Nine-decimal fixed point unit (1e9 scaling), similar to WAD (1e18) by Maker."
      ],
      "type": "u64",
      "value": "1000000000"
    },
    {
      "name": "nadDecimals",
      "type": "u8",
      "value": "9"
    },
    {
      "name": "operatorExecutionWindowSlots",
      "type": "u64",
      "value": "3024000"
    },
    {
      "name": "operatorNoticeSlots",
      "type": "u64",
      "value": "4752000"
    },
    {
      "name": "operatorPolicyVersion",
      "type": "u64",
      "value": "2"
    },
    {
      "name": "parameterExecutionMaxUtilizationBps",
      "type": "u64",
      "value": "8000"
    },
    {
      "name": "referralAccrualSeedPrefix",
      "type": "bytes",
      "value": "[114, 101, 102, 101, 114, 114, 97, 108, 95, 97, 99, 99, 114, 117, 97, 108]"
    },
    {
      "name": "referralPartnerSeedPrefix",
      "type": "bytes",
      "value": "[114, 101, 102, 101, 114, 114, 97, 108, 95, 112, 97, 114, 116, 110, 101, 114]"
    },
    {
      "name": "targetMsPerSlot",
      "docs": [
        "Economic timers use a deterministic nominal slot cadence instead of the",
        "leader-influenced `Clock.unix_timestamp`. Solana's 200 ms slot rollout is",
        "separate from Alpenglow's finality change. Revisit this protocol constant",
        "if the cluster's scheduled slot duration changes again."
      ],
      "type": "u64",
      "value": "200"
    },
    {
      "name": "yieldAccountSeedPrefix",
      "type": "bytes",
      "value": "[121, 105, 101, 108, 100]"
    }
  ]
};
