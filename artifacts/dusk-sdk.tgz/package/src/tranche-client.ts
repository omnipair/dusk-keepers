import type { Program } from "@coral-xyz/anchor";
import { PublicKey, SystemProgram, Transaction, SYSVAR_INSTRUCTIONS_PUBKEY, type AccountMeta } from "@solana/web3.js";
import { createAssociatedTokenAccountIdempotentInstruction, getAssociatedTokenAddressSync, TOKEN_2022_PROGRAM_ID, TOKEN_PROGRAM_ID } from "@solana/spl-token";
import { address, type AddressLike } from "./address.js";
import { deriveJuniorMintAddress, deriveJuniorCohortAddress, deriveJuniorExitAddress, deriveYieldAccountAddress, deriveTokenMetadataAddress, TOKEN_METADATA_PROGRAM_ID } from "./constants.js";
import { integerBN, type IntegerLike } from "./parameters.js";
import { assertLpTokenMetadata, type LpTokenMetadataInput } from "./lp-naming.js";
import { oracleComputeBudgetInstructions, oracleReadAccounts } from "./oracle.js";
import { DuskWrite } from "./write.js";
import { assertCurrentMarketLayout } from "./market-layout.js";
import type { Dusk as DuskIdl } from "./types_v2.js";

export type TrancheAction =
  | { kind: "enter"; seniorAmount: IntegerLike; minimumJunior: IntegerLike }
  | { kind: "requestExit"; juniorAmount: IntegerLike }
  | { kind: "convertExit"; minimumSenior: IntegerLike }
  | { kind: "cancelExit" };

/** srLP/jrLP builders. Conversion changes ownership of existing pool capital;
 * redeeming cash is a separate ordinary-LP withdrawal. Builders never submit. */
export class DuskTranches {
  readonly write: DuskWrite;
  constructor(readonly program: Program<DuskIdl>) { this.write = new DuskWrite(program); }

  // Throws DuskUnsupportedMarketLayoutError for a market at any other layout.
  private async marketState(market: PublicKey) {
    return assertCurrentMarketLayout(await this.program.account.market.fetch(market));
  }

  /** A retired receipt has zero principal but can still own earned income. */
  async burnRetired(params: { market: AddressLike; owner: AddressLike; retiredMint: AddressLike; amount: IntegerLike }) {
    const market = address(params.market), owner = address(params.owner), retiredMint = address(params.retiredMint);
    const state = await this.marketState(market);
    if (retiredMint.equals(state.juniorMint)) throw new Error("Cannot burn an active generation through the retired-receipt path");
    const exitAddress = deriveJuniorExitAddress(market, owner, retiredMint, this.program.programId)[0];
    const exitState = await this.program.account.juniorExitAccount.fetchNullable(exitAddress);
    const instruction = await this.write.instruction("burnRetiredJunior", { amount: integerBN(params.amount, "amount") }, { accounts: {
      market, owner, retiredMint, cohort: deriveJuniorCohortAddress(market, retiredMint, this.program.programId)[0],
      ownerJunior: getAssociatedTokenAddressSync(retiredMint, owner, true, TOKEN_2022_PROGRAM_ID),
      baseYield: deriveYieldAccountAddress(market, owner, retiredMint, state.baseSide.assetMint, "junior", this.program.programId)[0],
      quoteYield: deriveYieldAccountAddress(market, owner, retiredMint, state.quoteSide.assetMint, "junior", this.program.programId)[0],
      exit: exitState ? exitAddress : null, token2022Program: TOKEN_2022_PROGRAM_ID,
    } });
    return { instruction, transaction: new Transaction().add(instruction) };
  }

  async fundSeed(params: { market: AddressLike; asset: "base" | "quote"; remainingAccounts?: AccountMeta[] }) {
    const market = address(params.market);
    const state = await this.marketState(market);
    const side = params.asset === "base" ? state.baseSide : state.quoteSide;
    const instruction = await this.write.instruction("fundJuniorSeed", undefined, { accounts: {
      market, assetMint: side.assetMint, reserveVault: side.reserveVault,
      tokenProgram: TOKEN_PROGRAM_ID, token2022Program: TOKEN_2022_PROGRAM_ID,
    }, remainingAccounts: params.remainingAccounts });
    return { instruction, transaction: new Transaction().add(instruction) };
  }

  async compoundSeed(params: { market: AddressLike }) {
    const market = address(params.market);
    const state = await this.marketState(market);
    const policy = state.oracle.policy;
    const instruction = await this.write.instruction("compoundJuniorSeed", undefined, {
      accounts: { market, juniorMint: state.juniorMint },
      remainingAccounts: oracleReadAccounts(policy),
    });
    return {
      instruction,
      transaction: new Transaction().add(...oracleComputeBudgetInstructions(policy), instruction),
    };
  }

  async initialize(params: { market: AddressLike; payer: AddressLike; metadata: LpTokenMetadataInput }) {
    const market = address(params.market), payer = address(params.payer);
    assertLpTokenMetadata(params.metadata);
    const state = await this.marketState(market);
    const first = state.juniorMint.equals(PublicKey.default);
    if (!first && !state.tranches.juniorReserveShares.isZero()) throw new Error("Current junior capital is not wiped out");
    const generation = BigInt(state.tranches.generation.toString()) + (first ? 0n : 1n);
    const juniorMint = deriveJuniorMintAddress(market, generation, this.program.programId)[0];
    const cohort = deriveJuniorCohortAddress(market, juniorMint, this.program.programId)[0];
    const initialize = await this.write.instruction("initializeJunior", {
      generation: integerBN(generation, "generation"),
      metadata: params.metadata,
    }, { accounts: {
      payer, market, juniorMint, cohort,
      tokenMetadata: deriveTokenMetadataAddress(juniorMint)[0], sysvarInstructions: SYSVAR_INSTRUCTIONS_PUBKEY, tokenMetadataProgram: TOKEN_METADATA_PROGRAM_ID,
      previousCohort: first ? null : deriveJuniorCohortAddress(market, state.juniorMint, this.program.programId)[0],
      token2022Program: TOKEN_2022_PROGRAM_ID, systemProgram: SystemProgram.programId,
    } });
    const hook = await this.write.initializeLpTransferHookInstruction({ payer, market, lpMint: juniorMint, tokenKind: "junior" });
    return { juniorMint, cohort, generation, instructions: [initialize, hook], transaction: new Transaction().add(initialize, hook) };
  }

  async convert(params: { market: AddressLike; owner: AddressLike; action: TrancheAction }) {
    const market = address(params.market), owner = address(params.owner);
    const state = await this.marketState(market);
    if (state.juniorMint.equals(PublicKey.default)) throw new Error("Initialize the junior mint first");
    const seniorMint = state.srlpMint, juniorMint = state.juniorMint;
    const ownerSenior = getAssociatedTokenAddressSync(seniorMint, owner, true, TOKEN_2022_PROGRAM_ID);
    const ownerJunior = getAssociatedTokenAddressSync(juniorMint, owner, true, TOKEN_2022_PROGRAM_ID);
    const exit = deriveJuniorExitAddress(market, owner, juniorMint, this.program.programId)[0];
    const action = params.action.kind === "enter"
      ? { enter: { seniorAmount: integerBN(params.action.seniorAmount, "seniorAmount"), minimumJunior: integerBN(params.action.minimumJunior, "minimumJunior") } }
      : params.action.kind === "requestExit"
        ? { requestExit: { juniorAmount: integerBN(params.action.juniorAmount, "juniorAmount") } }
        : params.action.kind === "convertExit"
          ? { convertExit: { minimumSenior: integerBN(params.action.minimumSenior, "minimumSenior") } }
          : { cancelExit: {} };
    const ix = await this.write.instruction("convertTranche", action, { accounts: {
      owner, market, seniorMint, juniorMint, ownerSenior, ownerJunior, exit,
      seniorBaseYield: deriveYieldAccountAddress(market, owner, seniorMint, state.baseSide.assetMint, "srlp", this.program.programId)[0],
      seniorQuoteYield: deriveYieldAccountAddress(market, owner, seniorMint, state.quoteSide.assetMint, "srlp", this.program.programId)[0],
      juniorBaseYield: deriveYieldAccountAddress(market, owner, juniorMint, state.baseSide.assetMint, "junior", this.program.programId)[0],
      juniorQuoteYield: deriveYieldAccountAddress(market, owner, juniorMint, state.quoteSide.assetMint, "junior", this.program.programId)[0],
      token2022Program: TOKEN_2022_PROGRAM_ID, systemProgram: SystemProgram.programId,
    } });
    const instructions = [
      createAssociatedTokenAccountIdempotentInstruction(owner, ownerSenior, owner, seniorMint, TOKEN_2022_PROGRAM_ID),
      createAssociatedTokenAccountIdempotentInstruction(owner, ownerJunior, owner, juniorMint, TOKEN_2022_PROGRAM_ID), ix,
    ];
    return { instructions, transaction: new Transaction().add(...instructions), exit, seniorMint, juniorMint };
  }
}
