import type { IdlTypes } from "@coral-xyz/anchor";
import { PublicKey, type AccountMeta } from "@solana/web3.js";
import { TOKEN_PROGRAM_ID, TOKEN_2022_PROGRAM_ID } from "@solana/spl-token";
import { SystemProgram } from "@solana/web3.js";
import type { LeverageDelegate } from "./types_delegate.js";
import { type LeverageDelegateProgram, LEVERAGE_DELEGATE_PROGRAM_ID } from "./delegate.js";
import { DUSK_PROGRAM_ID, deriveEventAuthorityAddress } from "./constants.js";
import { integerBN } from "./parameters.js";
import { DuskWrite, type RawAmount } from "./write.js";
import { createDuskProgram } from "./program.js";
import { oracleReadAccounts } from "./oracle.js";

export const PROTECTION_ACTION = { borrowRepay: 0, borrowCollateral: 1, leverageRepay: 2 } as const;

export function deriveProtectionOrderAddress(owner: PublicKey, orderId: RawAmount,
  programId = LEVERAGE_DELEGATE_PROGRAM_ID): [PublicKey, number] {
  return PublicKey.findProgramAddressSync([Buffer.from("protection_order"), owner.toBuffer(),
    integerBN(orderId, "orderId").toArrayLike(Buffer, "le", 8)], programId);
}

type MethodAccounts<T extends keyof LeverageDelegateProgram["methods"]> =
  Parameters<ReturnType<LeverageDelegateProgram["methods"][T]>["accountsStrict"]>[0];
type CreateAccounts = Omit<MethodAccounts<"createProtectionOrder">,
  "order" | "duskEventAuthority" | "duskProgram" | "token2022Program" | "systemProgram"> & { owner: PublicKey };
type ManageAccounts = Omit<MethodAccounts<"fundProtectionOrder">, "token2022Program">;
type ExecuteAccounts = Omit<MethodAccounts<"executeProtectionOrder">,
  "duskEventAuthority" | "duskProgram" | "tokenProgram" | "token2022Program">;
type CreateArgs = IdlTypes<LeverageDelegate>["createProtectionOrderArgs"];

/** All amounts use raw token units. Health 10000 is the liquidation boundary. */
export type CreateProtectionOrderParams = {
  [K in keyof CreateArgs]: CreateArgs[K] extends number ? number : RawAmount;
};

/** Fund recurring protection for an existing borrowing or leverage position.
 * Setup the order's LP ATA, asset ATAs and both yield accounts first. LP transfers
 * require buildLpTransferHookAccountMetas. The sponsor remains yield recipient.
 * Execution needs a keeper token balance to advance repayment; LP redemption
 * reimburses that balance atomically. Insufficient redemption liquidity reverts.
 */
export class DuskProtectionOrders {
  constructor(readonly program: LeverageDelegateProgram) {}

  private async oracleAccounts(market: PublicKey, remaining: AccountMeta[]) {
    const dusk = createDuskProgram({ connection: this.program.provider.connection });
    const state = await dusk.account.market.fetch(market);
    const accounts = [...remaining];
    for (const meta of oracleReadAccounts(state.oracle.policy)) {
      if (!accounts.some(account => account.pubkey.equals(meta.pubkey))) accounts.push(meta);
    }
    return accounts;
  }

  async createInstruction(params: CreateProtectionOrderParams, accounts: CreateAccounts,
    remainingAccounts: AccountMeta[] = []) {
    const order = deriveProtectionOrderAddress(new PublicKey(accounts.owner), params.orderId, this.program.programId)[0];
    const args: CreateArgs = {
      ...params,
      orderId: integerBN(params.orderId, "orderId"),
      lpAmount: integerBN(params.lpAmount, "lpAmount"),
      maxLpPerExecution: integerBN(params.maxLpPerExecution, "maxLpPerExecution"),
      maxPaymentPerExecution: integerBN(params.maxPaymentPerExecution, "maxPaymentPerExecution"),
      minPaymentPerLpNad: integerBN(params.minPaymentPerLpNad, "minPaymentPerLpNad"),
      triggerHealthBps: integerBN(params.triggerHealthBps, "triggerHealthBps"),
      targetHealthBps: integerBN(params.targetHealthBps, "targetHealthBps"),
      expiresAt: integerBN(params.expiresAt, "expiresAt"),
    };
    return this.program.methods.createProtectionOrder(args).accountsStrict({ ...accounts, order,
      duskProgram: DUSK_PROGRAM_ID, duskEventAuthority: deriveEventAuthorityAddress()[0],
      token2022Program: TOKEN_2022_PROGRAM_ID, systemProgram: SystemProgram.programId,
    }).remainingAccounts(remainingAccounts).instruction();
  }

  async previewInstruction(accounts: MethodAccounts<"previewProtectionOrder">, remainingAccounts: AccountMeta[] = []) {
    return this.program.methods.previewProtectionOrder().accountsStrict(accounts)
      .remainingAccounts(await this.oracleAccounts(new PublicKey(accounts.market), remainingAccounts)).instruction();
  }

  async fundInstruction(lpAmount: RawAmount, accounts: ManageAccounts, remainingAccounts: AccountMeta[] = []) {
    return this.program.methods.fundProtectionOrder({ lpAmount: integerBN(lpAmount, "lpAmount") })
      .accountsStrict({ ...accounts, token2022Program: TOKEN_2022_PROGRAM_ID }).remainingAccounts(remainingAccounts).instruction();
  }

  async cancelInstruction(accounts: ManageAccounts, remainingAccounts: AccountMeta[] = []) {
    return this.program.methods.cancelProtectionOrder().accountsStrict({ ...accounts, token2022Program: TOKEN_2022_PROGRAM_ID })
      .remainingAccounts(remainingAccounts).instruction();
  }

  /** LP redemptions may need an address lookup table and a larger heap frame.
   * Simulate the complete transaction with the current native market state.
   * LP proceeds must cover payment, the full keeper reward, and the additional
   * 10 bps protocol fee. Supply protocolFee from orderProtocolFeeAccounts.
   */
  async executeInstruction(params: { lpAmount: RawAmount; paymentAmount: RawAmount },
    accounts: ExecuteAccounts, remainingAccounts: AccountMeta[] = []) {
    const write = new DuskWrite(createDuskProgram({ connection: this.program.provider.connection }));
    const order = await this.program.account.protectionOrder.fetch(accounts.order);
    const prefix = order.action === PROTECTION_ACTION.borrowCollateral
      ? [] : await write.hlpRemainingAccounts(accounts.market);
    // Keep the canonical prefix first even when callers supply transfer-hook
    // accounts. Existing callers may already provide that same prefix.
    const hasPrefix = prefix.length > 0 && prefix.every((meta, i) =>
      remainingAccounts[i]?.pubkey.equals(meta.pubkey) && remainingAccounts[i]?.isWritable === meta.isWritable);
    const completeRemaining = hasPrefix ? remainingAccounts : [...prefix, ...remainingAccounts];
    const remaining = await this.oracleAccounts(new PublicKey(accounts.market), completeRemaining);
    return this.program.methods.executeProtectionOrder({ lpAmount: integerBN(params.lpAmount, "lpAmount"),
      paymentAmount: integerBN(params.paymentAmount, "paymentAmount") })
      .accountsStrict({ ...accounts, duskProgram: DUSK_PROGRAM_ID, duskEventAuthority: deriveEventAuthorityAddress()[0],
        tokenProgram: TOKEN_PROGRAM_ID, token2022Program: TOKEN_2022_PROGRAM_ID })
      .remainingAccounts(remaining).instruction();
  }
}
