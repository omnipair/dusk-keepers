import { deriveJuniorCohortAddress } from "./constants.js";
import { oracleComputeBudgetInstructions, oraclePolicy, oracleReadAccounts, type OraclePolicyInput } from "./oracle.js";
import type { BN, Program } from "@coral-xyz/anchor";
import {
  getAssociatedTokenAddressSync,
  getMint,
  TOKEN_2022_PROGRAM_ID,
  TOKEN_PROGRAM_ID,
} from "@solana/spl-token";
import {
  ComputeBudgetProgram,
  SystemProgram,
  SYSVAR_INSTRUCTIONS_PUBKEY,
  Transaction,
  type AccountMeta,
  type PublicKey,
  type TransactionInstruction,
} from "@solana/web3.js";

import { address, type AddressLike } from "./address.js";
import {
  normalizeInstructionAccounts,
  normalizeInstructionArgs,
  type DuskDefinedInput,
  type DuskInstructionAccounts,
  type DuskInstructionArgs,
  type DuskInstructionName,
  type ProgramBuildCall,
  type ProgramMethodCall,
} from "./instruction-args.js";
import { assertLpTokenMetadata, type LpTokenMetadataInput } from "./lp-naming.js";
import { marketParamsHash, type MarketLaunchConfig } from "./market-bootstrap.js";
import { assertCurrentMarketLayout } from "./market-layout.js";
import type { Market } from "./type-aliases.js";
import {
  deriveBorrowPositionAddress,
  deriveEventAuthorityAddress,
  deriveFutarchyAuthorityAddress,
  deriveLeverageCollateralVaultAddress,
  deriveLeverageDelegationAddress,
  deriveLeveragePositionAddress,
  deriveMarketAddress,
  deriveMarketCollateralVaultAddress,
  deriveMarketInterestVaultAddress,
  deriveMarketReserveVaultAddress,
  deriveTokenMetadataAddress,
  TOKEN_METADATA_PROGRAM_ID,
  deriveReferralAccrualAddress,
  deriveYieldAccountAddress,
  deriveYieldTransferHookValidationAddress,
  deriveHlpCohortAddress,
  deriveReferralPartnerAddress,
  MAX_OPERATOR_INTEREST_SHARE_BPS,
  yieldTokenKindArg,
  type YieldTokenKind,
} from "./constants.js";
import {
  integerBN,
  type IntegerLike,
} from "./parameters.js";
import {
  assertReferralInterestShareBps,
  referralAccrualAddresses,
  resolveTransferHookAccountMetas,
  tokenProgramForMint,
  type TransferHookTransfer,
} from "./referral.js";
import type { Dusk } from "./types_v2.js";

/**
 * An untyped account map. The write methods take
 * `DuskInstructionAccounts<Name>`, which is checked against the IDL.
 */
export type DuskAccounts = Record<string, unknown>;

interface DuskBuildOptionsBase {
  /** Explicit source policy for offline builders; async builders resolve it from the market. */
  oraclePolicy?: OraclePolicyInput;
  remainingAccounts?: AccountMeta[];
}

export interface DuskBuildOptions<out N extends DuskInstructionName = DuskInstructionName>
  extends DuskBuildOptionsBase {
  accounts?: DuskInstructionAccounts<N>;
}

type DuskBuildOptionsWithAccounts<N extends DuskInstructionName> = DuskBuildOptionsBase & {
  accounts: DuskInstructionAccounts<N>;
};

/**
 * The arguments after the instruction name in `builder`, `instruction`,
 * `transaction` and `rpc`. `args` is required unless the instruction takes
 * none; `options` and its `accounts` are required when the instruction has an
 * account Anchor cannot resolve on its own.
 */
export type DuskBuildCall<N extends DuskInstructionName> = ProgramBuildCall<
  Dusk,
  N,
  DuskBuildOptions<N>,
  DuskBuildOptionsWithAccounts<N>
>;

/** The argument after the instruction name in `method`. */
export type DuskMethodCall<N extends DuskInstructionName> = ProgramMethodCall<Dusk, N>;

/** Raw base-unit amount. Accepts bigint to keep callers off floating point. */
export type RawAmount = bigint | number | string;

// A composite builder fills these accounts itself; the caller may still name
// them, and the composite's value wins.
type WithOptionalAccounts<T, K extends PropertyKey> = T extends unknown
  ? Omit<T, K & keyof T> & Partial<Pick<T, K & keyof T>>
  : never;

/** The swap amounts `swapBuilder`, `swapInstruction`, `swapTransaction` and `swapRpc` take. */
export interface SwapAmounts {
  exactAssetIn: RawAmount;
  /** Slippage floor; the program rejects a fill below it. */
  minAssetOut: RawAmount;
}

export interface SwapBuildOptions extends DuskBuildOptionsBase {
  /** The swap's accounts. The composite fills in `market` from the option below. */
  accounts: WithOptionalAccounts<DuskInstructionAccounts<"swap">, "market">;
  market: AddressLike;
}

export type ReferredActionName = "borrow" | "openLeverage";

/** `referredBorrow` amounts. The referrer comes from the options. */
export interface ReferredBorrowParams {
  borrowAmount: RawAmount;
  /** Slippage floor on the debt actually opened. */
  minDebtAmountOut: RawAmount;
  /** Health floor in basis points; defaults to 0, no floor. */
  minLiquidationCfBps?: number;
}

/** `referredOpenLeverage` amounts. The referrer comes from the options. */
export interface ReferredOpenLeverageParams {
  positionId: AddressLike;
  /** The borrowed side: "base" or 0, "quote" or 1. */
  debtAsset: MarketAssetSide | 0 | 1;
  marginAmount: RawAmount;
  /** Leverage multiplier in basis points; 20000 is two times. */
  multiplierBps: RawAmount;
  minCollateralOut: RawAmount;
  /** Zero, the default, means no limit price. */
  limitPriceNad?: RawAmount;
  /** Open on behalf of another owner; defaults to the signing owner. */
  positionOwner?: AddressLike | null;
}

export type ReferredActionParams<N extends ReferredActionName = ReferredActionName> = N extends "borrow"
  ? ReferredBorrowParams
  : ReferredOpenLeverageParams;

/** The action's accounts, less the market and the referral accounts the composite fills in. */
export type ReferredActionAccounts<N extends ReferredActionName = ReferredActionName> = N extends ReferredActionName
  ? WithOptionalAccounts<
      DuskInstructionAccounts<N>,
      "market" | "referralPartner" | "referralAccrual" | "instructionsSysvar"
    >
  : never;

export interface ReferredActionOptions<out N extends ReferredActionName = ReferredActionName>
  extends DuskBuildOptionsBase {
  accounts: ReferredActionAccounts<N>;
  payer: AddressLike;
  referrer: AddressLike;
  market: AddressLike;
  debtMint: AddressLike;
  transferHookTransfers?: readonly TransferHookTransfer[];
}

export interface ReferredActionBuild {
  referralPartner: ReturnType<typeof deriveReferralPartnerAddress>[0];
  referralAccrual: ReturnType<typeof deriveReferralPartnerAddress>[0];
  setupInstruction: TransactionInstruction;
  actionInstruction: TransactionInstruction;
  transaction: Transaction;
}

export type HlpLiquidityName = "depositSingleSided" | "withdrawSingleSided";

/** `depositSingleSided` amounts. */
export interface DepositSingleSidedParams {
  depositAmount: RawAmount;
  /** Slippage floor on minted hLP. */
  minHlpAmount: RawAmount;
}

/** `withdrawSingleSided` amounts. */
export interface WithdrawSingleSidedParams {
  hlpAmount: RawAmount;
  /** Slippage floor on the target asset paid out. */
  minTargetAmountOut: RawAmount;
}

export type HlpLiquidityParams<N extends HlpLiquidityName = HlpLiquidityName> = N extends "depositSingleSided"
  ? DepositSingleSidedParams
  : WithdrawSingleSidedParams;

/** The action's accounts, less the market, owner, mints and yield accounts the composite fills in. */
export type HlpLiquidityAccounts<N extends HlpLiquidityName = HlpLiquidityName> = N extends HlpLiquidityName
  ? WithOptionalAccounts<
      DuskInstructionAccounts<N>,
      "market" | "owner" | "targetHlpMint" | "baseMint" | "quoteMint" | "baseYieldAccount" | "quoteYieldAccount"
    >
  : never;

export interface HlpLiquidityBuildOptions<out N extends HlpLiquidityName = HlpLiquidityName>
  extends DuskBuildOptionsBase {
  accounts: HlpLiquidityAccounts<N>;
  payer: AddressLike;
  owner: AddressLike;
  market: AddressLike;
  targetHlpMint: AddressLike;
  baseMint: AddressLike;
  quoteMint: AddressLike;
  marketSnapshot?: Market;
}

export interface HlpLiquidityBuild {
  baseYieldAccount: AccountMeta["pubkey"];
  quoteYieldAccount: AccountMeta["pubkey"];
  setupInstructions: TransactionInstruction[];
  actionInstruction: TransactionInstruction;
  transaction: Transaction;
}

type AnchorMethodBuilder = {
  accounts(accounts: DuskAccounts): AnchorMethodBuilder;
  remainingAccounts(accounts: AccountMeta[]): AnchorMethodBuilder;
  preInstructions(instructions: TransactionInstruction[]): AnchorMethodBuilder;
  instruction(): Promise<TransactionInstruction>;
  transaction(): Promise<Transaction>;
  rpc(): Promise<string>;
};

type AnchorMethods = Record<string, (...args: unknown[]) => AnchorMethodBuilder>;

// What the public signatures narrow down to once the name is known.
interface UncheckedBuildOptions extends DuskBuildOptionsBase {
  accounts?: DuskAccounts;
}

export class DuskWrite {
  constructor(readonly program: Program<Dusk>) {}

  // Every Market this builder reads must be at the current layout.
  private async fetchMarketAccount(market: PublicKey): Promise<unknown> {
    return assertCurrentMarketLayout(await (this.program as unknown as {
      account: { market: { fetch(address: PublicKey): Promise<Pick<Market, "version">> } };
    }).account.market.fetch(market));
  }

  /**
   * Anchor's method builder for one instruction. `args` is checked against
   * the IDL and converted for Anchor before anything is encoded; a missing,
   * misspelled or wrongly typed field throws `DuskInstructionInputError`.
   */
  method<N extends DuskInstructionName>(name: N, ...call: DuskMethodCall<N>): AnchorMethodBuilder {
    return this.uncheckedMethod(name, call[0]);
  }

  private uncheckedMethod(name: DuskInstructionName, args: unknown): AnchorMethodBuilder {
    const method = (this.program.methods as unknown as AnchorMethods)[name];
    if (!method) {
      throw new Error(`Unknown Dusk instruction: ${name}`);
    }
    return method(...normalizeInstructionArgs(this.program.idl, name, args));
  }

  /**
   * Anchor's method builder with accounts, oracle feeds and event-CPI accounts
   * applied. Arguments and account names are checked against the IDL.
   */
  builder<N extends DuskInstructionName>(name: N, ...call: DuskBuildCall<N>): AnchorMethodBuilder {
    const [args, options] = call as [unknown, UncheckedBuildOptions?];
    return this.uncheckedBuilder(name, args, options);
  }

  private uncheckedBuilder(
    name: DuskInstructionName,
    args: unknown,
    options: UncheckedBuildOptions = {}
  ): AnchorMethodBuilder {
    let builder = this.uncheckedMethod(name, args);
    const instructionAccounts = this.program.idl.instructions?.find(
      (instruction) => instruction.name === name
    )?.accounts;
    const usesEventCpi =
      instructionAccounts?.some((account) => account.name === "eventAuthority") === true &&
      instructionAccounts.some((account) => account.name === "program") === true;
    if (options.accounts || usesEventCpi) {
      const accounts = usesEventCpi
        ? {
            ...options.accounts,
            eventAuthority: deriveEventAuthorityAddress(this.program.programId)[0],
            program: this.program.programId,
          }
        : options.accounts!;
      builder = builder.accounts(normalizeInstructionAccounts(this.program.idl, name, accounts));
    }
    const remaining = [...(options.remainingAccounts ?? [])];
    for (const meta of oracleReadAccounts(options.oraclePolicy)) {
      if (!remaining.some(existing => existing.pubkey.equals(meta.pubkey))) remaining.push(meta);
    }
    if (remaining.length) builder = builder.remainingAccounts(remaining);
    const budgets = oracleComputeBudgetInstructions(options.oraclePolicy);
    if (budgets.length) builder = builder.preInstructions(budgets);
    return builder;
  }

  async instruction<N extends DuskInstructionName>(
    name: N,
    ...call: DuskBuildCall<N>
  ): Promise<TransactionInstruction> {
    const [args, options] = call as [unknown, UncheckedBuildOptions?];
    return this.uncheckedInstruction(name, args, options);
  }

  private async uncheckedInstruction(
    name: DuskInstructionName,
    args: unknown,
    options?: UncheckedBuildOptions
  ): Promise<TransactionInstruction> {
    return this.uncheckedBuilder(name, args, await this.withOraclePolicy(name, options)).instruction();
  }

  async transaction<N extends DuskInstructionName>(
    name: N,
    ...call: DuskBuildCall<N>
  ): Promise<Transaction> {
    const [args, options] = call as [unknown, UncheckedBuildOptions?];
    return this.uncheckedBuilder(name, args, await this.withOraclePolicy(name, options)).transaction();
  }

  async rpc<N extends DuskInstructionName>(name: N, ...call: DuskBuildCall<N>): Promise<string> {
    const [args, options] = call as [unknown, UncheckedBuildOptions?];
    return this.uncheckedBuilder(name, args, await this.withOraclePolicy(name, options)).rpc();
  }

  /**
   * One built instruction as a transaction, led by the compute budget the
   * market's positive oracle weight requires. A bare instruction cannot carry
   * that budget, so every transaction helper over an oracle-reading
   * instruction adds it here.
   */
  private async oracleBudgetedTransaction(
    market: AddressLike,
    instruction: TransactionInstruction
  ): Promise<Transaction> {
    const state = await this.fetchMarketAccount(address(market)) as { oracle?: { policy: OraclePolicyInput } };
    return new Transaction().add(...oracleComputeBudgetInstructions(state.oracle?.policy), instruction);
  }

  /**
   * Add and remove liquidity first apply a due, funded recenter, which costs
   * about as much as a recentering swap and exceeds the default 200k compute
   * units. Concentrated markets with a centre controller get a limit sized
   * for it; positive-weight oracle markets keep their larger oracle budget.
   */
  private async liquidityBudgetedTransaction(
    market: AddressLike,
    instruction: TransactionInstruction
  ): Promise<Transaction> {
    const state = await this.fetchMarketAccount(address(market)) as {
      oracle?: { policy: OraclePolicyInput };
      config: { amm: { peakAmplificationNad: BN; adjustmentStepNad: BN } };
    };
    const oracleBudget = oracleComputeBudgetInstructions(state.oracle?.policy);
    // A peak amplification of one (NAD) is the CPMM, which never recenters.
    const recenters = BigInt(state.config.amm.peakAmplificationNad.toString()) > 1_000_000_000n
      && !state.config.amm.adjustmentStepNad.isZero();
    const budget = oracleBudget.length > 0 || !recenters
      ? oracleBudget
      : [ComputeBudgetProgram.setComputeUnitLimit({ units: LIQUIDITY_RECENTER_COMPUTE_UNIT_LIMIT })];
    return new Transaction().add(...budget, instruction);
  }

  private async withOraclePolicy(
    name: DuskInstructionName,
    options: UncheckedBuildOptions = {}
  ): Promise<UncheckedBuildOptions> {
    if (!ORACLE_READ_INSTRUCTIONS.has(name) || options.oraclePolicy) return options;
    const nested = options.accounts?.accounts as DuskAccounts | undefined;
    const preview = options.accounts?.preview as DuskAccounts | undefined;
    const market = options.accounts?.market ?? nested?.market ?? preview?.market;
    if (!market) return options;

    const state = await this.fetchMarketAccount(address(market as AddressLike)) as { oracle?: {policy: OraclePolicyInput} };
    return {...options, oraclePolicy: state.oracle?.policy};
  }

  /**
   * The hLP accounts an instruction must carry when hedged liquidity is live.
   *
   * Swap and openLeverage both require them, and their order is
   * consensus-visible, so both take them from here rather than each assembling
   * its own list.
   */
  /**
   * The hLP settlement prefix an instruction must carry when the market has
   * active hLP.
   *
   * Required by every leverage instruction that settles the market —
   * open, close, increase and decrease — not only by open. Omitting it fails
   * with `NotEnoughAccounts` at the point the program tries to read the
   * prefix, which names neither leverage nor hLP and reads as a malformed
   * call.
   */
  async hlpRemainingAccounts(
    marketAddress: AddressLike,
    marketSnapshot?: Market,
    required = false
  ): Promise<AccountMeta[]> {
    const market = address(marketAddress);
    const state = (marketSnapshot ?? await this.fetchMarketAccount(market)) as {
      srlpMint: AccountMeta["pubkey"];
      baseSide: { interestVault: AccountMeta["pubkey"]; assetMint: AccountMeta["pubkey"]; reserveVault: AccountMeta["pubkey"] };
      quoteSide: { interestVault: AccountMeta["pubkey"]; assetMint: AccountMeta["pubkey"]; reserveVault: AccountMeta["pubkey"] };
      baseHlpVault: {
        hlpSupply: { toString(): string };
        residualExposure: { toString(): string };
        srlpVault: AccountMeta["pubkey"];
      };
      quoteHlpVault: {
        hlpSupply: { toString(): string };
        residualExposure: { toString(): string };
        srlpVault: AccountMeta["pubkey"];
      };
    };
    const hlpActive =
      BigInt(state.baseHlpVault.hlpSupply.toString()) !== 0n ||
      BigInt(state.quoteHlpVault.hlpSupply.toString()) !== 0n ||
      BigInt(state.baseHlpVault.residualExposure.toString()) !== 0n ||
      BigInt(state.quoteHlpVault.residualExposure.toString()) !== 0n;
    if (!hlpActive && !required) return [];
    return [
      { pubkey: state.srlpMint, isSigner: false, isWritable: true },
      { pubkey: state.baseHlpVault.srlpVault, isSigner: false, isWritable: true },
      { pubkey: state.quoteHlpVault.srlpVault, isSigner: false, isWritable: true },
      { pubkey: state.baseSide.interestVault, isSigner: false, isWritable: true },
      { pubkey: state.quoteSide.interestVault, isSigner: false, isWritable: true },
      // Fresh public-interest settlements rebalance both vaults. These keys
      // usually duplicate fixed swap accounts; repayments need them explicitly.
      { pubkey: state.baseSide.assetMint, isSigner: false, isWritable: false },
      { pubkey: state.quoteSide.assetMint, isSigner: false, isWritable: false },
      { pubkey: state.baseSide.reserveVault, isSigner: false, isWritable: true },
      { pubkey: state.quoteSide.reserveVault, isSigner: false, isWritable: true },
    ];
  }

  async swapBuilder(
    amounts: SwapAmounts,
    options: SwapBuildOptions
  ): Promise<AnchorMethodBuilder> {
    // Spread rather than picked field by field, so a JavaScript caller's
    // misspelled key reaches the IDL check instead of being dropped.
    return this.swapMethodBuilder({ ...amounts }, options);
  }

  private async swapMethodBuilder(
    args: DuskInstructionArgs<"swap">,
    options: SwapBuildOptions
  ): Promise<AnchorMethodBuilder> {
    const market = address(options.market);
    const state = (await this.fetchMarketAccount(market)) as {
      srlpMint: AccountMeta["pubkey"];
      baseSide: { interestVault: AccountMeta["pubkey"] };
      quoteSide: { interestVault: AccountMeta["pubkey"] };
      baseHlpVault: {
        hlpSupply: { toString(): string };
        residualExposure: { toString(): string };
        srlpVault: AccountMeta["pubkey"];
      };
      quoteHlpVault: {
        hlpSupply: { toString(): string };
        residualExposure: { toString(): string };
        srlpVault: AccountMeta["pubkey"];
      };
    };
    const hlpActive =
      BigInt(state.baseHlpVault.hlpSupply.toString()) !== 0n ||
      BigInt(state.quoteHlpVault.hlpSupply.toString()) !== 0n ||
      BigInt(state.baseHlpVault.residualExposure.toString()) !== 0n ||
      BigInt(state.quoteHlpVault.residualExposure.toString()) !== 0n;
    const prefix: AccountMeta[] = hlpActive
      ? [
          { pubkey: state.srlpMint, isSigner: false, isWritable: true },
          { pubkey: state.baseHlpVault.srlpVault, isSigner: false, isWritable: true },
          { pubkey: state.quoteHlpVault.srlpVault, isSigner: false, isWritable: true },
          { pubkey: state.baseSide.interestVault, isSigner: false, isWritable: true },
          { pubkey: state.quoteSide.interestVault, isSigner: false, isWritable: true },
        ]
      : [];

    return this.builder("swap", args, {
      oraclePolicy: options.oraclePolicy ?? (state as typeof state & {oracle?: {policy: OraclePolicyInput}}).oracle?.policy,
      accounts: {
        ...options.accounts,
        // The market whose state chose the hLP prefix above.
        market,
        instructionsSysvar: SYSVAR_INSTRUCTIONS_PUBKEY,
      },
      // Prefix order is consensus-visible. Hook accounts must remain a tail,
      // including any deliberate duplicate pubkeys required by a hook meta list.
      remainingAccounts: [...prefix, ...(options.remainingAccounts ?? [])],
    });
  }

  async swapInstruction(amounts: SwapAmounts, options: SwapBuildOptions): Promise<TransactionInstruction> {
    return (await this.swapBuilder(amounts, options)).instruction();
  }

  async swapTransaction(amounts: SwapAmounts, options: SwapBuildOptions): Promise<Transaction> {
    return (await this.swapBuilder(amounts, options)).transaction();
  }

  async swapRpc(amounts: SwapAmounts, options: SwapBuildOptions): Promise<string> {
    return (await this.swapBuilder(amounts, options)).rpc();
  }

  /**
   * Swap, with accounts resolved from the market and the two mints.
   *
   * `swapInstruction` takes a prepared account map, which makes callers
   * responsible for reconstructing the program's account set. This resolves it
   * instead: reserve vaults derive from the market and mint, trader accounts
   * default to the associated token account for the correct token program, and
   * the hLP remaining-account prefix is still assembled by `swapBuilder`,
   * whose ordering is consensus-visible.
   */
  async buildSwapInstruction(
    params: SwapParams
  ): Promise<TransactionInstruction> {
    return (await this.buildSwapBuilder(params)).instruction();
  }

  async buildSwapTransaction(params: SwapParams): Promise<Transaction> {
    return (await this.buildSwapBuilder(params)).transaction();
  }

  /**
   * Borrow against a position, with accounts resolved from the market and the
   * two mints.
   *
   * The referral accounts are optional on chain and are omitted here: a borrow
   * with no referrer should not have to name accounts it does not use. Use
   * `referredBorrow` when a referrer is present.
   */
  async buildBorrowInstruction(
    params: BorrowParams
  ): Promise<TransactionInstruction> {
    const market = address(params.market);
    const owner = address(params.owner);
    const debtAssetMint = address(params.debtAssetMint);
    const collateralAssetMint = address(params.collateralAssetMint);

    if (debtAssetMint.equals(collateralAssetMint)) {
      throw new Error("Borrow debt and collateral mints must differ");
    }

    const debtTokenProgram = await tokenProgramForMint(
      this.program.provider.connection,
      debtAssetMint
    );
    const programId = this.program.programId;

    return this.instruction(
      "borrow",
      {
        borrowAmount: integerBN(params.borrowAmount, "borrowAmount"),
        minDebtAmountOut: integerBN(
          params.minDebtAmountOut,
          "minDebtAmountOut"
        ),
        minLiquidationCfBps: Number(params.minLiquidationCfBps ?? 0),
        referrer: null,
      },
      {
        accounts: {
          market,
          futarchyAuthority: deriveFutarchyAuthorityAddress(programId)[0],
          owner,
          debtAssetMint,
          collateralAssetMint,
          reserveVault: address(
            params.reserveVault ??
              deriveMarketReserveVaultAddress(market, debtAssetMint, programId)[0]
          ),
          ownerDebtAccount: address(
            params.ownerDebtAccount ??
              getAssociatedTokenAddressSync(
                debtAssetMint,
                owner,
                true,
                debtTokenProgram
              )
          ),
          borrowPosition: address(
            params.borrowPosition ??
              deriveBorrowPositionAddress(market, owner, address(params.positionId), programId)[0]
          ),
          referralPartner: null,
          referralAccrual: null,
          tokenProgram: TOKEN_PROGRAM_ID,
          token2022Program: TOKEN_2022_PROGRAM_ID,
        },
        remainingAccounts: params.remainingAccounts,
      }
    );
  }

  async buildBorrowTransaction(params: BorrowParams): Promise<Transaction> {
    const options = await this.withOraclePolicy("borrow", { accounts: {market: address(params.market)} });
    return new Transaction().add(...oracleComputeBudgetInstructions(options.oraclePolicy),
      await this.buildBorrowInstruction(params));
  }

  /**
   * Open a leverage position, with accounts resolved from the market, the
   * position id and the two mints.
   *
   * Referral accounts are optional on chain and omitted here; use
   * `referredOpenLeverage` when a referrer is present.
   */
  async buildOpenLeverageInstruction(
    params: OpenLeverageParams
  ): Promise<TransactionInstruction> {
    const market = address(params.market);
    const owner = address(params.owner);
    const debtMint = address(params.debtMint);
    const collateralMint = address(params.collateralMint);

    if (debtMint.equals(collateralMint)) {
      throw new Error("Leverage debt and collateral mints must differ");
    }

    if ("fundingAsset" in params && params.fundingAsset !== undefined && params.fundingAsset !== "debt")
      throw new Error("Leverage funding must use the debt asset; swap other tokens before opening");
    const positionId = address(params.positionId);
    const debtTokenProgram = await tokenProgramForMint(
      this.program.provider.connection,
      debtMint
    );
    const programId = this.program.programId;

    const openArgs = {
        positionId,
        debtAsset: params.debtAsset === "quote" ? 1 : 0,
        marginAmount: integerBN(params.marginAmount, "marginAmount"),
        multiplierBps: integerBN(
          params.multiplierBps,
          "multiplierBps"
        ),
        minCollateralOut: integerBN(
          params.minCollateralOut,
          "minCollateralOut"
        ),
        referrer: null,
        positionOwner: null,
        limitPriceNad: integerBN(
          params.limitPriceNad ?? 0,
          "limitPriceNad"
        ),
      };
    return this.instruction(
      "openLeverage",
      openArgs,
      {
        accounts: {
          market,
          futarchyAuthority: deriveFutarchyAuthorityAddress(programId)[0],
          owner,
          payer: address(params.payer ?? owner),
          leveragePosition: address(
            params.leveragePosition ??
              deriveLeveragePositionAddress(market, owner, positionId, owner, programId)[0]
          ),
          debtMint,
          collateralMint,
          debtReserveVault: address(
            params.debtReserveVault ??
              deriveMarketReserveVaultAddress(market, debtMint, programId)[0]
          ),
          collateralReserveVault: address(
            params.collateralReserveVault ??
              deriveMarketReserveVaultAddress(market, collateralMint, programId)[0]
          ),
          leverageCollateralVault: address(
            params.leverageCollateralVault ??
              deriveLeverageCollateralVaultAddress(market, collateralMint, programId)[0]
          ),
          ownerDebtAccount: address(
            params.ownerDebtAccount ??
              getAssociatedTokenAddressSync(
                debtMint,
                owner,
                true,
                debtTokenProgram
              )
          ),
          referralPartner: null,
          referralAccrual: null,
          instructionsSysvar: SYSVAR_INSTRUCTIONS_PUBKEY,
          tokenProgram: TOKEN_PROGRAM_ID,
          token2022Program: TOKEN_2022_PROGRAM_ID,
          systemProgram: SystemProgram.programId,
        },
        remainingAccounts: [
          ...(await this.hlpRemainingAccounts(market)),
          ...(params.remainingAccounts ?? []),
        ],
      }
    );
  }

  async buildOpenLeverageTransaction(
    params: OpenLeverageParams
  ): Promise<Transaction> {
    const options = await this.withOraclePolicy("openLeverage", { accounts: {market: address(params.market)} });
    return new Transaction().add(...oracleComputeBudgetInstructions(options.oraclePolicy),
      await this.buildOpenLeverageInstruction(params)
    );
  }

  /**
   * Delegate a leverage position to a program that may act on it, which is how
   * conditional orders (take-profit, stop-loss) are authorised.
   */
  async buildCreateLeverageDelegationInstruction(
    params: CreateLeverageDelegationParams
  ): Promise<TransactionInstruction> {
    const market = address(params.market);
    const programId = this.program.programId;
    const leveragePosition = address(
      params.leveragePosition ??
        deriveLeveragePositionAddress(market, address(params.owner), address(params.positionId), address(params.namespaceAuthority ?? params.owner), programId)[0]
    );

    return this.instruction(
      "createLeverageDelegation",
      {
        debtAsset: params.debtAsset === "quote" ? 1 : 0,
        delegatedProgram: address(params.delegatedProgram),
        approvedActions: Number(params.approvedActions),
      },
      {
        accounts: {
          market,
          leveragePosition,
          leverageDelegation: address(
            params.leverageDelegation ??
              deriveLeverageDelegationAddress(leveragePosition, programId)[0]
          ),
          owner: address(params.owner),
          systemProgram: SystemProgram.programId,
        },
        remainingAccounts: params.remainingAccounts,
      }
    );
  }

  async buildCreateLeverageDelegationTransaction(
    params: CreateLeverageDelegationParams
  ): Promise<Transaction> {
    return new Transaction().add(
      await this.buildCreateLeverageDelegationInstruction(params)
    );
  }

  private async buildSwapBuilder(params: SwapParams) {
    const market = address(params.market);
    const trader = address(params.trader);
    const assetInMint = address(params.assetInMint);
    const assetOutMint = address(params.assetOutMint);

    if (assetInMint.equals(assetOutMint)) {
      throw new Error("Swap input and output mints must differ");
    }

    const connection = this.program.provider.connection;
    const programId = this.program.programId;
    const [assetInProgram, assetOutProgram] = await Promise.all([
      tokenProgramForMint(connection, assetInMint),
      tokenProgramForMint(connection, assetOutMint),
    ]);

    return this.swapMethodBuilder(
      // A single positional SwapArgs struct. Wrapping it in an outer object
      // used to serialize a struct of zeros; the IDL check now rejects it.
      {
        exactAssetIn: integerBN(params.exactAssetIn, "exactAssetIn"),
        minAssetOut: integerBN(params.minAssetOut, "minAssetOut"),
      },
      {
        market,
        accounts: {
          futarchyAuthority: deriveFutarchyAuthorityAddress(programId)[0],
          trader,
          assetInMint,
          assetOutMint,
          reserveInVault: address(
            params.reserveInVault ??
              deriveMarketReserveVaultAddress(market, assetInMint, programId)[0]
          ),
          reserveOutVault: address(
            params.reserveOutVault ??
              deriveMarketReserveVaultAddress(market, assetOutMint, programId)[0]
          ),
          traderAssetInAccount: address(
            params.traderAssetInAccount ??
              getAssociatedTokenAddressSync(
                assetInMint,
                trader,
                true,
                assetInProgram
              )
          ),
          traderAssetOutAccount: address(
            params.traderAssetOutAccount ??
              getAssociatedTokenAddressSync(
                assetOutMint,
                trader,
                true,
                assetOutProgram
              )
          ),
          tokenProgram: TOKEN_PROGRAM_ID,
          token2022Program: TOKEN_2022_PROGRAM_ID,
        },
        remainingAccounts: params.remainingAccounts,
      }
    );
  }

  async initializeYieldAccountsInstruction(params: {
    payer: AddressLike;
    owner: AddressLike;
    market: AddressLike;
    lpMint: AddressLike;
    baseMint: AddressLike;
    quoteMint: AddressLike;
    tokenKind: YieldTokenKind;
    /** Supply the retired mint's cohort when initializing claims after rotation. */
    retired?: boolean;
  }): Promise<TransactionInstruction> {
    const payer = address(params.payer);
    const owner = address(params.owner);
    const market = address(params.market);
    const lpMint = address(params.lpMint);
    const baseMint = address(params.baseMint);
    const quoteMint = address(params.quoteMint);
    return this.instruction("initializeYieldAccounts", { owner, tokenKind: yieldTokenKindArg(params.tokenKind) }, {
      accounts: {
        payer,
        market,
        lpMint,
        baseMint,
        quoteMint,
        baseYieldAccount: deriveYieldAccountAddress(
          market,
          owner,
          lpMint,
          baseMint,
          params.tokenKind,
          this.program.programId
        )[0],
        quoteYieldAccount: deriveYieldAccountAddress(
          market,
          owner,
          lpMint,
          quoteMint,
          params.tokenKind,
          this.program.programId
        )[0],
        systemProgram: SystemProgram.programId,
      },
      remainingAccounts: params.retired
        ? [{ pubkey: (params.tokenKind === "junior" || params.tokenKind === 2 ? deriveJuniorCohortAddress : deriveHlpCohortAddress)(market, lpMint, this.program.programId)[0], isSigner: false, isWritable: false }]
        : [],
    });
  }

  async initializeYieldAccountsTransaction(
    params: Parameters<DuskWrite["initializeYieldAccountsInstruction"]>[0]
  ): Promise<Transaction> {
    return new Transaction().add(await this.initializeYieldAccountsInstruction(params));
  }

  async initializeLpTransferHookInstruction(params: {
    payer: AddressLike;
    market: AddressLike;
    lpMint: AddressLike;
    /** Pass this when composing market creation and hook setup in one transaction. */
    tokenKind?: YieldTokenKind;
  }): Promise<TransactionInstruction> {
    const lpMint = address(params.lpMint);
    const market = address(params.market);
    let tokenKind = params.tokenKind;
    const juniorCohort = deriveJuniorCohortAddress(market, lpMint, this.program.programId)[0];
    if (tokenKind === undefined) {
      const state = await this.fetchMarketAccount(market) as Market;
      if (lpMint.equals(state.srlpMint)) tokenKind = "srlp";
      else if (lpMint.equals(state.juniorMint)) tokenKind = "junior";
      else if (lpMint.equals(state.baseSide.hlpMint) || lpMint.equals(state.quoteSide.hlpMint)) tokenKind = "hlp";
      // A retired junior generation resolves through its retired cohort.
      else if (await this.program.provider.connection.getAccountInfo(juniorCohort)) tokenKind = "junior";
      else throw new Error("LP mint does not belong to the market");
    }
    const isHlp = tokenKind === "hlp" || tokenKind === 1;
    const isJunior = tokenKind === "junior" || tokenKind === 2;
    return this.instruction("initializeLpTransferHook", undefined, {
      accounts: {
        payer: address(params.payer),
        market,
        lpMint,
        validationAccount: deriveYieldTransferHookValidationAddress(lpMint, this.program.programId)[0],
        systemProgram: SystemProgram.programId,
      },
      // The program reads the junior cohort only for a mint that is no
      // longer the market's current junior mint.
      remainingAccounts: isHlp
        ? [{ pubkey: deriveHlpCohortAddress(market, lpMint, this.program.programId)[0], isSigner: false, isWritable: true }]
        : isJunior
          ? [{ pubkey: juniorCohort, isSigner: false, isWritable: false }]
          : [],
    });
  }

  async initializeLpTransferHookTransaction(
    params: Parameters<DuskWrite["initializeLpTransferHookInstruction"]>[0]
  ): Promise<Transaction> {
    return new Transaction().add(await this.initializeLpTransferHookInstruction(params));
  }

  /**
   * The `params_hash`, and so the market address seed, that
   * `initializeMarketInstruction` derives from these arguments. Compute it to
   * create the LP mints for a market address before the market exists.
   */
  async marketParamsHashFor(params: {
    payer: AddressLike;
    config: MarketLaunchConfig;
    operatorInterestShareBps?: number;
    oracle?: OraclePolicyInput | null;
    bootstrapPriceNad?: IntegerLike;
    launchFeeProgressOffset?: number;
  }): Promise<Uint8Array> {
    return marketParamsHash(this.program.coder, {
      creator: params.payer,
      config: anchorMarketConfig(params.config),
      operatorInterestShareBps: params.operatorInterestShareBps ?? 0,
      oracle: params.oracle == null ? null : oraclePolicy(params.oracle),
      bootstrapPriceNad: integerBN(params.bootstrapPriceNad ?? 0, "bootstrapPriceNad"),
      launchFeeProgressOffset: params.launchFeeProgressOffset ?? 0,
    });
  }

  /**
   * Bring a market into existence.
   *
   * The three LP mints must already exist and carry the Dusk transfer hook —
   * see `createHookedLpMintInstructions`. Every PDA is derived here rather
   * than left to Anchor, because the market address depends on `paramsHash`,
   * which is an argument rather than an account, and the vaults hang off the
   * market in turn.
   *
   * `teamTreasury` and its wrapped-SOL account come from the futarchy
   * authority, which must already be initialized on the deployment.
   */
  async initializeMarketInstruction(params: {
    payer: AddressLike;
    baseMint: AddressLike;
    quoteMint: AddressLike;
    srlpMint: AddressLike;
    baseHlpMint: AddressLike;
    quoteHlpMint: AddressLike;
    teamTreasury: AddressLike;
    teamTreasuryWsolAccount: AddressLike;
    /** Derived from the payer and creation arguments (`marketParamsHash`).
     * A supplied value must equal it; omit it unless checking a precomputed
     * market address. */
    paramsHash?: Uint8Array | Buffer | number[];
    config: MarketLaunchConfig;
    /** Share of base interest retained by the operator, 0–10000 bps. */
    operatorInterestShareBps?: number;
    /** Installed atomically at creation. Omit or pass null for native pricing.
     * Guided first liquidity derives its ratio from the validated current feed. */
    oracle?: OraclePolicyInput | null;
    /** Native launch-adapter price in NAD. Guided creation requires zero. */
    bootstrapPriceNad?: IntegerLike;
    launchFeeProgressOffset?: number;
    lpMetadata: {
      srlp: { name: string; symbol: string; uri: string };
      baseHlp: { name: string; symbol: string; uri: string };
      quoteHlp: { name: string; symbol: string; uri: string };
    };
  }): Promise<TransactionInstruction> {
    const operatorShare=params.operatorInterestShareBps??0;
    if(!Number.isInteger(operatorShare)||operatorShare<0||operatorShare>MAX_OPERATOR_INTEREST_SHARE_BPS)throw new Error(`operatorInterestShareBps must be 0–${MAX_OPERATOR_INTEREST_SHARE_BPS}`);
    const baseMint = address(params.baseMint);
    const quoteMint = address(params.quoteMint);
    const oracle = params.oracle == null ? null : oraclePolicy(params.oracle);
    const bootstrapPriceNad = integerBN(params.bootstrapPriceNad ?? 0, "bootstrapPriceNad");
    if (oracle && oracle.lambdaBps > 0 && !bootstrapPriceNad.isZero())
      throw new Error("Oracle-guided markets derive the initial price from the feed; omit bootstrapPriceNad");
    const config = anchorMarketConfig(params.config);
    const launchFeeProgressOffset = params.launchFeeProgressOffset ?? 0;
    const paramsHash = await this.marketParamsHashFor(params);
    if (params.paramsHash !== undefined && !Buffer.from(params.paramsHash).equals(Buffer.from(paramsHash))) {
      throw new Error("paramsHash does not match the payer and creation arguments; omit it to derive the market address");
    }
    const programId = this.program.programId;
    const [market] = deriveMarketAddress(baseMint, quoteMint, paramsHash, programId);
    return this.instruction(
      "initializeMarket",
      {
        operatorInterestShareBps:operatorShare,
        config,
        oracle,
        paramsHash: [...paramsHash],
        bootstrapPriceNad,
        launchFeeProgressOffset,
        srlpMetadata: params.lpMetadata.srlp,
        baseHlpMetadata: params.lpMetadata.baseHlp,
        quoteHlpMetadata: params.lpMetadata.quoteHlp,
      },
      {
        accounts: {
          payer: address(params.payer),
          baseMint,
          quoteMint,
          srlpMint: address(params.srlpMint),
          baseHlpMint: address(params.baseHlpMint),
          quoteHlpMint: address(params.quoteHlpMint),
          srlpTokenMetadata: deriveTokenMetadataAddress(address(params.srlpMint))[0],
          baseHlpTokenMetadata: deriveTokenMetadataAddress(address(params.baseHlpMint))[0],
          quoteHlpTokenMetadata: deriveTokenMetadataAddress(address(params.quoteHlpMint))[0],
          market,
          futarchyAuthority: deriveFutarchyAuthorityAddress(programId)[0],
          baseReserveVault: deriveMarketReserveVaultAddress(market, baseMint, programId)[0],
          quoteReserveVault: deriveMarketReserveVaultAddress(market, quoteMint, programId)[0],
          baseCollateralVault: deriveMarketCollateralVaultAddress(market, baseMint, programId)[0],
          quoteCollateralVault: deriveMarketCollateralVaultAddress(market, quoteMint, programId)[0],
          baseInterestVault: deriveMarketInterestVaultAddress(market, baseMint, programId)[0],
          quoteInterestVault: deriveMarketInterestVaultAddress(market, quoteMint, programId)[0],
          teamTreasury: address(params.teamTreasury),
          teamTreasuryWsolAccount: address(params.teamTreasuryWsolAccount),
          systemProgram: SystemProgram.programId,
          tokenProgram: TOKEN_PROGRAM_ID,
          token2022Program: TOKEN_2022_PROGRAM_ID,
          sysvarInstructions: SYSVAR_INSTRUCTIONS_PUBKEY,
          tokenMetadataProgram: TOKEN_METADATA_PROGRAM_ID,
        },
      }
    );
  }

  async initializeMarketTransaction(
    params: Parameters<DuskWrite["initializeMarketInstruction"]>[0]
  ): Promise<Transaction> {
    return new Transaction().add(await this.initializeMarketInstruction(params));
  }

  /** Update a current LP mint's cosmetic metadata, signed by the market operator.
   * Does not change authority, token supply, balances, or financial settings. */
  updateLpMetadataInstruction(params: {
    market: AddressLike;
    operator: AddressLike;
    lpMint: AddressLike;
    metadata: LpTokenMetadataInput;
  }): Promise<TransactionInstruction> {
    assertLpTokenMetadata(params.metadata);
    const lpMint = address(params.lpMint);
    return this.instruction("updateLpMetadata", params.metadata, { accounts: {
      operator: address(params.operator), market: address(params.market), lpMint,
      tokenMetadata: deriveTokenMetadataAddress(lpMint)[0],
      tokenMetadataProgram: TOKEN_METADATA_PROGRAM_ID,
    } });
  }

  async hlpLiquidityAction<N extends HlpLiquidityName>(
    name: N,
    params: HlpLiquidityParams<N>,
    options: HlpLiquidityBuildOptions<N>
  ): Promise<HlpLiquidityBuild> {
    const payer = address(options.payer);
    const owner = address(options.owner);
    const market = address(options.market);
    const lpMint = address(options.targetHlpMint);
    const baseMint = address(options.baseMint);
    const quoteMint = address(options.quoteMint);
    const baseYieldAccount = deriveYieldAccountAddress(
      market,
      owner,
      lpMint,
      baseMint,
      "hlp",
      this.program.programId
    )[0];
    const quoteYieldAccount = deriveYieldAccountAddress(
      market,
      owner,
      lpMint,
      quoteMint,
      "hlp",
      this.program.programId
    )[0];
    const [baseYieldInfo, quoteYieldInfo] = await Promise.all([
      this.program.provider.connection.getAccountInfo(baseYieldAccount),
      this.program.provider.connection.getAccountInfo(quoteYieldAccount),
    ]);
    const yieldAccountDefinition = this.program.idl.accounts?.find(
      (account) => account.name === "yieldAccount"
    );
    if (!yieldAccountDefinition) {
      throw new Error("Dusk IDL is missing YieldAccount");
    }
    const yieldAccountSize = this.program.coder.accounts.size("yieldAccount");
    const yieldAccountDiscriminator = Buffer.from(yieldAccountDefinition.discriminator);
    const yieldAccountsReady = [baseYieldInfo, quoteYieldInfo].every(
      (info) =>
        info !== null &&
        info.owner.equals(this.program.programId) &&
        info.data.length === yieldAccountSize &&
        info.data.subarray(0, yieldAccountDiscriminator.length).equals(yieldAccountDiscriminator)
    );
    const setupInstructions =
      yieldAccountsReady
        ? []
        : [
            await this.initializeYieldAccountsInstruction({
              payer,
              owner,
              market,
              lpMint,
              baseMint,
              quoteMint,
              tokenKind: "hlp",
            }),
          ];
    // Widened to both actions: `name` and `params` share one N, which
    // TypeScript cannot narrow from a comparison.
    const args: HlpLiquidityParams = params;
    const accounts: HlpLiquidityAccounts = options.accounts;
    const actionInstruction = await this.instruction<HlpLiquidityName>(name, { ...args }, {
      accounts: {
        ...accounts,
        market,
        owner,
        targetHlpMint: lpMint,
        baseMint,
        quoteMint,
        baseYieldAccount,
        quoteYieldAccount,
      },
      remainingAccounts: name === "depositSingleSided"
        ? mergeAccountMetas(await this.hlpRemainingAccounts(market, options.marketSnapshot, true), options.remainingAccounts ?? [])
        : options.remainingAccounts,
      oraclePolicy: options.oraclePolicy,
    });
    return {
      baseYieldAccount,
      quoteYieldAccount,
      setupInstructions,
      actionInstruction,
      transaction: new Transaction().add(
        ComputeBudgetProgram.requestHeapFrame({bytes:256 * 1024}),
        ComputeBudgetProgram.setComputeUnitLimit({units:1_400_000}),
        ...setupInstructions, actionInstruction,
      ),
    };
  }

  depositSingleSided(
    params: DepositSingleSidedParams,
    options: HlpLiquidityBuildOptions<"depositSingleSided">
  ): Promise<HlpLiquidityBuild> {
    return this.hlpLiquidityAction("depositSingleSided", params, options);
  }

  withdrawSingleSided(
    params: WithdrawSingleSidedParams,
    options: HlpLiquidityBuildOptions<"withdrawSingleSided">
  ): Promise<HlpLiquidityBuild> {
    return this.hlpLiquidityAction("withdrawSingleSided", params, options);
  }

  /** Begin a fresh hLP receipt cohort after the current vault has terminally closed. */
  rotateHlpCohortInstruction(params: {
    payer: AddressLike;
    market: AddressLike;
    oldHlpMint: AddressLike;
    newHlpMint: AddressLike;
    targetAsset: "base" | "quote";
    metadata: { name: string; symbol: string; uri: string };
  }): Promise<TransactionInstruction> {
    const market = address(params.market);
    const oldHlpMint = address(params.oldHlpMint);
    const newHlpMint = address(params.newHlpMint);
    return this.instruction("rotateHlpCohort", {
      targetAsset: params.targetAsset === "base" ? 0 : 1,
      metadata: params.metadata,
    }, {
      accounts: {
        payer: address(params.payer),
        market,
        oldHlpMint,
        newHlpMint,
        oldCohort: deriveHlpCohortAddress(market, oldHlpMint, this.program.programId)[0],
        newTokenMetadata: deriveTokenMetadataAddress(newHlpMint)[0],
        sysvarInstructions: SYSVAR_INSTRUCTIONS_PUBKEY,
        token2022Program: TOKEN_2022_PROGRAM_ID,
        tokenMetadataProgram: TOKEN_METADATA_PROGRAM_ID,
        systemProgram: SystemProgram.programId,
      },
    });
  }

  /** Burn old hLP receipts after terminal closure while preserving earned yield. */
  burnRetiredHlpReceiptInstruction(params: {
    market: AddressLike;
    owner: AddressLike;
    retiredMint: AddressLike;
    baseMint: AddressLike;
    quoteMint: AddressLike;
    amount: IntegerLike;
    ownerHlpAccount?: AddressLike;
  }): Promise<TransactionInstruction> {
    const market = address(params.market);
    const owner = address(params.owner);
    const retiredMint = address(params.retiredMint);
    return this.instruction("burnRetiredHlpReceipt", {
      amount: integerBN(params.amount),
    }, {
      accounts: {
        market,
        owner,
        retiredMint,
        cohort: deriveHlpCohortAddress(market, retiredMint, this.program.programId)[0],
        ownerHlpAccount: params.ownerHlpAccount
          ? address(params.ownerHlpAccount)
          : getAssociatedTokenAddressSync(retiredMint, owner, true, TOKEN_2022_PROGRAM_ID),
        baseYieldAccount: deriveYieldAccountAddress(
          market, owner, retiredMint, address(params.baseMint), "hlp", this.program.programId
        )[0],
        quoteYieldAccount: deriveYieldAccountAddress(
          market, owner, retiredMint, address(params.quoteMint), "hlp", this.program.programId
        )[0],
        token2022Program: TOKEN_2022_PROGRAM_ID,
      },
    });
  }

  async configureReferralPartnerInstruction(params: {
    authoritySigner: AddressLike;
    referrer: AddressLike;
    interestShareBps: number;
    active: boolean;
    futarchyAuthority?: AddressLike;
  }): Promise<TransactionInstruction> {
    assertReferralInterestShareBps(params.interestShareBps);
    const referrer = address(params.referrer);
    return this.instruction(
      "configureReferralPartner",
      {
        referrer,
        interestShareBps: params.interestShareBps,
        active: params.active,
      },
      {
        accounts: {
          authoritySigner: address(params.authoritySigner),
          futarchyAuthority:
            params.futarchyAuthority ?? deriveFutarchyAuthorityAddress(this.program.programId)[0],
          referralPartner: deriveReferralPartnerAddress(referrer, this.program.programId)[0],
          systemProgram: SystemProgram.programId,
        },
      }
    );
  }

  async configureReferralPartnerTransaction(
    params: Parameters<DuskWrite["configureReferralPartnerInstruction"]>[0]
  ): Promise<Transaction> {
    return new Transaction().add(await this.configureReferralPartnerInstruction(params));
  }

  async initializeReferralAccrualInstruction(params: {
    payer: AddressLike;
    referrer: AddressLike;
    market: AddressLike;
    assetMint: AddressLike;
  }): Promise<TransactionInstruction> {
    const referral = referralAccrualAddresses({ ...params, programId: this.program.programId });
    return this.instruction("initializeReferralAccrual", undefined, {
      accounts: {
        payer: address(params.payer),
        referralPartner: referral.referralPartner,
        market: address(params.market),
        assetMint: address(params.assetMint),
        referralAccrual: referral.referralAccrual,
        systemProgram: SystemProgram.programId,
      },
    });
  }

  async initializeReferralAccrualTransaction(
    params: Parameters<DuskWrite["initializeReferralAccrualInstruction"]>[0]
  ): Promise<Transaction> {
    return new Transaction().add(
      await this.initializeReferralAccrualInstruction(params)
    );
  }

  async referredAction<N extends ReferredActionName>(
    name: N,
    params: ReferredActionParams<N>,
    options: ReferredActionOptions<N>
  ): Promise<ReferredActionBuild> {
    const referral = referralAccrualAddresses({
      referrer: options.referrer,
      market: options.market,
      assetMint: options.debtMint,
      programId: this.program.programId,
    });
    const setupInstruction = await this.initializeReferralAccrualInstruction({
      payer: options.payer,
      referrer: options.referrer,
      market: options.market,
      assetMint: options.debtMint,
    });
    const hookAccounts = options.transferHookTransfers?.length
      ? await resolveTransferHookAccountMetas(
          this.program.provider.connection,
          options.transferHookTransfers
        )
      : [];
    const referrer = address(options.referrer);
    // The market the referral accrual was derived for.
    const market = address(options.market);
    const referralAccounts = {
      referralPartner: referral.referralPartner,
      referralAccrual: referral.referralAccrual,
    };
    const remainingAccounts = mergeAccountMetas(options.remainingAccounts ?? [], hookAccounts);
    // `name` and `params` share one N, which a comparison cannot narrow, so
    // each branch restates its own action. The caller's keys are spread so a
    // misspelled one reaches the IDL check instead of being dropped.
    const actionInstruction =
      name === "borrow"
        ? await this.instruction(
            "borrow",
            borrowArgs(params as ReferredBorrowParams, referrer),
            {
              accounts: { ...(options.accounts as ReferredActionAccounts<"borrow">), market, ...referralAccounts },
              remainingAccounts,
            }
          )
        : await this.instruction(
            "openLeverage",
            openLeverageArgs(params as ReferredOpenLeverageParams, referrer),
            {
              accounts: {
                ...(options.accounts as ReferredActionAccounts<"openLeverage">),
                market,
                ...referralAccounts,
                instructionsSysvar: SYSVAR_INSTRUCTIONS_PUBKEY,
              },
              // Opening settles the market like `buildOpenLeverageInstruction`,
              // so an active hLP needs the same canonical prefix first.
              remainingAccounts: withLeadingAccounts(await this.hlpRemainingAccounts(market), remainingAccounts),
            }
          );
    return {
      referralPartner: referral.referralPartner,
      referralAccrual: referral.referralAccrual,
      setupInstruction,
      actionInstruction,
      transaction: new Transaction().add(setupInstruction, actionInstruction),
    };
  }

  referredBorrow(
    params: ReferredBorrowParams,
    options: ReferredActionOptions<"borrow">
  ): Promise<ReferredActionBuild> {
    return this.referredAction("borrow", params, options);
  }

  referredOpenLeverage(
    params: ReferredOpenLeverageParams,
    options: ReferredActionOptions<"openLeverage">
  ): Promise<ReferredActionBuild> {
    return this.referredAction("openLeverage", params, options);
  }

  async setReferralRecipientInstruction(params: {
    authority: AddressLike;
    recipient: AddressLike;
  }): Promise<TransactionInstruction> {
    const authority = address(params.authority);
    return this.instruction(
      "setReferralRecipient",
      { recipient: address(params.recipient) },
      {
        accounts: {
          authority,
          referralPartner: deriveReferralPartnerAddress(authority, this.program.programId)[0],
        },
      }
    );
  }

  async setReferralRecipientTransaction(params: {
    authority: AddressLike;
    recipient: AddressLike;
  }): Promise<Transaction> {
    return new Transaction().add(await this.setReferralRecipientInstruction(params));
  }

  async claimReferralInterestInstruction(params: {
    authority: AddressLike;
    market: AddressLike;
    mint: AddressLike;
    interestVault?: AddressLike;
    recipientTokenAccount: AddressLike;
    remainingAccounts?: AccountMeta[];
  }): Promise<TransactionInstruction> {
    const authority = address(params.authority);
    const market = address(params.market);
    const mintKey = address(params.mint);
    const referral = referralAccrualAddresses({
      referrer: authority,
      market,
      assetMint: mintKey,
      programId: this.program.programId,
    });
    const interestVault = address(
      params.interestVault ?? deriveMarketInterestVaultAddress(market, mintKey, this.program.programId)[0]
    );
    const recipientTokenAccount = address(params.recipientTokenAccount);
    const tokenProgram = await tokenProgramForMint(
      this.program.provider.connection,
      mintKey
    );
    const referralAccrual = (this.program as unknown as {
      account: {
        referralAccrual: {
          fetch(address: PublicKey): Promise<{ amount: { toString(): string } }>;
        };
      };
    }).account.referralAccrual;
    const [accrual, mint] = await Promise.all([
      referralAccrual.fetch(referral.referralAccrual),
      getMint(
        this.program.provider.connection,
        mintKey,
        undefined,
        tokenProgram
      ),
    ]);
    const hookAccounts = await resolveTransferHookAccountMetas(
      this.program.provider.connection,
      [
        {
          source: interestVault,
          mint: mintKey,
          destination: recipientTokenAccount,
          authority: market,
          amount: accrual.amount,
          decimals: mint.decimals,
          tokenProgram,
        },
      ]
    );
    return this.instruction("claimReferralInterest", undefined, {
      accounts: {
        market,
        authority,
        referralPartner: referral.referralPartner,
        assetMint: mintKey,
        referralAccrual: referral.referralAccrual,
        interestVault,
        recipientTokenAccount,
        tokenProgram: TOKEN_PROGRAM_ID,
        token2022Program: TOKEN_2022_PROGRAM_ID,
      },
      remainingAccounts: mergeAccountMetas(params.remainingAccounts ?? [], hookAccounts),
    });
  }

  async claimReferralInterestTransaction(
    params: Parameters<DuskWrite["claimReferralInterestInstruction"]>[0]
  ): Promise<Transaction> {
    return new Transaction().add(
      await this.claimReferralInterestInstruction(params)
    );
  }

  /**
   * Deposit collateral into a borrow position, creating it when `positionId` is
   * new. Callers pass amounts in raw base units.
   */
  async depositCollateralInstruction(
    params: DepositCollateralParams
  ): Promise<TransactionInstruction> {
    const market = address(params.market);
    const owner = address(params.owner);
    const assetMint = address(params.assetMint);
    const positionId = address(params.positionId);
    const programId = this.program.programId;
    return this.instruction(
      "depositCollateral",
      { positionId, depositAmount: integerBN(params.depositAmount, "depositAmount") },
      {
        accounts: {
          market,
          owner,
          assetMint,
          collateralVault: address(
            params.collateralVault ??
              deriveMarketCollateralVaultAddress(market, assetMint, programId)[0]
          ),
          ownerAssetAccount: address(params.ownerAssetAccount),
          borrowPosition: address(
            params.borrowPosition ??
              deriveBorrowPositionAddress(market, owner, positionId, programId)[0]
          ),
          tokenProgram: TOKEN_PROGRAM_ID,
          token2022Program: TOKEN_2022_PROGRAM_ID,
        },
        remainingAccounts: params.remainingAccounts,
      }
    );
  }

  /** Donate to an existing borrow position. `owner` is the token payer. */
  async donateCollateralInstruction(params: DepositCollateralParams): Promise<TransactionInstruction> {
    const market = address(params.market);
    const assetMint = address(params.assetMint);
    const programId = this.program.programId;
    return this.instruction("donateCollateral",
      { depositAmount: integerBN(params.depositAmount, "depositAmount") }, {
        accounts: {
          market, owner: address(params.owner), assetMint,
          collateralVault: address(params.collateralVault ?? deriveMarketCollateralVaultAddress(market, assetMint, programId)[0]),
          ownerAssetAccount: address(params.ownerAssetAccount),
          borrowPosition: address(params.borrowPosition ?? deriveBorrowPositionAddress(market, address(params.positionOwner ?? params.owner), address(params.positionId), programId)[0]),
          tokenProgram: TOKEN_PROGRAM_ID, token2022Program: TOKEN_2022_PROGRAM_ID,
        }, remainingAccounts: params.remainingAccounts,
      });
  }

  /** Sweep both collateral balances and close a debt-free borrow position. */
  async withdrawAllCollateralInstruction(params: WithdrawAllCollateralParams): Promise<TransactionInstruction> {
    const market = address(params.market);
    const baseMint = address(params.baseMint);
    const quoteMint = address(params.quoteMint);
    const programId = this.program.programId;
    return this.instruction("withdrawAllCollateral", {
      minBaseOut: integerBN(params.minBaseOut, "minBaseOut"),
      minQuoteOut: integerBN(params.minQuoteOut, "minQuoteOut"),
    }, { accounts: {
      market, owner: address(params.owner), baseMint, quoteMint,
      borrowPosition: address(params.borrowPosition ?? deriveBorrowPositionAddress(market, address(params.owner), address(params.positionId), programId)[0]),
      baseCollateralVault: deriveMarketCollateralVaultAddress(market, baseMint, programId)[0],
      quoteCollateralVault: deriveMarketCollateralVaultAddress(market, quoteMint, programId)[0],
      ownerBaseAccount: address(params.ownerBaseAccount), ownerQuoteAccount: address(params.ownerQuoteAccount),
      tokenProgram: TOKEN_PROGRAM_ID, token2022Program: TOKEN_2022_PROGRAM_ID,
    }, remainingAccounts: params.remainingAccounts });
  }

  /** Return all collateral after a complete leverage repayment and close the position. */
  async withdrawRepaidLeverageInstruction(params: WithdrawRepaidLeverageParams): Promise<TransactionInstruction> {
    const market = address(params.market);
    const collateralMint = address(params.collateralMint);
    const programId = this.program.programId;
    return this.instruction("withdrawRepaidLeverage",
      { minCollateralOut: integerBN(params.minCollateralOut, "minCollateralOut") }, {
        accounts: {
          market, owner: address(params.owner), collateralMint,
          leveragePosition: address(params.leveragePosition ?? deriveLeveragePositionAddress(market, address(params.owner), address(params.positionId), address(params.namespaceAuthority ?? params.owner), programId)[0]),
          collateralVault: deriveLeverageCollateralVaultAddress(market, collateralMint, programId)[0],
          ownerCollateralAccount: address(params.ownerCollateralAccount),
          tokenProgram: TOKEN_PROGRAM_ID, token2022Program: TOKEN_2022_PROGRAM_ID,
        }, remainingAccounts: params.remainingAccounts,
      });
  }

  async depositCollateralTransaction(
    params: DepositCollateralParams
  ): Promise<Transaction> {
    return this.oracleBudgetedTransaction(params.market, await this.depositCollateralInstruction(params));
  }

  /**
   * Withdraw collateral. `minAssetAmountOut` and `minLiquidationCfBps` are the
   * caller's slippage and health floors; the program rejects the withdrawal
   * rather than silently returning less.
   */
  async withdrawCollateralInstruction(
    params: WithdrawCollateralParams
  ): Promise<TransactionInstruction> {
    const market = address(params.market);
    const owner = address(params.owner);
    const assetMint = address(params.assetMint);
    const positionId = address(params.positionId);
    const programId = this.program.programId;
    return this.instruction(
      "withdrawCollateral",
      {
        withdrawAmount: integerBN(params.withdrawAmount, "withdrawAmount"),
        minAssetAmountOut: integerBN(params.minAssetAmountOut, "minAssetAmountOut"),
        minLiquidationCfBps: params.minLiquidationCfBps,
      },
      {
        accounts: {
          market,
          futarchyAuthority: deriveFutarchyAuthorityAddress(programId)[0],
          owner,
          assetMint,
          collateralVault: address(
            params.collateralVault ??
              deriveMarketCollateralVaultAddress(market, assetMint, programId)[0]
          ),
          ownerAssetAccount: address(params.ownerAssetAccount),
          borrowPosition: address(
            params.borrowPosition ??
              deriveBorrowPositionAddress(market, owner, positionId, programId)[0]
          ),
          tokenProgram: TOKEN_PROGRAM_ID,
          token2022Program: TOKEN_2022_PROGRAM_ID,
        },
        remainingAccounts: params.remainingAccounts,
      }
    );
  }

  async withdrawCollateralTransaction(
    params: WithdrawCollateralParams
  ): Promise<Transaction> {
    return this.oracleBudgetedTransaction(params.market, await this.withdrawCollateralInstruction(params));
  }

  /**
   * Repay anyone’s borrowed debt using `owner`’s tokens, without collateral rights.
   * Pass the wallet balance as `repayAmount` to clear a
   * position; the program repays at most the outstanding debt.
   */
  async repayInstruction(params: RepayParams): Promise<TransactionInstruction> {
    const market = address(params.market);
    const owner = address(params.owner);
    const debtAssetMint = address(params.debtAssetMint);
    const positionId = address(params.positionId);
    const referralPartner = params.referralPartner
      ? address(params.referralPartner)
      : null;
    const programId = this.program.programId;
    return this.instruction(
      "repay",
      { repayAmount: integerBN(params.repayAmount, "repayAmount") },
      {
        accounts: {
          market,
          futarchyAuthority: deriveFutarchyAuthorityAddress(programId)[0],
          owner,
          debtAssetMint,
          collateralAssetMint: address(params.collateralAssetMint),
          reserveVault: address(
            params.reserveVault ??
              deriveMarketReserveVaultAddress(market, debtAssetMint, programId)[0]
          ),
          interestVault: address(
            params.interestVault ??
              deriveMarketInterestVaultAddress(market, debtAssetMint, programId)[0]
          ),
          ownerDebtAccount: address(params.ownerDebtAccount),
          borrowPosition: address(
            params.borrowPosition ??
              deriveBorrowPositionAddress(market, address(params.positionOwner ?? params.owner), positionId, programId)[0]
          ),
          referralPartner,
          referralAccrual: referralPartner
            ? deriveReferralAccrualAddress(
                referralPartner,
                market,
                debtAssetMint,
                programId
              )[0]
            : null,
          tokenProgram: TOKEN_PROGRAM_ID,
          token2022Program: TOKEN_2022_PROGRAM_ID,
        },
        remainingAccounts: [...(await this.hlpRemainingAccounts(market)), ...(params.remainingAccounts ?? [])],
      }
    );
  }

  async repayTransaction(params: RepayParams): Promise<Transaction> {
    return this.oracleBudgetedTransaction(params.market, await this.repayInstruction(params));
  }

  /**
   * Add balanced srLP liquidity. `minSrlpAmount` is the caller's slippage floor;
   * the program rejects the deposit rather than minting fewer shares.
   */
  async addLiquidityInstruction(
    params: AddLiquidityParams
  ): Promise<TransactionInstruction> {
    const common = await this.resolveSrlpAccounts(params);
    return this.instruction(
      "addLiquidity",
      {
        baseDepositAmount: integerBN(
          params.baseDepositAmount,
          "baseDepositAmount"
        ),
        quoteDepositAmount: integerBN(
          params.quoteDepositAmount,
          "quoteDepositAmount"
        ),
        minSrlpAmount: integerBN(params.minSrlpAmount, "minSrlpAmount"),
      },
      {
        accounts: {
          ...common,
          futarchyAuthority: deriveFutarchyAuthorityAddress(this.program.programId)[0],
        },
        remainingAccounts: params.remainingAccounts,
      }
    );
  }

  async addLiquidityTransaction(
    params: AddLiquidityParams
  ): Promise<Transaction> {
    return this.liquidityBudgetedTransaction(params.market, await this.addLiquidityInstruction(params));
  }

  /**
   * Burn srLP for the underlying pair. Both minimums are enforced by the
   * program, so a partially-filled withdrawal fails instead of silently
   * returning less of one side.
   */
  async removeLiquidityInstruction(
    params: RemoveLiquidityParams
  ): Promise<TransactionInstruction> {
    const common = await this.resolveSrlpAccounts(params);
    return this.instruction(
      "removeLiquidity",
      {
        srlpAmount: integerBN(params.srlpAmount, "srlpAmount"),
        minBaseAmountOut: integerBN(
          params.minBaseAmountOut,
          "minBaseAmountOut"
        ),
        minQuoteAmountOut: integerBN(
          params.minQuoteAmountOut,
          "minQuoteAmountOut"
        ),
      },
      { accounts: common, remainingAccounts: params.remainingAccounts }
    );
  }

  async removeLiquidityTransaction(
    params: RemoveLiquidityParams
  ): Promise<Transaction> {
    return this.liquidityBudgetedTransaction(params.market, await this.removeLiquidityInstruction(params));
  }

  /**
   * Accounts shared by both balanced srLP instructions. Reserve vaults and srLP
   * yield accounts derive from the market; token programs resolve per mint so
   * a Token-2022 side needs no caller branching.
   */
  /** Borrow more against an open position and receive collateral. */
  async increaseLeverageInstruction(params: IncreaseLeverageParams): Promise<TransactionInstruction> {
    return this.fundLeverageInstruction(params, 0n);
  }

  /** Add debt-token equity and optional borrowing to the same position. */
  async addToLeverageInstruction(params: AddToLeverageParams): Promise<TransactionInstruction> {
    if (BigInt(params.marginAmount.toString()) <= 0n) throw new RangeError("marginAmount must be positive");
    return this.fundLeverageInstruction(params, params.marginAmount, params.ownerDebtAccount);
  }

  async addToLeverageTransaction(params: AddToLeverageParams): Promise<Transaction> {
    return this.oracleBudgetedTransaction(params.market, await this.addToLeverageInstruction(params));
  }

  private async fundLeverageInstruction(
    params: IncreaseLeverageParams, marginAmount: RawAmount, ownerDebtAccount?: AddressLike
  ): Promise<TransactionInstruction> {
    const core = await this.resolveLeverageAccounts(params);
    return this.instruction(
      "increaseLeverage",
      {
        debtAsset: marketAssetIndex(params.debtAsset),
        debtAmount: integerBN(params.debtAmount, "debtAmount"),
        marginAmount: integerBN(marginAmount, "marginAmount"),
        minCollateralOut: integerBN(
          params.minCollateralOut,
          "minCollateralOut"
        ),
      },
      {
        accounts: {
          market: core.market,
          futarchyAuthority: core.futarchyAuthority,
          positionOwner: core.positionOwner,
          leveragePosition: core.leveragePosition,
          debtMint: core.debtMint,
          collateralMint: core.collateralMint,
          debtReserveVault: core.debtReserveVault,
          collateralReserveVault: core.collateralReserveVault,
          leverageCollateralVault: core.leverageCollateralVault,
          owner: core.owner,
          ownerDebtAccount: ownerDebtAccount ? address(ownerDebtAccount) : null,
          instructionsSysvar: SYSVAR_INSTRUCTIONS_PUBKEY,
          tokenProgram: core.tokenProgram,
          token2022Program: TOKEN_2022_PROGRAM_ID,
        },
        remainingAccounts: [
          ...(await this.hlpRemainingAccounts(core.market)),
          ...(params.remainingAccounts ?? []),
        ],
      }
    );
  }

  async increaseLeverageTransaction(
    params: IncreaseLeverageParams
  ): Promise<Transaction> {
    return this.oracleBudgetedTransaction(params.market, await this.increaseLeverageInstruction(params));
  }

  /** Sell collateral to repay debt without closing the position. */
  async decreaseLeverageInstruction(
    params: DecreaseLeverageParams
  ): Promise<TransactionInstruction> {
    const core = await this.resolveLeverageAccounts(params);
    return this.instruction(
      "decreaseLeverage",
      {
        debtAsset: marketAssetIndex(params.debtAsset),
        collateralAmount: integerBN(
          params.collateralAmount,
          "collateralAmount"
        ),
        minRepayOut: integerBN(params.minRepayOut, "minRepayOut"),
        maxSurplusOut: integerBN(params.maxSurplusOut ?? 0n, "maxSurplusOut"),
      },
      {
        accounts: {
          market: core.market,
          futarchyAuthority: core.futarchyAuthority,
          positionOwner: core.positionOwner,
          leveragePosition: core.leveragePosition,
          debtMint: core.debtMint,
          collateralMint: core.collateralMint,
          debtReserveVault: core.debtReserveVault,
          collateralReserveVault: core.collateralReserveVault,
          debtInterestVault: core.debtInterestVault,
          ownerDebtAccount: address(params.ownerDebtAccount),
          leverageCollateralVault: core.leverageCollateralVault,
          referralPartner: core.referralPartner,
          referralAccrual: core.referralAccrual,
          owner: core.owner,
          instructionsSysvar: SYSVAR_INSTRUCTIONS_PUBKEY,
          tokenProgram: core.tokenProgram,
          token2022Program: TOKEN_2022_PROGRAM_ID,
        },
        remainingAccounts: [
          ...(await this.hlpRemainingAccounts(core.market)),
          ...(params.remainingAccounts ?? []),
        ],
      }
    );
  }

  async decreaseLeverageTransaction(
    params: DecreaseLeverageParams
  ): Promise<Transaction> {
    return this.oracleBudgetedTransaction(params.market, await this.decreaseLeverageInstruction(params));
  }

  /** Repay anyone’s leverage debt from `owner`’s tokens; collateral stays with the position owner. */
  async addLeverageMarginInstruction(params: LeverageMarginParams): Promise<TransactionInstruction> {
    return this.repayLeverageInstruction(params);
  }

  /** Permissionless repayment without an unnecessary collateral-sale quote. */
  async repayLeverageInstruction(params: LeverageMarginParams): Promise<TransactionInstruction> {
    return this.leverageRepaymentInstruction(params, "repayLeverage");
  }

  private async leverageRepaymentInstruction(
    params: LeverageMarginParams, method: "addLeverageMargin" | "repayLeverage"
  ): Promise<TransactionInstruction> {
    const core = await this.resolveLeverageAccounts(params);
    return this.instruction(
      method,
      {
        debtAsset: marketAssetIndex(params.debtAsset),
        amount: integerBN(params.amount, "amount"),
      },
      {
        accounts: {
          market: core.market,
          futarchyAuthority: core.futarchyAuthority,
          positionOwner: core.positionOwner,
          leveragePosition: core.leveragePosition,
          debtMint: core.debtMint,
          collateralMint: core.collateralMint,
          debtReserveVault: core.debtReserveVault,
          debtInterestVault: core.debtInterestVault,
          ownerDebtAccount: address(params.ownerDebtAccount),
          referralPartner: core.referralPartner,
          referralAccrual: core.referralAccrual,
          owner: core.owner,
          tokenProgram: core.tokenProgram,
          token2022Program: TOKEN_2022_PROGRAM_ID,
        },
        remainingAccounts: [...(await this.hlpRemainingAccounts(core.market)), ...(params.remainingAccounts ?? [])],
      }
    );
  }

  async repayLeverageTransaction(params: LeverageMarginParams): Promise<Transaction> {
    return this.oracleBudgetedTransaction(params.market, await this.repayLeverageInstruction(params));
  }

  async addLeverageMarginTransaction(
    params: LeverageMarginParams
  ): Promise<Transaction> {
    return this.oracleBudgetedTransaction(params.market, await this.repayLeverageInstruction(params));
  }

  /**
   * Owner-signed proportional partial/full close. Delegated closes use the delegate client.
   */
  async closeLeverageInstruction(
    params: CloseLeverageParams,
    marketSnapshot?: Market
  ): Promise<TransactionInstruction> {
    if ("collateralFunded" in params && params.collateralFunded === true)
      throw new Error("Collateral-funded leverage closes are no longer supported");
    const closeBps = params.closeBps ?? 10_000;
    if (!Number.isSafeInteger(closeBps) || closeBps <= 0 || closeBps > 10_000)
      throw new RangeError("closeBps must be between 1 and 10000");
    const core = await this.resolveLeverageAccounts(params);
    return this.instruction(
      "closeLeverage",
      {
        debtAsset: marketAssetIndex(params.debtAsset),
        minAmountOut: integerBN(params.minAmountOut, "minAmountOut"),
        closeBps,
      },
      {
        accounts: {
          market: core.market,
          futarchyAuthority: core.futarchyAuthority,
          positionOwner: core.positionOwner,
          leveragePosition: core.leveragePosition,
          debtMint: core.debtMint,
          collateralMint: core.collateralMint,
          debtReserveVault: core.debtReserveVault,
          collateralReserveVault: core.collateralReserveVault,
          debtInterestVault: core.debtInterestVault,
          leverageCollateralVault: core.leverageCollateralVault,
          ownerDebtAccount: address(params.ownerDebtAccount),
          delegateFeeRecipient: params.delegateFeeRecipient
            ? address(params.delegateFeeRecipient)
            : null,
          delegateExecutorAccount: params.delegateExecutorAccount
            ? address(params.delegateExecutorAccount)
            : null,
          referralPartner: core.referralPartner,
          referralAccrual: core.referralAccrual,
          leverageDelegation: params.leverageDelegation
            ? address(params.leverageDelegation)
            : null,
          delegatedProgram: params.delegatedProgram
            ? address(params.delegatedProgram)
            : null,
          authority: address(params.authority ?? params.positionOwner),
          instructionsSysvar: SYSVAR_INSTRUCTIONS_PUBKEY,
          tokenProgram: core.tokenProgram,
          token2022Program: TOKEN_2022_PROGRAM_ID,
        },
        remainingAccounts: [
          ...(await this.hlpRemainingAccounts(core.market, marketSnapshot)),
          ...(params.remainingAccounts ?? []),
        ],
      }
    );
  }

  async closeLeverageTransaction(
    params: CloseLeverageParams
  ): Promise<Transaction> {
    return this.oracleBudgetedTransaction(params.market, await this.closeLeverageInstruction(params));
  }

  /**
   * Accounts shared across the leverage lifecycle. Individual builders pass
   * through only the subset their instruction declares.
   */
  private async resolveLeverageAccounts(params: LeverageAccounts) {
    const market = address(params.market);
    const positionOwner = address(params.positionOwner);
    const debtMint = address(params.debtMint);
    const collateralMint = address(params.collateralMint);
    const positionId = address(params.positionId);
    const referralPartner = params.referralPartner
      ? address(params.referralPartner)
      : null;
    const programId = this.program.programId;
    return {
      market,
      futarchyAuthority: deriveFutarchyAuthorityAddress(programId)[0],
      positionOwner,
      owner: address(params.owner ?? params.positionOwner),
      leveragePosition: address(
        params.leveragePosition ??
          deriveLeveragePositionAddress(market, positionOwner, positionId, address(params.namespaceAuthority ?? params.positionOwner), programId)[0]
      ),
      debtMint,
      collateralMint,
      debtReserveVault: address(
        params.debtReserveVault ??
          deriveMarketReserveVaultAddress(market, debtMint, programId)[0]
      ),
      collateralReserveVault: address(
        params.collateralReserveVault ??
          deriveMarketReserveVaultAddress(market, collateralMint, programId)[0]
      ),
      debtInterestVault: address(
        params.debtInterestVault ??
          deriveMarketInterestVaultAddress(market, debtMint, programId)[0]
      ),
      leverageCollateralVault: address(
        params.leverageCollateralVault ??
          deriveLeverageCollateralVaultAddress(market, collateralMint, programId)[0]
      ),
      referralPartner,
      referralAccrual: referralPartner
        ? deriveReferralAccrualAddress(referralPartner, market, debtMint, programId)[0]
        : null,
      tokenProgram: TOKEN_PROGRAM_ID,
    };
  }

  private async resolveSrlpAccounts(params: SrlpLiquidityAccounts) {
    const market = address(params.market);
    const owner = address(params.owner);
    const baseMint = address(params.baseMint);
    const quoteMint = address(params.quoteMint);
    const srlpMint = address(params.srlpMint);
    const programId = this.program.programId;
    return {
      market,
      owner,
      baseMint,
      quoteMint,
      srlpMint,
      baseReserveVault: address(
        params.baseReserveVault ??
          deriveMarketReserveVaultAddress(market, baseMint, programId)[0]
      ),
      quoteReserveVault: address(
        params.quoteReserveVault ??
          deriveMarketReserveVaultAddress(market, quoteMint, programId)[0]
      ),
      ownerBaseAccount: address(params.ownerBaseAccount),
      ownerQuoteAccount: address(params.ownerQuoteAccount),
      ownerSrlpAccount: address(params.ownerSrlpAccount),
      baseYieldAccount: address(
        params.baseYieldAccount ??
          deriveYieldAccountAddress(
            market,
            owner,
            srlpMint,
            baseMint,
            "srlp",
            programId
          )[0]
      ),
      quoteYieldAccount: address(
        params.quoteYieldAccount ??
          deriveYieldAccountAddress(
            market,
            owner,
            srlpMint,
            quoteMint,
            "srlp",
            programId
          )[0]
      ),
      tokenProgram: TOKEN_PROGRAM_ID,
      token2022Program: TOKEN_2022_PROGRAM_ID,
    };
  }
}

interface LendingPositionAccounts {
  market: AddressLike;
  owner: AddressLike;
  /** Beneficiary when a different wallet pays for this position. */
  positionOwner?: AddressLike;
  /** Position discriminator; the borrow position PDA derives from it. */
  positionId: AddressLike;
  borrowPosition?: AddressLike;
  remainingAccounts?: AccountMeta[];
}

export interface DepositCollateralParams extends LendingPositionAccounts {
  assetMint: AddressLike;
  ownerAssetAccount: AddressLike;
  depositAmount: RawAmount;
  collateralVault?: AddressLike;
}

export interface WithdrawCollateralParams extends LendingPositionAccounts {
  assetMint: AddressLike;
  ownerAssetAccount: AddressLike;
  withdrawAmount: RawAmount;
  minAssetAmountOut: RawAmount;
  /** Health floor enforced by the program, in basis points. */
  minLiquidationCfBps: number;
  collateralVault?: AddressLike;
}

export interface RepayParams extends LendingPositionAccounts {
  debtAssetMint: AddressLike;
  collateralAssetMint: AddressLike;
  ownerDebtAccount: AddressLike;
  repayAmount: RawAmount;
  /** Omit when the position has no referrer. */
  referralPartner?: AddressLike | null;
  reserveVault?: AddressLike;
  interestVault?: AddressLike;
}

/** Which side of the pair carries the debt. */
export type MarketAssetSide = "base" | "quote";

function marketAssetIndex(side: MarketAssetSide): number {
  if (side !== "base" && side !== "quote") {
    throw new Error(`debtAsset must be "base" or "quote", got ${String(side)}`);
  }
  return side === "base" ? 0 : 1;
}

interface LeverageAccounts {
  market: AddressLike;
  positionOwner: AddressLike;
  /** Position discriminator; the leverage position PDA derives from it. */
  positionId: AddressLike;
  debtMint: AddressLike;
  collateralMint: AddressLike;
  debtAsset: MarketAssetSide;
  /** Signer when it differs from the position owner. */
  owner?: AddressLike;
  /** Signer that originally funded the position, if different from its owner. */
  namespaceAuthority?: AddressLike;
  leveragePosition?: AddressLike;
  debtReserveVault?: AddressLike;
  collateralReserveVault?: AddressLike;
  debtInterestVault?: AddressLike;
  leverageCollateralVault?: AddressLike;
  referralPartner?: AddressLike | null;
  remainingAccounts?: AccountMeta[];
}

export interface IncreaseLeverageParams extends LeverageAccounts {
  debtAmount: RawAmount;
  minCollateralOut: RawAmount;
}

export interface AddToLeverageParams extends IncreaseLeverageParams {
  /** Gross wallet funding in the borrowed token. */
  marginAmount: RawAmount;
  ownerDebtAccount: AddressLike;
}

export interface DecreaseLeverageParams extends LeverageAccounts {
  collateralAmount: RawAmount;
  minRepayOut: RawAmount;
  /** Owner-owned debt-token account for unused repayment output. */
  ownerDebtAccount: AddressLike;
  /** Gross surplus limit; defaults to zero. Use a bounded value for 1x rounding. */
  maxSurplusOut?: RawAmount;
}

export interface LeverageMarginParams extends LeverageAccounts {
  amount: RawAmount;
  ownerDebtAccount: AddressLike;
}

export interface CloseLeverageParams extends LeverageAccounts {
  /** Minimum net wallet payout after all transfer fees. */
  minAmountOut: RawAmount;
  /** Percentage of the entire position to remove. Default 10000 closes all. */
  closeBps?: number;
  /** Payout account owned by the position owner. */
  ownerDebtAccount: AddressLike;
  /** Required for delegated closes; the two accounts receive bounded fees. */
  delegateFeeRecipient?: AddressLike | null;
  delegateExecutorAccount?: AddressLike | null;
  /** Delegated settlement; omit these for an owner-signed close. */
  leverageDelegation?: AddressLike | null;
  delegatedProgram?: AddressLike | null;
  authority?: AddressLike;
}

interface SrlpLiquidityAccounts {
  market: AddressLike;
  owner: AddressLike;
  baseMint: AddressLike;
  quoteMint: AddressLike;
  srlpMint: AddressLike;
  ownerBaseAccount: AddressLike;
  ownerQuoteAccount: AddressLike;
  ownerSrlpAccount: AddressLike;
  baseReserveVault?: AddressLike;
  quoteReserveVault?: AddressLike;
  baseYieldAccount?: AddressLike;
  quoteYieldAccount?: AddressLike;
  remainingAccounts?: AccountMeta[];
}

/** Which side of the market a leverage position borrows. */
export type LeverageDebtAsset = "base" | "quote";

/** Opening leverage funded in the debt asset; margin plus borrowing buys collateral. */
export interface OpenLeverageParams {
  market: AddressLike;
  owner: AddressLike;
  positionId: AddressLike;
  debtAsset: LeverageDebtAsset;
  debtMint: AddressLike;
  collateralMint: AddressLike;
  marginAmount: RawAmount;
  /** Leverage multiplier in basis points; 20000 is two times. */
  multiplierBps: RawAmount;
  minCollateralOut: RawAmount;
  /** Zero means no limit price. */
  limitPriceNad?: RawAmount;
  payer?: AddressLike;
  ownerDebtAccount?: AddressLike;
  leveragePosition?: AddressLike;
  debtReserveVault?: AddressLike;
  collateralReserveVault?: AddressLike;
  leverageCollateralVault?: AddressLike;
  remainingAccounts?: AccountMeta[];
}

/** Authorising a program to act on a leverage position. */
export interface CreateLeverageDelegationParams {
  market: AddressLike;
  owner: AddressLike;
  namespaceAuthority?: AddressLike;
  positionId: AddressLike;
  debtAsset: LeverageDebtAsset;
  delegatedProgram: AddressLike;
  /** Bit flags for the actions the delegate may perform. */
  approvedActions: number;
  leveragePosition?: AddressLike;
  leverageDelegation?: AddressLike;
  remainingAccounts?: AccountMeta[];
}

/** A borrow described by its market, position and mints. */
export interface BorrowParams {
  market: AddressLike;
  owner: AddressLike;
  /** Position discriminator; the borrow position PDA derives from it. */
  positionId: AddressLike;
  debtAssetMint: AddressLike;
  collateralAssetMint: AddressLike;
  borrowAmount: RawAmount;
  /** Slippage floor on the debt actually opened. */
  minDebtAmountOut: RawAmount;
  minLiquidationCfBps?: number;
  ownerDebtAccount?: AddressLike;
  reserveVault?: AddressLike;
  borrowPosition?: AddressLike;
  remainingAccounts?: AccountMeta[];
}

/** A swap described by its market and mints rather than by an account map. */
export interface SwapParams {
  market: AddressLike;
  trader: AddressLike;
  assetInMint: AddressLike;
  assetOutMint: AddressLike;
  exactAssetIn: RawAmount;
  /** Slippage floor; the program rejects a fill below it. */
  minAssetOut: RawAmount;
  traderAssetInAccount?: AddressLike;
  traderAssetOutAccount?: AddressLike;
  reserveInVault?: AddressLike;
  reserveOutVault?: AddressLike;
  remainingAccounts?: AccountMeta[];
}

export interface AddLiquidityParams extends SrlpLiquidityAccounts {
  /** Maximum gross spend. Guided first deposits pair at the current validated
   * oracle price; unused amounts remain with the owner. Native seeding uses
   * both amounts to establish the initial ratio. */
  baseDepositAmount: RawAmount;
  quoteDepositAmount: RawAmount;
  /** Slippage floor on minted srLP shares. */
  minSrlpAmount: RawAmount;
}

export interface RemoveLiquidityParams extends SrlpLiquidityAccounts {
  srlpAmount: RawAmount;
  minBaseAmountOut: RawAmount;
  minQuoteAmountOut: RawAmount;
}

/**
 * Widen a launch config into the shape Anchor expects: every `u64` as a BN,
 * every `u16` left as a number. Written out field by field rather than mapped,
 * so a field added to the program fails to compile here instead of silently
 * going missing.
 */
function anchorMarketConfig(config: MarketLaunchConfig): DuskDefinedInput<"marketConfig"> {
  const bn = (value: IntegerLike, label: string) => integerBN(value, label);
  // bn.js `gtn` is only defined below 2^26, so compare as BigInt.
  if (BigInt(bn(config.amm.peakAmplificationNad as IntegerLike, "peakAmplificationNad").toString()) > 1_000_000_000n
      && bn(config.amm.adjustmentStepNad as IntegerLike, "adjustmentStepNad").isZero()) {
    throw new Error("concentrated markets require an enabled center controller");
  }
  return {
    swapFeeBps: config.swapFeeBps,
    divergenceFeeShareCapBps: config.divergenceFeeShareCapBps,
    volatilityFeeShareCapBps: config.volatilityFeeShareCapBps,
    targetHlpLeverageBps: config.targetHlpLeverageBps,
    settlementDivergenceBps: config.settlementDivergenceBps,
    emaHalfLifeMs: bn(config.emaHalfLifeMs, "emaHalfLifeMs"),
    directionalEmaHalfLifeMs: bn(
      config.directionalEmaHalfLifeMs,
      "directionalEmaHalfLifeMs"
    ),
    curveDepthEmaHalfLifeMs: bn(config.curveDepthEmaHalfLifeMs, "curveDepthEmaHalfLifeMs"),
    maxDailyBorrowBps: config.maxDailyBorrowBps,
    globalHealthContributionCapBps: config.globalHealthContributionCapBps,
    borrowMarketHealthFloorBps: config.borrowMarketHealthFloorBps,
    // `MarketLaunchConfig` keeps these two loosely typed, so the IDL check
    // validates their fields at run time instead.
    amm: anchorIntegerFields(config.amm, AMM_U64_FIELDS) as DuskDefinedInput<"ammConfig">,
    irm: anchorIntegerFields(config.irm, IRM_U64_FIELDS) as DuskDefinedInput<"riskRateConfig">,
    startTime: bn(config.startTime, "startTime"),
  };
}

const AMM_U64_FIELDS = [
  "peakAmplificationNad",
  "centerEmaHalfLifeMs",
  "volatilityHalfLifeMs",
  "adjustmentStepNad",
  "volatilityShockCapNad",
  "volatilityCapNad",
  "divergenceFeeCoefficientNad",
  "volatilityFeeCoefficientNad",
  "launchFeeDurationSeconds",
  "launchRateLimitReferenceNad",
  "launchRateLimitDurationSeconds",
] as const;

const IRM_U64_FIELDS = ["lowerSignalNad", "upperSignalNad", "halfLifeMs", "initialAprNad"] as const;

function anchorIntegerFields(
  source: Record<string, unknown>,
  wide: readonly string[]
): Record<string, unknown> {
  const out: Record<string, unknown> = { ...source };
  for (const field of wide) {
    if (out[field] === undefined) continue;
    out[field] = integerBN(out[field] as IntegerLike, field);
  }
  return out;
}

function borrowArgs(params: ReferredBorrowParams, referrer: PublicKey): DuskInstructionArgs<"borrow"> {
  return { ...params, minLiquidationCfBps: params.minLiquidationCfBps ?? 0, referrer };
}

function openLeverageArgs(
  params: ReferredOpenLeverageParams,
  referrer: PublicKey
): DuskInstructionArgs<"openLeverage"> {
  return {
    ...params,
    debtAsset: params.debtAsset === 0 || params.debtAsset === 1 ? params.debtAsset : marketAssetIndex(params.debtAsset),
    limitPriceNad: params.limitPriceNad ?? 0,
    positionOwner: params.positionOwner ?? null,
    referrer,
  };
}

/**
 * Put `prefix` first unless `accounts` already starts with it, so a caller
 * who supplied the canonical prefix explicitly does not get it twice.
 */
function withLeadingAccounts(prefix: readonly AccountMeta[], accounts: readonly AccountMeta[]): AccountMeta[] {
  const present =
    prefix.length <= accounts.length &&
    prefix.every((meta, index) => accounts[index].pubkey.equals(meta.pubkey));
  return present ? [...accounts] : [...prefix, ...accounts];
}

function mergeAccountMetas(...groups: readonly AccountMeta[][]): AccountMeta[] {
  const merged = new Map<string, AccountMeta>();
  for (const group of groups) {
    for (const meta of group) {
      const key = meta.pubkey.toBase58();
      const current = merged.get(key);
      merged.set(key, {
        pubkey: meta.pubkey,
        isSigner: Boolean(current?.isSigner || meta.isSigner),
        isWritable: Boolean(current?.isWritable || meta.isWritable),
      });
    }
  }
  return [...merged.values()];
}

export interface WithdrawAllCollateralParams extends LendingPositionAccounts {
  baseMint: AddressLike;
  quoteMint: AddressLike;
  ownerBaseAccount: AddressLike;
  ownerQuoteAccount: AddressLike;
  minBaseOut: RawAmount;
  minQuoteOut: RawAmount;
}

export interface WithdrawRepaidLeverageParams {
  market: AddressLike;
  owner: AddressLike;
  namespaceAuthority?: AddressLike;
  positionId: AddressLike;
  leveragePosition?: AddressLike;
  collateralMint: AddressLike;
  ownerCollateralAccount: AddressLike;
  minCollateralOut: RawAmount;
  remainingAccounts?: AccountMeta[];
}

// Kept in step with the on-chain instruction binding boundary.
/** Compute limit for an add or remove that first applies a due recenter on
 * a concentrated market: 327,068 CU measured on the finished binary, plus
 * margin. */
export const LIQUIDITY_RECENTER_COMPUTE_UNIT_LIMIT = 400_000;

const ORACLE_READ_INSTRUCTIONS = new Set<string>([
  "addLiquidity",
  "openLiquidityGates",
  "removeLiquidity",
  "fundInterest",
  "compoundJuniorSeed",
  "harvest",
  "swap",
  "previewHlpFlash",
  "beginHlpFlash",
  "settleHlpFlash",
  "closeInsolventHlp",
  "beginFlashLiquidation",
  "previewFlashLiquidation",
  "previewFlashAmmLiquidation",
  "emergencyLiquidation",
  "previewEmergencyLiquidation",
  "previewLiquidationHealth",
  "settleFlashLiquidation",
  "depositCollateral",
  "withdrawCollateral",
  "borrow",
  "repay",
  "donateCollateral",
  "openLeverage",
  "closeLeverage",
  "delegatedCloseLeverage",
  "increaseLeverage",
  "decreaseLeverage",
  "addLeverageMargin",
  "repayLeverage",
  "previewHlpDepositCapacity",
  "previewMarket",
  "previewHlpOrderTrigger",
  "previewAddLiquidity",
  "previewSwap",
  "previewBorrowCapacity",
  "previewBorrowPositionCapacity",
  "previewBorrowPosition",
  "depositSingleSided",
  "withdrawSingleSided",
  "executeOperatorChange",
]);
